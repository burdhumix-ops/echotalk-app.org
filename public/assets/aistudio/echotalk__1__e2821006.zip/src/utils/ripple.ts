/**
 * Universal Zero-Lag Touch Ripple Effect
 * Spawns a subtle, high-performance white ripple animation upon tap
 * on top of buttons, chat bubbles, and interactive targets.
 */

export function triggerRipple(target: HTMLElement, clientX: number, clientY: number) {
  if (!target) return;

  const rect = target.getBoundingClientRect();
  const diameter = Math.max(rect.width, rect.height) * 1.5;
  const radius = diameter / 2;

  const ripple = document.createElement('span');
  ripple.className = 'touch-ripple-effect';
  ripple.style.width = `${diameter}px`;
  ripple.style.height = `${diameter}px`;
  ripple.style.left = `${clientX - rect.left - radius}px`;
  ripple.style.top = `${clientY - rect.top - radius}px`;

  // Ensure target allows absolute child positioning
  const computed = window.getComputedStyle(target);
  if (computed.position === 'static') {
    target.style.position = 'relative';
  }
  if (computed.overflow !== 'hidden' && !target.classList.contains('overflow-visible')) {
    target.style.overflow = 'hidden';
  }

  target.appendChild(ripple);

  // Automatically remove after animation completes
  setTimeout(() => {
    if (ripple.parentNode === target) {
      target.removeChild(ripple);
    }
  }, 480);
}

let isInitialized = false;

export function initTouchRipple() {
  if (typeof window === 'undefined' || isInitialized) return;
  isInitialized = true;

  window.addEventListener(
    'pointerdown',
    (e: PointerEvent) => {
      // Only primary mouse button or touch
      if (e.pointerType === 'mouse' && e.button !== 0) return;

      const target = (e.target as HTMLElement)?.closest?.(
        'button, [role="button"], .ripple-target, .chat-bubble, a, .tab-item'
      ) as HTMLElement | null;

      if (!target || target.getAttribute('data-no-ripple') === 'true') {
        return;
      }

      triggerRipple(target, e.clientX, e.clientY);
    },
    { passive: true }
  );
}

// Auto-initialize in browser environments
if (typeof window !== 'undefined') {
  initTouchRipple();
}
