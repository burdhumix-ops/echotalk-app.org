/**
 * Acoustic Soundscapes Engine (Web Audio API)
 * Procedural ambient audio generators: Lo-fi Chill Beats, Cafe Rain, Neon Synthwave
 */

export type SoundscapeType = 'none' | 'lofi' | 'rain' | 'synthwave';

class SoundscapeEngine {
  private ctx: AudioContext | null = null;
  private currentType: SoundscapeType = 'none';
  private gainNode: GainNode | null = null;
  private oscillators: OscillatorNode[] = [];
  private intervals: number[] = [];
  private noiseNode: AudioNode | null = null;
  private isPlaying: boolean = false;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setSoundscape(type: SoundscapeType, volume: number = 0.25) {
    this.stop();
    if (type === 'none') {
      this.currentType = 'none';
      return;
    }

    this.initContext();
    if (!this.ctx) return;

    this.currentType = type;
    this.isPlaying = true;
    this.gainNode = this.ctx.createGain();
    this.gainNode.gain.setValueAtTime(volume, this.ctx.currentTime);
    this.gainNode.connect(this.ctx.destination);

    if (type === 'rain') {
      this.playCafeRain();
    } else if (type === 'lofi') {
      this.playLoFiBeats();
    } else if (type === 'synthwave') {
      this.playNeonSynthwave();
    }
  }

  private playCafeRain() {
    if (!this.ctx || !this.gainNode) return;

    // Pink / White noise generator for soothing rain
    const bufferSize = this.ctx.sampleRate * 2;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      data[i] = (b0 + b1 + b2) * 0.18;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;

    // Lowpass filter for warm indoor cafe rain feel
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, this.ctx.currentTime);

    noise.connect(filter);
    filter.connect(this.gainNode);
    noise.start();
    this.noiseNode = noise;
  }

  private playLoFiBeats() {
    if (!this.ctx || !this.gainNode) return;

    // Gentle 7th chord drone and mellow vinyl crackle
    const chords = [130.81, 164.81, 196.00, 246.94]; // Cmaj7 warm pad
    chords.forEach((freq) => {
      const osc = this.ctx!.createOscillator();
      const oscGain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, this.ctx!.currentTime);
      oscGain.gain.setValueAtTime(0.04, this.ctx!.currentTime);

      osc.connect(oscGain);
      oscGain.connect(this.gainNode!);
      osc.start();
      this.oscillators.push(osc);
    });

    // Mellow sub-pulse every 2 seconds
    const intervalId = window.setInterval(() => {
      if (!this.ctx || !this.gainNode) return;
      const kick = this.ctx.createOscillator();
      const kickGain = this.ctx.createGain();
      kick.frequency.setValueAtTime(80, this.ctx.currentTime);
      kick.frequency.exponentialRampToValueAtTime(35, this.ctx.currentTime + 0.3);
      kickGain.gain.setValueAtTime(0.08, this.ctx.currentTime);
      kickGain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.3);
      kick.connect(kickGain);
      kickGain.connect(this.gainNode);
      kick.start();
      kick.stop(this.ctx.currentTime + 0.35);
    }, 2000);
    this.intervals.push(intervalId);
  }

  private playNeonSynthwave() {
    if (!this.ctx || !this.gainNode) return;

    // Neon arpeggiator & retro synth pad
    const bass = this.ctx.createOscillator();
    const bassGain = this.ctx.createGain();
    bass.type = 'sawtooth';
    bass.frequency.setValueAtTime(55, this.ctx.currentTime); // A1 bass
    bassGain.gain.setValueAtTime(0.06, this.ctx.currentTime);

    const bassFilter = this.ctx.createBiquadFilter();
    bassFilter.type = 'lowpass';
    bassFilter.frequency.setValueAtTime(260, this.ctx.currentTime);

    bass.connect(bassFilter);
    bassFilter.connect(bassGain);
    bassGain.connect(this.gainNode);
    bass.start();
    this.oscillators.push(bass);

    // Warm pad
    [220, 277.18, 329.63].forEach((f) => {
      const osc = this.ctx!.createOscillator();
      const g = this.ctx!.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, this.ctx!.currentTime);
      g.gain.setValueAtTime(0.02, this.ctx!.currentTime);

      const fNode = this.ctx!.createBiquadFilter();
      fNode.type = 'lowpass';
      fNode.frequency.setValueAtTime(500, this.ctx!.currentTime);

      osc.connect(fNode);
      fNode.connect(g);
      g.connect(this.gainNode!);
      osc.start();
      this.oscillators.push(osc);
    });
  }

  public stop() {
    this.isPlaying = false;
    this.currentType = 'none';
    this.intervals.forEach((id) => clearInterval(id));
    this.intervals = [];

    this.oscillators.forEach((osc) => {
      try {
        osc.stop();
        osc.disconnect();
      } catch {}
    });
    this.oscillators = [];

    if (this.noiseNode) {
      try {
        (this.noiseNode as any).stop();
        this.noiseNode.disconnect();
      } catch {}
      this.noiseNode = null;
    }

    if (this.gainNode) {
      this.gainNode.disconnect();
      this.gainNode = null;
    }
  }

  public getCurrentType(): SoundscapeType {
    return this.currentType;
  }
}

export const soundscapeEngine = new SoundscapeEngine();
