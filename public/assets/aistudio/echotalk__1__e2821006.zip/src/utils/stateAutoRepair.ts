/**
 * Autonomous State Integrity Auto-Repair Engine
 * Validates localStorage JSON and state structures on app startup.
 * If corrupt or malformed states are detected, auto-heals by restoring
 * clean system defaults while strictly safeguarding credentials and data.
 */

export interface SystemHealthReport {
  repairedKeys: string[];
  intactKeys: string[];
  timestamp: number;
}

export function autoRepairState(): SystemHealthReport {
  const repairedKeys: string[] = [];
  const intactKeys: string[] = [];

  const safeValidate = (key: string, validator: (parsed: any) => boolean, defaultVal: any) => {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return;

      const parsed = JSON.parse(raw);
      if (!validator(parsed)) {
        console.warn(`[Auto-Repair] Malformed state found in '${key}'. Auto-healing to safe defaults.`);
        localStorage.setItem(key, JSON.stringify(defaultVal));
        repairedKeys.push(key);
      } else {
        intactKeys.push(key);
      }
    } catch (e) {
      console.warn(`[Auto-Repair] Corrupt JSON parse error in '${key}'. Rebuilding pristine default.`, e);
      localStorage.setItem(key, JSON.stringify(defaultVal));
      repairedKeys.push(key);
    }
  };

  // 1. Validate Theme
  safeValidate(
    'echotalk_theme_v2',
    (theme) => typeof theme === 'string' && ['midnight', 'cyberpunk', 'nordic', 'solaris', 'obsidian'].includes(theme),
    'midnight'
  );

  // 2. Validate User Age & Preferences
  safeValidate(
    'echotalk_user_age',
    (age) => typeof age === 'number' && !isNaN(age) && age >= 18 && age <= 100,
    24
  );

  // 3. Validate Offline Sync Queue
  safeValidate(
    'echotalk_offline_queue',
    (queue) => Array.isArray(queue),
    []
  );

  return {
    repairedKeys,
    intactKeys,
    timestamp: Date.now()
  };
}
