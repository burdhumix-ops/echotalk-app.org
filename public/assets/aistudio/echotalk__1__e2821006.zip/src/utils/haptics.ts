/**
 * Tactile Haptic Engine
 * Provides distinct physical vibration patterns across EchoTalk micro-interactions.
 */

export function hapticTap(duration: number = 10) {
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    try {
      navigator.vibrate(duration);
    } catch {}
  }
}

export function hapticDoublePulse() {
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    try {
      navigator.vibrate([15, 40, 15]);
    } catch {}
  }
}

export function hapticHeavyBump() {
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    try {
      navigator.vibrate([40, 20, 60]);
    } catch {}
  }
}

export function hapticMicro() {
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    try {
      navigator.vibrate(6);
    } catch {}
  }
}
