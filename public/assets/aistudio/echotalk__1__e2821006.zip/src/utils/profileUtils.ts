// Country flag emoji and gender icon utilities

export const COUNTRY_FLAG_MAP: Record<string, string> = {
  BR: '🇧🇷',
  FR: '🇫🇷',
  IE: '🇮🇪',
  JP: '🇯🇵',
  EE: '🇪🇪',
  PK: '🇵🇰',
  US: '🇺🇸',
  GB: '🇬🇧',
  UK: '🇬🇧',
  DE: '🇩🇪',
  CA: '🇨🇦',
  IN: '🇮🇳',
  KR: '🇰🇷',
  ES: '🇪🇸',
  IT: '🇮🇹',
  AU: '🇦🇺',
  NL: '🇳🇱',
  SE: '🇸🇪',
  MX: '🇲🇽',
  Argentina: '🇦🇷',
  Brazil: '🇧🇷',
  France: '🇫🇷',
  Ireland: '🇮🇪',
  Japan: '🇯🇵',
  Estonia: '🇪🇪',
  Pakistan: '🇵🇰',
  'United States': '🇺🇸',
  USA: '🇺🇸',
  'United Kingdom': '🇬🇧',
  UK_NAME: '🇬🇧',
  Germany: '🇩🇪',
  Canada: '🇨🇦',
  India: '🇮🇳',
  'South Korea': '🇰🇷',
  Spain: '🇪🇸',
  Italy: '🇮🇹',
  Australia: '🇦🇺'
};

export function getCountryFlag(countryOrCode?: string): string {
  if (!countryOrCode) return '🌐';
  const clean = countryOrCode.trim();
  if (COUNTRY_FLAG_MAP[clean]) {
    return COUNTRY_FLAG_MAP[clean];
  }
  if (COUNTRY_FLAG_MAP[clean.toUpperCase()]) {
    return COUNTRY_FLAG_MAP[clean.toUpperCase()];
  }
  // If 2-letter ISO code, generate flag emoji dynamically
  if (/^[a-zA-Z]{2}$/.test(clean)) {
    const codePoints = clean
      .toUpperCase()
      .split('')
      .map((char) => 127397 + char.charCodeAt(0));
    return String.fromCodePoint(...codePoints);
  }
  return '🌐';
}

export function getGenderIcon(gender?: string): string {
  if (!gender) return '⚧️';
  const g = gender.toLowerCase();
  if (g.includes('female') || g.includes('woman') || g === 'f') return '♀️';
  if (g.includes('male') || g.includes('man') || g === 'm') return '♂️';
  return '⚧️';
}
