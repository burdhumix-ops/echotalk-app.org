import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Users, Mic, MicOff, Volume2, Sparkles, MessageSquare, 
  Lock, KeyRound, Radio, Send, Crown, CheckCircle2, ChevronRight, X, Heart, Flame, Headphones
} from 'lucide-react';
import { ChatMessage, ChatRoom, ThemeConfig, UserProfile } from '../../types';
import { getCountryFlag, getGenderIcon } from '../../utils/profileUtils';
import { soundscapeEngine, SoundscapeType } from '../../utils/soundscapes';
import { hapticTap } from '../../utils/haptics';

interface LoungeTabProps {
  rooms: ChatRoom[];
  users: UserProfile[];
  onOpenProfile: (user: UserProfile) => void;
  currentUser: { name: string; role: 'owner' | 'admin' | 'member'; isHidden: boolean };
  theme: ThemeConfig;
}

export default function LoungeTab({
  rooms,
  users,
  onOpenProfile,
  currentUser,
  theme
}: LoungeTabProps) {
  // Navigation inside Lounge: null = main 4-card list; otherwise roomId
  const [activeRoomId, setActiveRoomId] = useState<number | null>(null);
  const [showMembersList, setShowMembersList] = useState<boolean>(false);
  const [memberSearchQuery, setMemberSearchQuery] = useState<string>('');

  // Ambient Soundscapes state (lo-fi chill beats, cafe rain, neon synthwave)
  const [activeSoundscape, setActiveSoundscape] = useState<SoundscapeType>('none');

  useEffect(() => {
    return () => {
      soundscapeEngine.stop();
    };
  }, []);

  const handleToggleSoundscape = (type: SoundscapeType) => {
    hapticTap(10);
    if (activeSoundscape === type) {
      soundscapeEngine.stop();
      setActiveSoundscape('none');
    } else {
      soundscapeEngine.setSoundscape(type, 0.22);
      setActiveSoundscape(type);
    }
  };

  // VIP Room Passcode state
  const [vipUnlocked, setVipUnlocked] = useState<boolean>(currentUser.role === 'owner' || currentUser.role === 'admin');
  const [showVipPinModal, setShowVipPinModal] = useState<boolean>(false);
  const [vipPinInput, setVipPinInput] = useState<string>('');
  const [vipPinError, setVipPinError] = useState<string>('');

  // Voice room live interactive states
  const [isMicMuted, setIsMicMuted] = useState<boolean>(true);
  const [isHandRaised, setIsHandRaised] = useState<boolean>(false);
  const [voiceReactions, setVoiceReactions] = useState<{ id: number; emoji: string }[]>([]);

  // Room messages state
  const [roomMessages, setRoomMessages] = useState<Record<number, ChatMessage[]>>({
    1: [
      { id: 11, sender: 'Chloe Dubois', text: 'Welcome to the Live Voice Room! Audio stage is live.', timestamp: '4:10 PM' },
      { id: 12, sender: 'Lucas Silva', text: 'Crystal clear spatial sound on this frequency.', timestamp: '4:12 PM' }
    ],
    2: [
      { id: 21, sender: 'Kenji Sato', text: 'Hello everyone! Welcome to Public Chat Room 1.', timestamp: '3:45 PM' },
      { id: 22, sender: 'Elena Rostova', text: 'Discussing global social trends and new tech designs today.', timestamp: '3:50 PM' },
      { id: 23, sender: 'Lucas Silva', text: 'Who wants to challenge me in chess later?', timestamp: '4:02 PM' }
    ],
    3: [
      { id: 31, sender: 'Chloe Dubois', text: 'Welcome to International Creative Hub (Public Room 2)!', timestamp: '2:30 PM' },
      { id: 32, sender: 'Elena Rostova', text: 'Sharing photo portfolios, doodles, and UI concepts here.', timestamp: '2:35 PM' }
    ],
    4: [
      { id: 41, sender: 'Zavier', text: 'Welcome to the VIP Founder & High-Rollers Lounge.', timestamp: '1:00 PM' },
      { id: 42, sender: 'Chloe Dubois', text: 'Elite access only. Private discussions & updates.', timestamp: '1:15 PM' }
    ]
  });

  const [messageInput, setMessageInput] = useState<string>('');

  // Exactly 4 sleek room cards as requested:
  // 1. 🎙️ Voice Room
  // 2. 💬 Public Chat Room 1
  // 3. 🌐 Public Chat Room 2
  // 4. 🔒 Premium VIP Room
  const ROOM_DEFINITIONS = [
    {
      id: 1,
      title: 'Voice Room',
      subtitle: 'Spatial Live Audio Lounge',
      description: 'Hop on stage, speak live with worldwide members, or listen in high-fidelity.',
      icon: '🎙️',
      type: 'voice' as const,
      badge: 'Live Audio',
      color: 'from-rose-500/20 via-purple-500/10 to-indigo-500/20',
      activeCount: 48,
      speakers: ['Chloe Dubois', 'Lucas Silva', 'Kenji Sato']
    },
    {
      id: 2,
      title: 'Public Chat Room 1',
      subtitle: 'Global Chit-Chat & Trends',
      description: 'Open worldwide community discussion for instant messaging, sharing memes & arcade invites.',
      icon: '💬',
      type: 'text' as const,
      badge: 'Open Global',
      color: 'from-blue-500/20 via-cyan-500/10 to-indigo-500/20',
      activeCount: 114
    },
    {
      id: 3,
      title: 'Public Chat Room 2',
      subtitle: 'International Creative Hub',
      description: 'Secondary open global room focused on photo portfolios, design markups, and doodles.',
      icon: '🌐',
      type: 'text' as const,
      badge: 'Open Global',
      color: 'from-emerald-500/20 via-teal-500/10 to-cyan-500/20',
      activeCount: 76
    },
    {
      id: 4,
      title: 'Premium VIP Room',
      subtitle: 'Founders & Elite Members Only',
      description: 'Encrypted sanctuary for verified founders, VIP passholders, and executives.',
      icon: '🔒',
      type: 'vip' as const,
      badge: vipUnlocked ? 'VIP Unlocked' : 'Passcode Required',
      color: 'from-amber-500/25 via-yellow-500/10 to-purple-600/20',
      activeCount: 19
    }
  ];

  const currentRoom = ROOM_DEFINITIONS.find((r) => r.id === activeRoomId);

  // Active room members list
  const activeRoomMembers = users.filter((u) => !u.isHidden);
  const filteredMembers = activeRoomMembers.filter(
    (u) =>
      u.name.toLowerCase().includes(memberSearchQuery.toLowerCase()) ||
      u.handle.toLowerCase().includes(memberSearchQuery.toLowerCase()) ||
      u.country.toLowerCase().includes(memberSearchQuery.toLowerCase())
  );

  const handleOpenRoomCard = (room: (typeof ROOM_DEFINITIONS)[0]) => {
    if (room.id === 4 && !vipUnlocked && currentUser.role === 'member') {
      setShowVipPinModal(true);
      return;
    }
    setActiveRoomId(room.id);
  };

  const handleVerifyVipPin = () => {
    if (vipPinInput === '7777' || vipPinInput === '9999' || vipPinInput === '2024') {
      setVipUnlocked(true);
      setShowVipPinModal(false);
      setActiveRoomId(4);
      setVipPinError('');
    } else {
      setVipPinError('Invalid VIP Passcode. (Try 7777 or Owner Code 9999)');
    }
  };

  const handleSendMessage = () => {
    if (!messageInput.trim() || !activeRoomId) return;
    const newMsg: ChatMessage = {
      id: Date.now(),
      sender: currentUser.name,
      text: messageInput.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'seen'
    };
    setRoomMessages((prev) => ({
      ...prev,
      [activeRoomId]: [...(prev[activeRoomId] || []), newMsg]
    }));
    setMessageInput('');
  };

  const handleTriggerVoiceReaction = (emoji: string) => {
    const reactionId = Date.now() + Math.random();
    setVoiceReactions((prev) => [...prev, { id: reactionId, emoji }]);
    setTimeout(() => {
      setVoiceReactions((prev) => prev.filter((r) => r.id !== reactionId));
    }, 2000);
  };

  // -------------------------------------------------------------
  // VIEW 1: ACTIVE ROOM MEMBERS LIST (100% FULL-SCREEN PAGE)
  // -------------------------------------------------------------
  if (showMembersList && currentRoom) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col bg-slate-950 text-white select-none animate-in slide-in-from-right duration-300">
        {/* Header Bar */}
        <div className="h-16 px-4 flex items-center justify-between border-b border-white/10 bg-slate-900/90 backdrop-blur-2xl shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowMembersList(false)}
              className="p-2 rounded-2xl bg-white/5 hover:bg-white/10 active:scale-95 transition text-gray-300"
              title="Return to room"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>Room Members</span>
                <span className="text-[11px] font-mono text-indigo-400">({activeRoomMembers.length})</span>
              </h2>
              <p className="text-[10px] text-gray-400">{currentRoom.title}</p>
            </div>
          </div>

          <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            {activeRoomMembers.filter((u) => u.online).length} Online
          </span>
        </div>

        {/* Member Search Bar */}
        <div className="p-3 bg-black/30 border-b border-white/5">
          <input
            type="text"
            placeholder="Search members by name, handle, or country..."
            value={memberSearchQuery}
            onChange={(e) => setMemberSearchQuery(e.target.value)}
            className="w-full px-4 py-2.5 rounded-2xl bg-white/5 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Members Clean List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {filteredMembers.map((member) => (
            <div
              key={member.id}
              onClick={() => {
                setShowMembersList(false);
                onOpenProfile(member);
              }}
              className="p-3.5 rounded-3xl bg-white/[0.04] hover:bg-white/[0.08] active:scale-[0.98] transition-all cursor-pointer flex items-center justify-between gap-3 shadow-md border border-white/5 group"
            >
              {/* Left Profile Avatar */}
              <div className="flex items-center gap-3.5 min-w-0">
                <div className="relative shrink-0">
                  <div className={`w-13 h-13 rounded-2xl ${member.avatarBg || 'bg-indigo-600'} overflow-hidden flex items-center justify-center font-bold text-base text-white shadow-lg border border-white/10`}>
                    {member.avatarUrl ? (
                      <img src={member.avatarUrl} alt={member.name} className="w-full h-full object-cover" />
                    ) : (
                      member.name[0]
                    )}
                  </div>
                  <div className={`w-3.5 h-3.5 rounded-full absolute -bottom-0.5 -right-0.5 border-2 border-slate-950 ${
                    member.online ? 'bg-emerald-400 animate-pulse' : 'bg-gray-500'
                  }`} />
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-white truncate group-hover:text-indigo-300 transition-colors">
                      {member.name}
                    </h4>
                    {/* Country Flag & Gender */}
                    <span className="text-base select-none" title={member.country}>
                      {getCountryFlag(member.countryCode || member.country)}
                    </span>
                    <span className="text-xs text-gray-400">
                      {getGenderIcon(member.gender)}
                    </span>
                  </div>
                  <p className="text-xs font-mono text-indigo-400 truncate">
                    {member.handle}
                  </p>
                  <p className="text-[11px] text-gray-400 truncate mt-0.5">
                    {member.bio || 'EchoTalk Community Explorer'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/5 text-gray-400 border border-white/10">
                  {member.role === 'owner' ? '👑 Owner' : member.role === 'admin' ? '🛡️ Admin' : 'Member'}
                </span>
                <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-white transition" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // VIEW 2: DEDICATED 100% FULL-SCREEN ROOM VIEW
  // -------------------------------------------------------------
  if (activeRoomId && currentRoom) {
    const messages = roomMessages[activeRoomId] || [];

    return (
      <div className="fixed inset-0 z-40 flex flex-col bg-slate-950 text-white select-none animate-in slide-in-from-bottom duration-300">
        {/* Dedicated Room Header */}
        <div className="h-16 px-4 flex items-center justify-between border-b border-white/10 bg-slate-900/90 backdrop-blur-2xl shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveRoomId(null)}
              className="p-2 rounded-2xl bg-white/5 hover:bg-white/10 active:scale-95 transition text-gray-300"
              title="Back to Lounge list"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <span className="text-xl">{currentRoom.icon}</span>
              <div>
                <h3 className="text-sm font-bold text-white tracking-tight leading-tight">
                  {currentRoom.title}
                </h3>
                <span className="text-[10px] text-gray-400 block">{currentRoom.subtitle}</span>
              </div>
            </div>
          </div>

          {/* Top-Right: 👥 Group Members Icon */}
          <button
            onClick={() => setShowMembersList(true)}
            className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-95 transition text-indigo-300 flex items-center gap-1.5 shadow"
            title="View Active Members"
          >
            <Users className="w-4 h-4" />
            <span className="text-xs font-bold hidden sm:inline">Members ({currentRoom.activeCount})</span>
          </button>
        </div>

        {/* Content area: Tailored for Voice vs Text rooms */}
        {currentRoom.type === 'voice' ? (
          /* DEDICATED LIVE AUDIO LOUNGE SCREEN */
          <div className="flex-1 flex flex-col justify-between p-4 sm:p-6 overflow-y-auto relative">
            {/* Ambient Background Wave & Visualizer */}
            <div className="absolute inset-0 bg-radial-gradient from-indigo-900/20 via-transparent to-transparent pointer-events-none" />

            {/* Floating Audio Emojis */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              {voiceReactions.map((r) => (
                <div
                  key={r.id}
                  className="absolute bottom-24 right-8 text-3xl animate-bounce"
                  style={{ animationDuration: '1.2s' }}
                >
                  {r.emoji}
                </div>
              ))}
            </div>

            {/* Stage Speakers Display */}
            <div className="space-y-4 relative z-10">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-1.5">
                  <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
                  <span>Live Speakers on Stage</span>
                </span>
                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>HD Spatial Audio</span>
                </span>
              </div>

              {/* Speakers Circular/Card Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {/* Current User Pod */}
                <div className="p-4 rounded-3xl bg-white/[0.06] border border-white/10 backdrop-blur-xl flex flex-col items-center text-center space-y-2 shadow-xl">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-xl text-white shadow-lg">
                      {currentUser.name[0]}
                    </div>
                    <div className={`w-5 h-5 rounded-full absolute -bottom-0.5 -right-0.5 border-2 border-slate-950 flex items-center justify-center ${
                      isMicMuted ? 'bg-rose-500' : 'bg-emerald-400 animate-pulse'
                    }`}>
                      {isMicMuted ? <MicOff className="w-3 h-3 text-white" /> : <Mic className="w-3 h-3 text-slate-950" />}
                    </div>
                  </div>
                  <span className="text-xs font-bold text-white">You</span>
                  <span className="text-[10px] text-indigo-400 font-mono">Stage Pod</span>
                </div>

                {/* Other Speakers */}
                {[
                  { name: 'Chloe Dubois', avatar: '/src/assets/images/avatar_chloe_dubois_1792623177921.jpg', bg: 'bg-indigo-600', isSpeaking: true },
                  { name: 'Lucas Silva', avatar: '/src/assets/images/avatar_lucas_silva_1792623191727.jpg', bg: 'bg-emerald-600', isSpeaking: false },
                  { name: 'Kenji Sato', avatar: '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg', bg: 'bg-purple-600', isSpeaking: true }
                ].map((sp, idx) => (
                  <div
                    key={idx}
                    className={`p-4 rounded-3xl bg-white/[0.04] border backdrop-blur-xl flex flex-col items-center text-center space-y-2 shadow-lg transition-all ${
                      sp.isSpeaking ? 'border-emerald-400/60 ring-4 ring-emerald-500/20' : 'border-white/5'
                    }`}
                  >
                    <div className="relative">
                      <div className="w-16 h-16 rounded-full overflow-hidden flex items-center justify-center font-bold text-xl text-white shadow">
                        <img src={sp.avatar} alt={sp.name} className="w-full h-full object-cover" />
                      </div>
                      {sp.isSpeaking && (
                        <div className="w-4 h-4 rounded-full bg-emerald-400 absolute -top-1 -right-1 border-2 border-slate-950 animate-ping" />
                      )}
                    </div>
                    <span className="text-xs font-bold text-gray-200 truncate max-w-[100px]">{sp.name}</span>
                    <span className="text-[10px] text-gray-400 font-mono">Speaker</span>
                  </div>
                ))}
              </div>

              {/* Audio Waveform Spectrum */}
              <div className="p-4 rounded-3xl bg-black/40 border border-white/5 flex items-center justify-between gap-4 mt-6">
                <div className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs text-gray-300 font-mono">Chloe Dubois is speaking</span>
                </div>
                <div className="flex items-center gap-1 h-6">
                  {[6, 14, 22, 12, 18, 8, 16, 24, 10, 20, 14, 18, 10].map((h, i) => (
                    <div
                      key={i}
                      style={{ height: `${h}px` }}
                      className="w-1 rounded-full bg-indigo-400 animate-pulse"
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Dedicated Voice Room Bottom Dock */}
            <div className="pt-6 relative z-10 flex flex-col gap-3">
              {/* Quick Reactions Bar */}
              <div className="flex items-center justify-center gap-2">
                {['👏', '🔥', '❤️', '🚀', '🎉', '💯'].map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => handleTriggerVoiceReaction(emoji)}
                    className="w-10 h-10 rounded-2xl bg-white/5 hover:bg-white/15 active:scale-90 transition text-lg flex items-center justify-center border border-white/5"
                  >
                    {emoji}
                  </button>
                ))}
              </div>

              {/* Microphone & Hand Controls */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsMicMuted(!isMicMuted)}
                  className={`flex-1 py-4 rounded-3xl font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-2xl ${
                    isMicMuted
                      ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/30'
                      : 'bg-emerald-500 text-slate-950 shadow-emerald-500/30'
                  }`}
                >
                  {isMicMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5 animate-pulse" />}
                  <span className="text-sm">{isMicMuted ? 'Unmute Mic' : 'Mic Live & Active'}</span>
                </button>

                <button
                  onClick={() => setIsHandRaised(!isHandRaised)}
                  className={`px-5 py-4 rounded-3xl font-semibold text-xs transition active:scale-95 border ${
                    isHandRaised
                      ? 'bg-amber-400 text-slate-950 font-bold border-amber-300'
                      : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
                  }`}
                >
                  {isHandRaised ? '✋ Hand Raised' : '✋ Raise Hand'}
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* DEDICATED FULL-SCREEN TEXT CHAT ROOM (Room 2, 3, or VIP Room 4) */
          <div className="flex-1 flex flex-col justify-between overflow-hidden">
            {/* Messages Feed */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((m) => {
                const isMe = m.sender === currentUser.name;
                return (
                  <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                    <span className="text-[10px] text-gray-400 px-1 mb-1 font-medium">
                      {m.sender} · {m.timestamp}
                    </span>
                    <div
                      className={`max-w-[80%] rounded-2xl p-3 text-xs leading-relaxed shadow-md ${
                        isMe ? 'bg-indigo-600 text-white' : 'bg-white/10 text-gray-100 border border-white/5'
                      }`}
                    >
                      {m.text}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Input Bar */}
            <div className="p-3 bg-slate-900/80 border-t border-white/10 flex items-center gap-2">
              <input
                type="text"
                placeholder={`Message ${currentRoom.title}...`}
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 px-4 py-3 rounded-2xl bg-white/5 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500"
              />
              <button
                onClick={handleSendMessage}
                className="p-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white transition shadow-md"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // -------------------------------------------------------------
  // VIEW 3: MAIN LOUNGE LIST (EXACTLY 4 SLEEK MINIMAL ROOM CARDS)
  // -------------------------------------------------------------
  return (
    <div className="p-4 sm:p-6 space-y-5 max-w-2xl mx-auto select-none">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
            <Radio className="w-5 h-5 text-indigo-400 animate-pulse" />
            <span>EchoTalk Lounge</span>
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            Select a dedicated full-screen lounge or community channel
          </p>
        </div>
        <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>4 Live Lounges</span>
        </span>
      </div>

      {/* Ambient Soundscapes Selector Bar (Web Audio API) */}
      <div className="p-3.5 rounded-3xl bg-slate-900/90 border border-white/10 backdrop-blur-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xl">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-indigo-500/15 border border-indigo-400/20 flex items-center justify-center text-indigo-400">
            <Headphones className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <span className="text-xs font-bold text-white block">Ambient Soundscapes</span>
            <span className="text-[10px] text-gray-400">Atmospheric background audio for voice & chats</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
          {[
            { id: 'none' as const, label: 'Off', icon: '🔇' },
            { id: 'lofi' as const, label: 'Lo-Fi Chill', icon: '🎧' },
            { id: 'rain' as const, label: 'Cafe Rain', icon: '🌧️' },
            { id: 'synthwave' as const, label: 'Synthwave', icon: '🌆' }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => handleToggleSoundscape(item.id)}
              className={`px-3 py-1.5 rounded-2xl text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 shrink-0 ${
                activeSoundscape === item.id
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border border-indigo-400/40'
                  : 'bg-white/5 hover:bg-white/10 text-gray-300 border border-white/5'
              }`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Exactly 4 Sleek Minimal Room Cards */}
      <div className="grid grid-cols-1 gap-4">
        {ROOM_DEFINITIONS.map((room) => {
          return (
            <div
              key={room.id}
              onClick={() => handleOpenRoomCard(room)}
              className="relative p-5 rounded-3xl bg-white/[0.04] hover:bg-white/[0.08] active:scale-[0.98] border border-white/10 transition-all duration-200 cursor-pointer shadow-xl overflow-hidden group flex flex-col justify-between"
            >
              {/* Subtle Ambient Color Glow */}
              <div className={`absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-gradient-to-br ${room.color} blur-3xl pointer-events-none group-hover:scale-125 transition-transform duration-500`} />

              <div className="flex items-start justify-between gap-4 relative z-10">
                <div className="flex items-start gap-4">
                  {/* Big Room Icon */}
                  <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-2xl shadow-inner shrink-0 group-hover:scale-105 transition-transform">
                    {room.icon}
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-black text-white group-hover:text-indigo-300 transition-colors">
                        {room.title}
                      </h3>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/10 text-gray-300 border border-white/10">
                        {room.badge}
                      </span>
                    </div>

                    <p className="text-xs text-indigo-300/90 font-medium">
                      {room.subtitle}
                    </p>

                    <p className="text-xs text-gray-400 leading-relaxed max-w-md pt-0.5">
                      {room.description}
                    </p>
                  </div>
                </div>

                {/* Right Arrow / Lock */}
                <div className="p-2.5 rounded-2xl bg-white/5 group-hover:bg-white/15 text-gray-300 transition shrink-0">
                  <ChevronRight className="w-5 h-5" />
                </div>
              </div>

              {/* Bottom Room Meta */}
              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-gray-400 relative z-10">
                <span className="flex items-center gap-1.5 font-mono text-[11px]">
                  <Users className="w-3.5 h-3.5 text-gray-500" />
                  <span>{room.activeCount} active inside</span>
                </span>

                <span className="text-[11px] font-bold text-indigo-400 group-hover:translate-x-0.5 transition-transform">
                  Tap to enter 100% full-screen →
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* VIP PASSCODE MODAL */}
      {showVipPinModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-2xl flex items-center justify-center p-4">
          <div className="w-full max-w-xs rounded-3xl bg-slate-900 border border-white/20 p-6 text-center space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center mx-auto shadow-lg">
              <Lock className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-base font-black text-white">VIP Room Locked</h3>
              <p className="text-xs text-gray-400 mt-1">
                Enter the 4-digit VIP passkey to enter the Founders lounge (Passcode: 7777).
              </p>
            </div>

            <input
              type="text"
              maxLength={4}
              value={vipPinInput}
              onChange={(e) => setVipPinInput(e.target.value.replace(/\D/g, ''))}
              placeholder="••••"
              className="w-full text-center text-xl font-mono tracking-widest py-2.5 rounded-2xl bg-black/50 border border-white/15 text-amber-300 focus:outline-none focus:border-amber-400"
            />

            {vipPinError && (
              <span className="text-[11px] text-rose-400 block font-medium">
                {vipPinError}
              </span>
            )}

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleVerifyVipPin}
                className="flex-1 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg active:scale-95 transition"
              >
                Unlock Lounge
              </button>
              <button
                onClick={() => {
                  setShowVipPinModal(false);
                  setVipPinError('');
                }}
                className="px-4 py-3 rounded-2xl bg-white/10 text-gray-300 text-xs font-semibold"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
