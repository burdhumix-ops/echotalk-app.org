import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, Users, Trophy, Sparkles, Play, Flame, Shield, Info, X, 
  Mic, MicOff, Volume2, Eye, Radio, Send, Crown
} from 'lucide-react';
import { ThemeConfig } from '../../types';
import ChessGame from '../games/ChessGame';
import LudoGame from '../games/LudoGame';
import MafiaGame from '../games/MafiaGame';
import ErrorBoundary from '../common/ErrorBoundary';
import { hapticDoublePulse, hapticHeavyBump, hapticTap } from '../../utils/haptics';

interface GamesTabProps {
  theme: ThemeConfig;
  onLaunchChallenge?: (game: 'chess' | 'ludo') => void;
}

interface GameItem {
  id: 'chess' | 'ludo' | 'mafia';
  title: string;
  category: string;
  players: string;
  logo: string;
  onlineCount: string;
  rating: string;
  rules: string;
  specs: string[];
  description: string;
}

interface LiveSpectatorMatch {
  id: string;
  game: 'chess' | 'ludo';
  player1: { name: string; avatar: string; score: string };
  player2: { name: string; avatar: string; score: string };
  spectatorCount: number;
  status: string;
}

const ARCADE_GAMES: GameItem[] = [
  {
    id: 'chess',
    title: 'Chess Classic',
    category: 'Grandmaster Strategy',
    players: '1-2 Players',
    logo: '/src/assets/images/game_chess_icon_1792618103123.jpg',
    onlineCount: '1,420 Online',
    rating: '4.9 ★',
    rules: 'Checkmate opponent king with legal moves, castling, en passant, and strategic positional control.',
    specs: ['Legal Move Engine', 'AI Novice to Grandmaster', '1v1 In-DM Duels'],
    description: 'Master the 64-square battlefield with custom move calculations, intelligent evaluation, and smooth piece animations.'
  },
  {
    id: 'ludo',
    title: 'Ludo Master',
    category: '3D Dice & Race',
    players: '2-4 Players',
    logo: '/src/assets/images/game_ludo_icon_1792618102891.jpg',
    onlineCount: '2,850 Online',
    rating: '4.8 ★',
    rules: 'Roll 6 to leave base. Navigate all 4 tokens around track to center home column. Capture rivals to send them home!',
    specs: ['3D Corner Base Dice', 'Safe Zones & Bonus 6s', 'Audio Haptics'],
    description: 'Authentic 15x15 board with 3D rolling corner dice directly in active player bases, real token captures, and home race.'
  },
  {
    id: 'mafia',
    title: 'Mafia Party Host',
    category: 'Social Mystery Party',
    players: '4-8 Players',
    logo: '/src/assets/images/game_mafia_icon_1792618103161.jpg',
    onlineCount: '980 Online',
    rating: '4.9 ★',
    rules: 'Day trials vote out suspects. Night mafia secretly strikes. Detectives investigate and Doctors shield innocent citizens.',
    specs: ['Secret Role Dealer', 'Day/Night Trials Engine', 'Real-time Ballots'],
    description: 'Roundtable party host dealing private syndicate, detective, and doctor roles with automated trial voting and countdowns.'
  }
];

const LIVE_MATCHES: LiveSpectatorMatch[] = [
  {
    id: 'match-1',
    game: 'chess',
    player1: { name: 'Lucas Silva', avatar: '/src/assets/images/avatar_lucas_silva_1792623191727.jpg', score: '1420' },
    player2: { name: 'Chloe Dubois', avatar: '/src/assets/images/avatar_chloe_dubois_1792623177921.jpg', score: '1390' },
    spectatorCount: 42,
    status: 'Move 24 · Black in Check'
  },
  {
    id: 'match-2',
    game: 'ludo',
    player1: { name: 'Maya Lin', avatar: '/src/assets/images/avatar_maya_lin_1792623223019.jpg', score: 'Leader' },
    player2: { name: 'David Thorne', avatar: '/src/assets/images/avatar_david_thorne_1792623223399.jpg', score: 'Chasing' },
    spectatorCount: 88,
    status: 'Final Stretch · 2 Tokens Home'
  }
];

export default function GamesTab({ theme }: GamesTabProps) {
  const [fullScreenActiveGame, setFullScreenActiveGame] = useState<'chess' | 'ludo' | 'mafia' | null>(null);
  const [spectatingMatch, setSpectatingMatch] = useState<LiveSpectatorMatch | null>(null);
  
  // Instant Touch-and-Hold Peek State (Zero Delay)
  const [pressingGameId, setPressingGameId] = useState<string | null>(null);
  const [peekedGame, setPeekedGame] = useState<GameItem | null>(null);
  const pressStartTime = useRef<number>(0);

  // In-Game Voice Chat State
  const [isVoiceMuted, setIsVoiceMuted] = useState<boolean>(false);
  const [floatingTaunts, setFloatingTaunts] = useState<{ id: number; emoji: string; x: number }[]>([]);

  // Instant Touch-and-Hold: Trigger the exact millisecond user touches down
  const handlePointerDown = (game: GameItem, e: React.PointerEvent) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;

    pressStartTime.current = Date.now();
    setPressingGameId(game.id);
    
    // Exact millisecond touch-and-hold response (zero artificial delay)
    setPeekedGame(game);
    hapticTap(15);
  };

  // Instant Release: Snap-back immediately on release, or quick-tap launch if < 200ms
  const handlePointerUp = (game: GameItem) => {
    const duration = Date.now() - pressStartTime.current;
    setPressingGameId(null);
    setPeekedGame(null);

    if (duration < 200) {
      // Quick Tap Launch (< 200ms opens full-screen game directly)
      hapticHeavyBump();
      setFullScreenActiveGame(game.id);
    }
  };

  const handlePointerCancel = () => {
    setPressingGameId(null);
    setPeekedGame(null);
  };

  // Send spectator emoji taunt floating across the board
  const triggerEmojiTaunt = (emoji: string) => {
    hapticDoublePulse();
    const newTaunt = {
      id: Date.now() + Math.random(),
      emoji,
      x: 20 + Math.random() * 60
    };
    setFloatingTaunts((prev) => [...prev, newTaunt]);
    setTimeout(() => {
      setFloatingTaunts((prev) => prev.filter((t) => t.id !== newTaunt.id));
    }, 1800);
  };

  // --- FULL-SCREEN GAME ENGINE OR SPECTATOR VIEW ---
  if (fullScreenActiveGame || spectatingMatch) {
    const activeInfo = ARCADE_GAMES.find((g) => g.id === fullScreenActiveGame);
    const currentGameId = fullScreenActiveGame || spectatingMatch?.game || 'chess';

    return (
      <div className={`fixed inset-0 z-50 flex flex-col ${theme.bg} ${theme.text} select-none animate-in fade-in duration-200 overflow-hidden gpu-accelerated`}>
        {/* Header Bar with Live Voice Bar */}
        <header className={`h-16 px-4 flex items-center justify-between border-b ${theme.border} ${theme.surface} frosted-glass shrink-0 z-30`}>
          <button
            onClick={() => {
              setFullScreenActiveGame(null);
              setSpectatingMatch(null);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition active:scale-95"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Arcade Hub</span>
          </button>

          <div className="text-center">
            <h2 className="text-sm font-bold text-white tracking-tight">
              {spectatingMatch ? `Spectating: ${spectatingMatch.player1.name} vs ${spectatingMatch.player2.name}` : activeInfo?.title}
            </h2>
            <span className="text-[10px] text-indigo-400 font-mono">
              {spectatingMatch ? `👁️ ${spectatingMatch.spectatorCount} Watching Live` : '100% Full-Screen Engine'}
            </span>
          </div>

          {/* Floating In-Game Live Voice Chat Toggle */}
          <button
            onClick={() => {
              hapticDoublePulse();
              setIsVoiceMuted(!isVoiceMuted);
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shadow border ${
              isVoiceMuted
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 animate-pulse'
            }`}
            title="Toggle In-Game Live Voice Bar"
          >
            {isVoiceMuted ? <MicOff className="w-3.5 h-3.5 text-amber-400" /> : <Mic className="w-3.5 h-3.5 text-emerald-400" />}
            <span className="hidden sm:inline font-mono">{isVoiceMuted ? 'Muted' : 'Voice ON'}</span>
          </button>
        </header>

        {/* Dedicated Game Engine View with Self-Healing ErrorBoundary */}
        <div className="flex-1 overflow-y-auto p-4 flex items-center justify-center relative overscroll-none">
          <div className="w-full max-w-md relative">
            
            {/* Animated Floating Emoji Taunts Floating Across The Board */}
            <div className="absolute inset-0 pointer-events-none z-40 overflow-hidden">
              {floatingTaunts.map((t) => (
                <div
                  key={t.id}
                  style={{ left: `${t.x}%` }}
                  className="absolute bottom-6 text-3xl animate-[floatUp_1.8s_ease-out_forwards] select-none"
                >
                  {t.emoji}
                </div>
              ))}
            </div>

            <ErrorBoundary componentName={`GameEngine-${currentGameId}`} fallbackTitle="Arcade Engine Recovery">
              {currentGameId === 'chess' && (
                <ChessGame theme={theme} isFullScreen={true} onClose={() => { setFullScreenActiveGame(null); setSpectatingMatch(null); }} />
              )}
              {currentGameId === 'ludo' && (
                <LudoGame theme={theme} isFullScreen={true} onClose={() => { setFullScreenActiveGame(null); setSpectatingMatch(null); }} />
              )}
              {currentGameId === 'mafia' && (
                <MafiaGame theme={theme} onClose={() => { setFullScreenActiveGame(null); setSpectatingMatch(null); }} />
              )}
            </ErrorBoundary>

            {/* Spectator Emoji Taunt Dock if Spectating */}
            {spectatingMatch && (
              <div className="mt-3 p-2.5 rounded-2xl bg-black/60 backdrop-blur-md border border-white/10 flex items-center justify-between gap-2 shadow-2xl">
                <span className="text-[10px] text-gray-400 font-mono flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  <span>Send Taunt:</span>
                </span>
                <div className="flex items-center gap-2">
                  {['🔥', '👏', '😱', '👑', '🎯'].map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => triggerEmojiTaunt(emoji)}
                      className="text-lg p-1 hover:scale-130 active:scale-90 transition-transform"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-lg mx-auto flex flex-col items-center select-none gpu-accelerated min-h-[75vh] justify-center space-y-6">
      
      {/* Subtle Hint */}
      <div className="text-center space-y-1">
        <h1 className="text-lg font-black tracking-tight text-white flex items-center justify-center gap-2">
          <span>Arcade Hub</span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            Instant Hold-to-Peek · Tap to Play
          </span>
        </h1>
        <p className="text-xs text-gray-400">
          Touch & hold for zero-delay specs peek · Quick tap to launch
        </p>
      </div>

      {/* CLEAN MINIMALIST ARCADE GRID: Icon-Only Layout for Chess, Ludo, Mafia */}
      <div className="grid grid-cols-3 gap-4 sm:gap-6 w-full max-w-md justify-center">
        {ARCADE_GAMES.map((game) => {
          const isPressing = pressingGameId === game.id;

          return (
            <div
              key={game.id}
              className="flex flex-col items-center gap-2.5 relative touch-none"
              onPointerDown={(e) => handlePointerDown(game, e)}
              onPointerUp={() => handlePointerUp(game)}
              onPointerLeave={handlePointerCancel}
              onPointerCancel={handlePointerCancel}
            >
              {/* Clean High-Resolution Game Logo Container with scale(1.05) Spring Animation */}
              <div
                className={`relative w-24 h-24 sm:w-28 sm:h-28 rounded-3xl overflow-hidden cursor-pointer shadow-xl border border-white/15 bg-slate-900 transition-all duration-200 ease-[cubic-bezier(0.34,1.56,0.64,1)] gpu-accelerated ${
                  isPressing
                    ? 'scale-[1.05] ring-4 ring-indigo-500/60 shadow-indigo-500/30'
                    : 'hover:scale-105 active:scale-95 hover:border-white/30'
                }`}
                style={{
                  willChange: 'transform, opacity'
                }}
              >
                <img
                  src={game.logo}
                  alt={game.title}
                  draggable={false}
                  className="w-full h-full object-cover select-none pointer-events-none"
                />

                {/* Subtle Glassmorphism Shine Reflection */}
                <div className="absolute inset-0 bg-gradient-to-tr from-black/40 via-transparent to-white/20 pointer-events-none" />

                {/* Instant Active Ring */}
                {isPressing && (
                  <div className="absolute inset-0 rounded-3xl border-2 border-indigo-400 animate-pulse pointer-events-none" />
                )}
              </div>

              {/* Minimal Clean Label */}
              <span className="text-xs font-bold text-gray-200 tracking-tight text-center truncate max-w-full">
                {game.title}
              </span>
            </div>
          );
        })}
      </div>

      {/* --- SPECTATOR MODE: LIVE FRIEND MATCHES --- */}
      <div className="w-full max-w-md pt-2 space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold uppercase tracking-wider text-gray-300 flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
            <span>Live Matches (Spectator Mode)</span>
          </span>
          <span className="text-[10px] font-mono text-indigo-400">Live Peer Stream</span>
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {LIVE_MATCHES.map((match) => (
            <div
              key={match.id}
              onClick={() => {
                hapticDoublePulse();
                setSpectatingMatch(match);
              }}
              className="p-3.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 flex items-center justify-between cursor-pointer transition active:scale-98 shadow-md"
            >
              <div className="flex items-center gap-3">
                <div className="flex -space-x-2">
                  <img src={match.player1.avatar} alt={match.player1.name} className="w-8 h-8 rounded-full border border-white/20 object-cover" />
                  <img src={match.player2.avatar} alt={match.player2.name} className="w-8 h-8 rounded-full border border-white/20 object-cover" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white tracking-tight flex items-center gap-1.5">
                    <span>{match.player1.name} vs {match.player2.name}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 font-mono">
                      {match.game === 'chess' ? 'Chess' : 'Ludo'}
                    </span>
                  </h4>
                  <span className="text-[10px] text-gray-400">{match.status}</span>
                </div>
              </div>

              <div className="flex items-center gap-1 text-[11px] font-mono font-bold text-rose-400 bg-rose-500/10 px-2.5 py-1 rounded-xl border border-rose-500/20">
                <Eye className="w-3.5 h-3.5" />
                <span>{match.spectatorCount}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* --- ELEGANT FLOATING GLASS OVERLAY PREVIEW CARD (Instant Touch-and-Hold Peek) --- */}
      {peekedGame && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in zoom-in-95 duration-100 select-none gpu-accelerated pointer-events-auto"
          onPointerUp={() => {
            // Instant snap-back on release
            setPeekedGame(null);
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm rounded-[32px] bg-slate-900/95 border border-white/20 p-5 shadow-2xl space-y-4 text-white relative backdrop-blur-2xl animate-in slide-in-from-bottom-4 duration-150"
          >
            {/* Header with High-Res Logo & Title */}
            <div className="flex items-center gap-3.5">
              <div className="w-16 h-16 rounded-2xl overflow-hidden border border-white/20 bg-black shadow-md shrink-0">
                <img
                  src={peekedGame.logo}
                  alt={peekedGame.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-black tracking-tight text-white truncate">
                    {peekedGame.title}
                  </h3>
                  <span className="text-xs font-mono font-bold text-amber-400">
                    {peekedGame.rating}
                  </span>
                </div>
                <p className="text-xs text-indigo-400 font-medium">
                  {peekedGame.category}
                </p>
                <div className="flex items-center gap-2 mt-1 text-[11px] font-mono text-emerald-400">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>{peekedGame.onlineCount}</span>
                </div>
              </div>
            </div>

            {/* Official Rules & Objective */}
            <div className="space-y-1 bg-white/5 p-3 rounded-2xl border border-white/5">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">
                Official Rules & Objective
              </span>
              <p className="text-xs text-gray-300 leading-relaxed">
                {peekedGame.rules}
              </p>
            </div>

            {/* Game Specs */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                Engine Specifications
              </span>
              <div className="flex flex-wrap gap-1.5">
                {peekedGame.specs.map((spec, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] px-2.5 py-1 rounded-xl bg-white/10 border border-white/10 text-gray-200 font-medium"
                  >
                    ✓ {spec}
                  </span>
                ))}
              </div>
            </div>

            {/* Primary 'Play Now' Action Button */}
            <div className="pt-2 flex gap-2">
              <button
                onClick={() => {
                  const id = peekedGame.id;
                  setPeekedGame(null);
                  hapticHeavyBump();
                  setFullScreenActiveGame(id);
                }}
                className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-900/50 transition"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Play Now</span>
              </button>
            </div>

            <p className="text-[10px] text-center text-gray-400">
              Release touch to close preview
            </p>
          </div>
        </div>
      )}

    </div>
  );
}
