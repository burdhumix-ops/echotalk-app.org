import React, { useState } from 'react';
import { 
  Mic, MicOff, Volume2, Users, Sparkles, MessageSquare, 
  Crown, Radio, ArrowRight, Share2, Shield, Settings2, Plus, Headphones
} from 'lucide-react';
import { ChatRoom, ThemeConfig } from '../../types';

interface RoomsTabProps {
  rooms: ChatRoom[];
  onOpenRoom: (room: ChatRoom) => void;
  onCreateRoom?: (room: { name: string; topic: string; isSpecial: boolean; locked: boolean; isVoiceRoom?: boolean }) => void;
  currentUser: { name: string; role: 'owner' | 'admin' | 'member' };
  theme: ThemeConfig;
}

const VOICE_PARTICIPANTS = [
  { name: 'Chloe Dubois', role: 'Speaker', isSpeaking: true, avatarBg: 'bg-indigo-600', seed: 'C' },
  { name: 'Lucas Silva', role: 'Speaker', isSpeaking: false, avatarBg: 'bg-emerald-600', seed: 'L' },
  { name: 'Kenji Sato', role: 'Speaker', isSpeaking: true, avatarBg: 'bg-purple-600', seed: 'K' },
  { name: 'Elena Rostova', role: 'Listener', isSpeaking: false, avatarBg: 'bg-rose-600', seed: 'E' },
  { name: 'Liam O’Connor', role: 'Listener', isSpeaking: false, avatarBg: 'bg-teal-600', seed: 'Li' }
];

export default function RoomsTab({
  rooms,
  onOpenRoom,
  onCreateRoom,
  currentUser,
  theme
}: RoomsTabProps) {
  const [isMicMuted, setIsMicMuted] = useState<boolean>(true);
  const [isHandRaised, setIsHandRaised] = useState<boolean>(false);
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [newRoomName, setNewRoomName] = useState<string>('');
  const [newRoomTopic, setNewRoomTopic] = useState<string>('');
  const [isVoiceToggle, setIsVoiceToggle] = useState<boolean>(true);

  // Default rooms catalogue if only 1 exists
  const allRooms: ChatRoom[] = rooms.length >= 3 ? rooms : [
    rooms[0] || {
      id: 1,
      name: 'Global Voice & Lo-Fi Lounge',
      topic: 'Worldwide live audio community lounge & lo-fi chillout session',
      isSpecial: true,
      locked: false,
      memberCount: 54,
      hostName: 'Chloe Dubois',
      messages: [],
      isVoiceRoom: true,
      activeSpeakers: 3
    },
    {
      id: 2,
      name: 'Tech & Architecture Stage',
      topic: 'Deep dives into distributed systems, TypeScript, and high-performance WebSockets',
      isSpecial: false,
      locked: false,
      memberCount: 38,
      hostName: 'Zavier',
      messages: [],
      isVoiceRoom: true,
      activeSpeakers: 2
    },
    {
      id: 3,
      name: 'Global Arcade Chat & Matchmaking',
      topic: 'Looking for 1v1 Chess and Ludo matches. Post your challenge links!',
      isSpecial: false,
      locked: false,
      memberCount: 82,
      hostName: 'Lucas Silva',
      messages: [],
      isVoiceRoom: false
    },
    {
      id: 4,
      name: 'Chill Ambient Radio & Doodles',
      topic: 'Draw together and share lo-fi music recommendations',
      isSpecial: false,
      locked: false,
      memberCount: 29,
      hostName: 'Chloe Dubois',
      messages: [],
      isVoiceRoom: true,
      activeSpeakers: 1
    }
  ];

  const mainRoom = allRooms[0];

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomName.trim()) return;
    if (onCreateRoom) {
      onCreateRoom({
        name: newRoomName.trim(),
        topic: newRoomTopic.trim() || 'Community discussion space',
        isSpecial: false,
        locked: false,
        isVoiceRoom: isVoiceToggle
      });
    }
    setNewRoomName('');
    setNewRoomTopic('');
    setShowCreateModal(false);
  };

  return (
    <div className="p-4 space-y-5 max-w-2xl mx-auto select-none">
      {/* Header */}
      <div className="flex items-center justify-between pb-1">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Radio className="w-5 h-5 text-rose-500 animate-pulse" />
            <span>EchoTalk Voice Space</span>
          </h2>
          <p className="text-xs text-gray-400">iOS minimal live audio lounges & community spaces</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCreateModal(true)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition active:scale-95"
            title="Create Space"
          >
            <Plus className="w-4 h-4" />
          </button>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-full flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Live Audio</span>
          </span>
        </div>
      </div>

      {/* SINGLE MINIMALIST iOS VOICE LOUNGE FEATURED CARD */}
      <div className={`rounded-3xl border ${theme.cardBorder} ${theme.card} p-5 space-y-5 shadow-2xl relative overflow-hidden`}>
        {/* Ambient Top Glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Lounge Card Header */}
        <div className="flex items-start justify-between gap-3 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] bg-gradient-to-r from-amber-500/20 to-rose-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-mono flex items-center gap-1">
                <Crown className="w-3 h-3 text-amber-400" />
                Featured Lounge
              </span>
              <span className="text-xs text-gray-400">· 54 Connected</span>
            </div>
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <span>{mainRoom.name}</span>
              <span title="Voice Room Active">🎙️</span>
            </h3>
            <p className="text-xs text-gray-400 max-w-md leading-relaxed">{mainRoom.topic}</p>
          </div>

          <button
            onClick={() => onOpenRoom(mainRoom)}
            className="px-3.5 py-2 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 shrink-0"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Chat ({mainRoom.messages?.length || 2})</span>
          </button>
        </div>

        {/* Live Audio Waveform Simulation Bar */}
        <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-indigo-400 shrink-0" />
            <span className="text-xs text-gray-300 font-medium truncate">
              Now Speaking: <strong className="text-white">Chloe Dubois & Kenji Sato</strong>
            </span>
          </div>

          <div className="flex items-center gap-1 h-5 shrink-0">
            {[4, 12, 8, 16, 6, 14, 18, 10, 15, 7, 13, 9].map((height, i) => (
              <div
                key={i}
                style={{ height: `${height}px` }}
                className="w-1 rounded-full bg-indigo-500 animate-pulse"
              />
            ))}
          </div>
        </div>

        {/* Live Participants Radial / Grid with Speaking Rings */}
        <div className="space-y-2">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide block">
            Stage Speakers & Listeners
          </span>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {/* Current User Card */}
            <div className="flex flex-col items-center text-center space-y-1.5 p-2 rounded-2xl bg-white/5 border border-white/10">
              <div className="relative">
                <div className={`w-12 h-12 rounded-2xl ${theme.accent} flex items-center justify-center font-bold text-sm text-white shadow-lg`}>
                  {currentUser.name[0]}
                </div>
                <div className={`w-4 h-4 rounded-full absolute -bottom-1 -right-1 border-2 border-slate-950 flex items-center justify-center ${
                  isMicMuted ? 'bg-rose-500' : 'bg-emerald-400'
                }`}>
                  {isMicMuted ? <MicOff className="w-2.5 h-2.5 text-white" /> : <Mic className="w-2.5 h-2.5 text-slate-950" />}
                </div>
              </div>
              <span className="text-xs font-semibold text-white truncate max-w-[70px]">You</span>
              <span className="text-[9px] text-indigo-400 font-mono">Stage</span>
            </div>

            {/* Other Stage Speakers */}
            {VOICE_PARTICIPANTS.map((p, idx) => (
              <div
                key={idx}
                className="flex flex-col items-center text-center space-y-1.5 p-2 rounded-2xl bg-white/5 border border-white/5 hover:border-white/20 transition"
              >
                <div className="relative">
                  <div className={`w-12 h-12 rounded-2xl ${p.avatarBg} flex items-center justify-center font-bold text-sm text-white shadow transition-all ${
                    p.isSpeaking ? 'ring-4 ring-emerald-400/60 scale-105 shadow-emerald-500/30' : ''
                  }`}>
                    {p.seed}
                  </div>
                  {p.isSpeaking && (
                    <div className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-slate-950 animate-ping" />
                  )}
                </div>
                <span className="text-xs font-semibold text-gray-200 truncate max-w-[70px]">
                  {p.name.split(' ')[0]}
                </span>
                <span className="text-[9px] text-gray-500 font-mono">{p.role}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Minimalist iOS Floating Voice Control Dock */}
        <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-3">
          {/* Mute Toggle Button */}
          <button
            onClick={() => setIsMicMuted(!isMicMuted)}
            className={`flex-1 py-3 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-lg ${
              isMicMuted
                ? 'bg-rose-600/80 hover:bg-rose-600 text-white border border-rose-500/40'
                : 'bg-emerald-500 text-slate-950 shadow-emerald-500/20'
            }`}
          >
            {isMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 animate-pulse" />}
            <span>{isMicMuted ? 'Unmute Mic' : 'Mic Active'}</span>
          </button>

          {/* Raise Hand Toggle */}
          <button
            onClick={() => setIsHandRaised(!isHandRaised)}
            className={`px-4 py-3 rounded-2xl text-xs font-semibold transition active:scale-95 ${
              isHandRaised
                ? 'bg-amber-400 text-slate-950 font-bold shadow-md'
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
          >
            <span>{isHandRaised ? '✋ Hand Raised' : '✋ Raise Hand'}</span>
          </button>

          {/* Enter Room Stream Button */}
          <button
            onClick={() => onOpenRoom(mainRoom)}
            className={`px-4 py-3 rounded-2xl ${theme.accent} text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition`}
          >
            <span>Open Chat</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ALL ROOMS & CHANNELS LIST VIEW WITH VOICE ROOM 🎙️ ICONS */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
            <Headphones className="w-4 h-4 text-indigo-400" />
            <span>Community Spaces & Lounges</span>
          </span>
          <span className="text-[11px] text-gray-500 font-mono">
            {allRooms.filter(r => r.isVoiceRoom !== false).length} Voice · {allRooms.filter(r => r.isVoiceRoom === false).length} Text
          </span>
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {allRooms.map((room) => {
            const isVoice = room.isVoiceRoom !== false;

            return (
              <div
                key={room.id}
                onClick={() => onOpenRoom(room)}
                className={`p-3.5 rounded-2xl border ${theme.cardBorder} ${theme.card} hover:border-white/20 transition-all cursor-pointer flex items-center justify-between gap-3 group shadow-md hover:scale-[1.01]`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  {/* Distinctive Room Icon Badge */}
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-inner ${
                    isVoice
                      ? 'bg-gradient-to-tr from-rose-500/20 to-purple-500/30 text-rose-300 border border-rose-500/30'
                      : 'bg-white/5 text-gray-300 border border-white/10'
                  }`}>
                    {isVoice ? (
                      <span className="text-lg" title="Live Voice Lounge">🎙️</span>
                    ) : (
                      <MessageSquare className="w-5 h-5 text-indigo-400" />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-white truncate group-hover:text-indigo-300 transition-colors">
                        {room.name}
                      </h4>
                      {/* Dedicated Voice Room Indicator Tag */}
                      {isVoice ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 shrink-0">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping" />
                          <span>🎙️ Voice Room</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/5 text-gray-400 border border-white/10 shrink-0">
                          💬 Text Channel
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-gray-400 truncate mt-0.5">
                      {room.topic}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className="text-right hidden sm:block">
                    <span className="text-[11px] font-mono text-gray-400 flex items-center gap-1 justify-end">
                      <Users className="w-3 h-3 text-gray-500" />
                      {room.memberCount || 12}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-white/5 group-hover:bg-white/10 text-gray-300 transition">
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal: Create Space */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateSubmit}
            className={`w-full max-w-sm rounded-3xl border ${theme.cardBorder} ${theme.card} p-5 space-y-4 shadow-2xl animate-in zoom-in-95`}
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Create New Lounge / Channel
              </span>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-gray-400 block mb-1 font-semibold">Space Name</label>
                <input
                  type="text"
                  value={newRoomName}
                  onChange={(e) => setNewRoomName(e.target.value)}
                  placeholder="e.g. Chill Music Hub"
                  className={`w-full px-3 py-2 rounded-xl ${theme.inputBg} border ${theme.border} text-white focus:outline-none focus:border-indigo-500`}
                />
              </div>

              <div>
                <label className="text-gray-400 block mb-1 font-semibold">Topic Description</label>
                <input
                  type="text"
                  value={newRoomTopic}
                  onChange={(e) => setNewRoomTopic(e.target.value)}
                  placeholder="e.g. Share favorite tunes and talk live"
                  className={`w-full px-3 py-2 rounded-xl ${theme.inputBg} border ${theme.border} text-white focus:outline-none focus:border-indigo-500`}
                />
              </div>

              {/* Voice vs Text Room Toggle */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-black/30 border border-white/10">
                <div className="space-y-0.5">
                  <span className="font-semibold text-white flex items-center gap-1.5">
                    <span>🎙️</span>
                    <span>Voice Room (Live Audio)</span>
                  </span>
                  <p className="text-[10px] text-gray-400">
                    Enable real-time audio microphone stage
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsVoiceToggle(!isVoiceToggle)}
                  className={`w-11 h-6 rounded-full p-0.5 transition-colors ${
                    isVoiceToggle ? 'bg-rose-500' : 'bg-white/20'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      isVoiceToggle ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="submit"
                className={`flex-1 py-2.5 rounded-xl ${theme.accent} text-white font-bold text-xs shadow-md`}
              >
                Create Space
              </button>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2.5 rounded-xl bg-white/10 text-gray-300 text-xs font-semibold"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
