import React, { useState } from 'react';
import { MessageSquare, ShieldAlert, Check, X, Ban, Clock, Sparkles } from 'lucide-react';
import { ChatMessage, ThemeConfig, UserProfile } from '../../types';

interface DMsTabProps {
  users: UserProfile[];
  dms: Record<number, ChatMessage[]>;
  onOpenDM: (user: UserProfile) => void;
  onAcceptRequest: (userId: number) => void;
  onDeclineRequest: (userId: number) => void;
  theme: ThemeConfig;
}

export default function DMsTab({
  users,
  dms,
  onOpenDM,
  onAcceptRequest,
  onDeclineRequest,
  theme
}: DMsTabProps) {
  const [subTab, setSubTab] = useState<'direct' | 'requests'>('direct');

  const friends = users.filter((u) => u.isFriend);
  const requests = users.filter((u) => !u.isFriend);

  return (
    <div className="p-4 space-y-4 max-w-2xl mx-auto">
      {/* Segmented Sub-Navigation Bar */}
      <div className="flex p-1 bg-black/30 rounded-2xl border border-white/5">
        <button
          onClick={() => setSubTab('direct')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
            subTab === 'direct' ? `${theme.accent} text-white shadow-md` : 'text-gray-400 hover:text-white'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Direct Messages</span>
        </button>

        <button
          onClick={() => setSubTab('requests')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
            subTab === 'requests' ? `${theme.accent} text-white shadow-md` : 'text-gray-400 hover:text-white'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Message Requests</span>
          {requests.length > 0 && (
            <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-mono flex items-center justify-center">
              {requests.length}
            </span>
          )}
        </button>
      </div>

      {/* DIRECT MESSAGES VIEW */}
      {subTab === 'direct' && (
        <div className="space-y-2.5">
          {friends.length === 0 ? (
            <div className="text-center py-16 text-gray-500 space-y-2">
              <MessageSquare className="w-8 h-8 mx-auto opacity-40 text-indigo-400" />
              <p className="text-xs">No active direct message threads yet.</p>
              <p className="text-[11px] text-gray-600">Start a chat from the Crew directory tab!</p>
            </div>
          ) : (
            friends.map((user) => {
              const thread = dms[user.id] || [];
              const lastMsg = thread[thread.length - 1];

              return (
                <div
                  key={user.id}
                  onClick={() => onOpenDM(user)}
                  className={`p-3.5 rounded-2xl border ${theme.cardBorder} ${theme.card} hover:bg-white/5 transition-all cursor-pointer flex items-center justify-between gap-3 group`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="relative shrink-0">
                      <div className={`w-11 h-11 rounded-2xl ${user.avatarBg || 'bg-purple-600'} overflow-hidden flex items-center justify-center font-bold text-sm text-white shadow border border-white/10`}>
                        {user.avatarUrl ? (
                          <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover" />
                        ) : (
                          user.name[0]
                        )}
                      </div>
                      <div
                        className={`w-3 h-3 rounded-full absolute -bottom-0.5 -right-0.5 border-2 border-slate-950 ${
                          user.online ? 'bg-emerald-400' : 'bg-gray-500'
                        }`}
                      />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-semibold text-white truncate">{user.name}</h3>
                        {lastMsg && (
                          <span className="text-[10px] text-gray-500 font-mono">
                            {lastMsg.timestamp}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-400 truncate mt-0.5">
                        {lastMsg ? (
                          lastMsg.isDoodle ? (
                            '🎨 [Instagram Doodle]'
                          ) : lastMsg.isViewOnce ? (
                            '🔥 [View-Once Photo]'
                          ) : lastMsg.isAudio ? (
                            '🎙️ [Audio Voice Note]'
                          ) : (
                            lastMsg.text
                          )
                        ) : (
                          'Tap to open direct conversation'
                        )}
                      </p>
                    </div>
                  </div>

                  <span className="text-xs text-indigo-400 group-hover:translate-x-1 transition-transform">
                    →
                  </span>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* MESSAGE REQUESTS VIEW (CAPPED AT 3) */}
      {subTab === 'requests' && (
        <div className="space-y-3">
          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300/90 leading-relaxed">
            <strong>EchoTalk Privacy Shield:</strong> Message requests allow non-crew contacts to send up to <strong>3 messages max</strong>. Accept the request to unlock continuous conversation or decline to discard.
          </div>

          {requests.length === 0 ? (
            <div className="text-center py-16 text-gray-500 space-y-2">
              <ShieldAlert className="w-8 h-8 mx-auto opacity-40 text-amber-400" />
              <p className="text-xs">No pending message requests.</p>
            </div>
          ) : (
            requests.map((user) => {
              const thread = dms[user.id] || [];
              const lastMsg = thread[thread.length - 1];
              const isCapped = user.reqCount >= 3;

              return (
                <div
                  key={user.id}
                  className={`p-3.5 rounded-2xl border ${theme.cardBorder} ${theme.card} space-y-3`}
                >
                  <div
                    onClick={() => onOpenDM(user)}
                    className="flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-2xl bg-amber-600/30 border border-amber-500/40 text-amber-300 overflow-hidden flex items-center justify-center font-bold text-sm shrink-0">
                        {user.avatarUrl ? (
                          <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover" />
                        ) : (
                          user.name[0]
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-white truncate">{user.name}</h4>
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                            isCapped
                              ? 'bg-red-500/20 text-red-300 border-red-500/40'
                              : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          }`}>
                            {user.reqCount}/3 messages {isCapped ? '(CAPPED)' : ''}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-400 truncate mt-0.5">
                          {user.country} · {lastMsg ? `"${lastMsg.text}"` : 'Sent an introductory message'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Accept / Decline Action Bar */}
                  <div className="flex gap-2 pt-1 border-t border-white/5">
                    <button
                      onClick={() => onAcceptRequest(user.id)}
                      className={`flex-1 py-2 rounded-xl ${theme.accent} text-white font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95`}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                      <span>Accept Request</span>
                    </button>
                    <button
                      onClick={() => onDeclineRequest(user.id)}
                      className="px-4 py-2 rounded-xl bg-white/10 hover:bg-rose-500/20 hover:text-rose-400 text-gray-300 text-xs font-semibold flex items-center gap-1 transition"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Decline</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
