import React, { useState } from 'react';
import { 
  Settings, Edit3, Eye, Plus, Camera, X, ShieldAlert, Sparkles, Check, Globe, Lock
} from 'lucide-react';
import { AdminVaultEntry, ThemeConfig, UserProfile } from '../../types';
import FullBleedProfileView from '../profile/FullBleedProfileView';

interface ProfileTabProps {
  currentUser: { 
    name: string; 
    handle?: string;
    role: 'owner' | 'admin' | 'member'; 
    isHidden: boolean; 
    bio: string;
    avatarColor?: string;
    avatarUrl?: string;
    portfolio?: string[];
    age?: number;
    country?: string;
    countryCode?: string;
    gender?: 'Male' | 'Female' | 'Non-binary';
  };
  setCurrentUser: React.Dispatch<React.SetStateAction<any>>;
  theme: ThemeConfig;
  adminVault: AdminVaultEntry[];
  onOpenVault: () => void;
  onOpenSettings: () => void;
}

export default function ProfileTab({
  currentUser,
  setCurrentUser,
  theme,
  adminVault,
  onOpenVault,
  onOpenSettings
}: ProfileTabProps) {
  const [showEditModal, setShowEditModal] = useState<boolean>(false);
  const [showPublicPreviewModal, setShowPublicPreviewModal] = useState<boolean>(false);

  // Edit fields
  const [editName, setEditName] = useState<string>(currentUser.name);
  const [editHandle, setEditHandle] = useState<string>(currentUser.handle || `@${currentUser.name.toLowerCase()}`);
  const [editBio, setEditBio] = useState<string>(currentUser.bio);
  const [editAge, setEditAge] = useState<number>(currentUser.age || 24);
  const [editGender, setEditGender] = useState<'Male' | 'Female' | 'Non-binary'>(currentUser.gender || 'Female');

  const profileUser: UserProfile = {
    id: 999,
    name: currentUser.name,
    handle: currentUser.handle || `@${currentUser.name.toLowerCase().replace(/\s+/g, '')}`,
    country: currentUser.country || 'United States',
    countryCode: currentUser.countryCode || 'US',
    gender: currentUser.gender || 'Female',
    online: true,
    isFriend: true,
    reqCount: 0,
    bio: currentUser.bio,
    avatarSeed: currentUser.name,
    avatarBg: currentUser.avatarColor || 'bg-indigo-600',
    role: currentUser.role,
    avatarUrl: currentUser.avatarUrl,
    portfolio: currentUser.portfolio,
    age: currentUser.age || 24,
    isHidden: currentUser.isHidden
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentUser((prev: any) => ({
      ...prev,
      name: editName.trim() || prev.name,
      handle: editHandle.trim().startsWith('@') ? editHandle.trim() : `@${editHandle.trim()}`,
      bio: editBio.trim() || prev.bio,
      age: Number(editAge) || 24,
      gender: editGender
    }));
    setShowEditModal(false);
  };

  return (
    <div className="w-full min-h-full flex flex-col relative">
      {/* Floating Action Header Bar */}
      <div className="px-4 py-2.5 bg-black/40 backdrop-blur-xl border-b border-white/10 flex items-center justify-between text-xs shrink-0 z-30">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setEditName(currentUser.name);
              setEditHandle(currentUser.handle || `@${currentUser.name.toLowerCase()}`);
              setEditBio(currentUser.bio);
              setEditAge(currentUser.age || 24);
              setEditGender(currentUser.gender || 'Female');
              setShowEditModal(true);
            }}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white font-semibold transition flex items-center gap-1.5"
          >
            <Edit3 className="w-3.5 h-3.5 text-indigo-400" />
            <span>Edit Profile & Age</span>
          </button>

          <button
            onClick={() => setShowPublicPreviewModal(true)}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white font-semibold transition flex items-center gap-1.5"
            title="Preview how your profile appears to other users"
          >
            <Eye className="w-3.5 h-3.5 text-emerald-400" />
            <span>Preview Profile</span>
          </button>
        </div>

        {currentUser.role === 'owner' && (
          <button
            onClick={onOpenVault}
            className="px-3 py-1.5 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold hover:bg-purple-500/30 transition flex items-center gap-1.5"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-purple-400" />
            <span>Vault ({adminVault.length})</span>
          </button>
        )}
      </div>

      {/* Main Full-Bleed Profile View */}
      <FullBleedProfileView
        user={profileUser}
        isCurrentUser={true}
        onOpenSettings={onOpenSettings}
        theme={theme}
        onUpdateCurrentUser={setCurrentUser}
      />

      {/* 100% FULL-SCREEN PREVIEW PROFILE MODAL */}
      {showPublicPreviewModal && (
        <div className="fixed inset-0 z-50 flex flex-col bg-slate-950 animate-in fade-in duration-200">
          <div className="h-14 px-4 bg-black/60 backdrop-blur-xl border-b border-white/10 flex items-center justify-between text-xs text-white shrink-0 z-30">
            <span className="font-bold font-mono text-emerald-400 flex items-center gap-1.5">
              <Eye className="w-4 h-4" />
              <span>Public Live Profile Preview</span>
            </span>
            <button
              onClick={() => setShowPublicPreviewModal(false)}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold"
            >
              Exit Preview
            </button>
          </div>

          <div className="flex-1 overflow-y-auto">
            <FullBleedProfileView
              user={profileUser}
              isCurrentUser={false}
              onClose={() => setShowPublicPreviewModal(false)}
              theme={theme}
            />
          </div>
        </div>
      )}

      {/* EDIT PROFILE MODAL WITH AGE INPUT */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-2xl flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveProfile}
            className="w-full max-w-sm rounded-3xl bg-slate-900 border border-white/15 p-5 space-y-4 shadow-2xl text-xs animate-in zoom-in-95 text-white"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="font-bold text-white uppercase tracking-wider">
                Edit Profile Details
              </span>
              <button
                type="button"
                onClick={() => setShowEditModal(false)}
                className="text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-gray-400 block mb-1 font-semibold">Display Name</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-gray-400 block mb-1 font-semibold">Unique @handle</label>
                <input
                  type="text"
                  value={editHandle}
                  onChange={(e) => setEditHandle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Age Field */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 block mb-1 font-semibold">Age</label>
                  <input
                    type="number"
                    min={18}
                    max={100}
                    value={editAge}
                    onChange={(e) => setEditAge(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-gray-400 block mb-1 font-semibold">Gender</label>
                  <select
                    value={editGender}
                    onChange={(e) => setEditGender(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Female">Female ♀️</option>
                    <option value="Male">Male ♂️</option>
                    <option value="Non-binary">Non-binary ⚧️</option>
                  </select>
                </div>
              </div>

              {/* Locked IP-based Country Information */}
              <div className="p-3 rounded-2xl bg-black/30 border border-white/10 space-y-1">
                <span className="text-[11px] text-gray-400 flex items-center justify-between">
                  <span className="flex items-center gap-1 font-bold text-white">
                    <Lock className="w-3.5 h-3.5 text-emerald-400" />
                    <span>IP Location (Locked)</span>
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono">Automatic Detection</span>
                </span>
                <p className="text-[11px] text-gray-300">
                  {currentUser.country || 'United States'} ({currentUser.countryCode || 'US'})
                </p>
                <p className="text-[10px] text-gray-500">
                  Country is securely read from network IP to prevent location spoofing.
                </p>
              </div>

              <div>
                <label className="text-gray-400 block mb-1 font-semibold">Bio</label>
                <textarea
                  rows={3}
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md"
              >
                Save Changes
              </button>
              <button
                type="button"
                onClick={() => setShowEditModal(false)}
                className="px-4 py-2.5 rounded-xl bg-white/10 text-gray-300 text-xs font-semibold"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
