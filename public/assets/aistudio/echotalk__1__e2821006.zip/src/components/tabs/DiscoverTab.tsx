import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, Shuffle, Compass, Filter, X, ChevronDown, Check, EyeOff, RotateCcw, Globe, User 
} from 'lucide-react';
import { ThemeConfig, UserProfile } from '../../types';
import { DEFAULT_PORTFOLIO_IMAGES } from '../../data/galleryPhotos';
import { getCountryFlag, getGenderIcon } from '../../utils/profileUtils';
import FullBleedProfileView from '../profile/FullBleedProfileView';
import { DiscoverSkeletonGrid } from '../common/SkeletonLoader';
import { hapticTap } from '../../utils/haptics';

interface DiscoverTabProps {
  users: UserProfile[];
  onOpenDM: (user: UserProfile) => void;
  onSendRequest: (userId: number) => void;
  theme: ThemeConfig;
  currentUser: { name: string; role: 'owner' | 'admin' | 'member'; isHidden: boolean };
  onOpenProfile?: (user: UserProfile) => void;
}

type GenderFilter = 'all' | 'Male' | 'Female' | 'Non-binary';
type AgeFilter = 'all' | '18-25' | '26-35' | '36+';

export default function DiscoverTab({
  users,
  onOpenDM,
  onSendRequest,
  theme,
  currentUser,
  onOpenProfile
}: DiscoverTabProps) {
  const [searchUsername, setSearchUsername] = useState<string>('');
  const [autoShuffle, setAutoShuffle] = useState<boolean>(true);
  const [shuffleKey, setShuffleKey] = useState<number>(0);
  
  // Working Multi-Filter States
  const [genderFilter, setGenderFilter] = useState<GenderFilter>('all');
  const [ageRangeFilter, setAgeRangeFilter] = useState<AgeFilter>('all');
  const [countryFilter, setCountryFilter] = useState<string>('all');
  const [showFiltersPanel, setShowFiltersPanel] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Full-Screen Profile state
  const [activeProfile, setActiveProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => setIsLoading(false), 260);
    return () => clearTimeout(timer);
  }, []);

  // Filter out ghost mode hidden users and current user
  const discoverableUsers = users.filter(
    (u) => !u.isHidden && u.name !== currentUser.name
  );

  const [shuffledList, setShuffledList] = useState<UserProfile[]>(discoverableUsers);

  useEffect(() => {
    setShuffledList(discoverableUsers);
  }, [users]);

  // Periodic automatic shuffle every 16 seconds if autoShuffle is enabled and no active filters
  const hasActiveFilters = genderFilter !== 'all' || ageRangeFilter !== 'all' || countryFilter !== 'all' || searchUsername.trim() !== '';

  useEffect(() => {
    if (!autoShuffle || hasActiveFilters) return;
    const interval = setInterval(() => {
      handleManualShuffle();
    }, 16000);
    return () => clearInterval(interval);
  }, [autoShuffle, discoverableUsers, hasActiveFilters]);

  const handleManualShuffle = () => {
    setShuffledList((prev) => [...prev].sort(() => Math.random() - 0.5));
    setShuffleKey((k) => k + 1);
  };

  // Distinct country list from users for the country filter
  const availableCountries = useMemo(() => {
    const set = new Set<string>();
    discoverableUsers.forEach((u) => {
      if (u.country) set.add(u.country);
    });
    return Array.from(set).sort();
  }, [discoverableUsers]);

  // Active filter count
  const activeFiltersCount = (genderFilter !== 'all' ? 1 : 0) +
    (ageRangeFilter !== 'all' ? 1 : 0) +
    (countryFilter !== 'all' ? 1 : 0);

  // Reset all filters
  const handleResetFilters = () => {
    setGenderFilter('all');
    setAgeRangeFilter('all');
    setCountryFilter('all');
    setSearchUsername('');
  };

  // Instant real-time multi-filter engine
  const filteredUsers = useMemo(() => {
    return shuffledList.filter((u) => {
      // 1. Text Search
      if (searchUsername.trim()) {
        const q = searchUsername.trim().toLowerCase().replace(/^@/, '');
        const match =
          u.handle.toLowerCase().includes(q) ||
          u.name.toLowerCase().includes(q) ||
          u.country.toLowerCase().includes(q);
        if (!match) return false;
      }

      // 2. Gender Filter
      if (genderFilter !== 'all') {
        if (genderFilter === 'Non-binary') {
          if (u.gender !== 'Non-binary') return false;
        } else if (u.gender !== genderFilter) {
          return false;
        }
      }

      // 3. Age Range Filter
      const userAge = u.age || 24;
      if (ageRangeFilter === '18-25') {
        if (userAge < 18 || userAge > 25) return false;
      } else if (ageRangeFilter === '26-35') {
        if (userAge < 26 || userAge > 35) return false;
      } else if (ageRangeFilter === '36+') {
        if (userAge < 36) return false;
      }

      // 4. Country Filter
      if (countryFilter !== 'all') {
        if (u.country !== countryFilter && u.countryCode !== countryFilter) {
          return false;
        }
      }

      return true;
    });
  }, [shuffledList, searchUsername, genderFilter, ageRangeFilter, countryFilter]);

  return (
    <div className="p-4 space-y-3.5 max-w-2xl mx-auto select-none gpu-accelerated">
      {/* Ghost Mode Status Banner for Current User */}
      {currentUser.isHidden && (
        <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-xs text-amber-200 flex items-center gap-2.5">
          <EyeOff className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            <strong>Ghost Mode Active:</strong> Your account is hidden from the Discover network.
          </span>
        </div>
      )}

      {/* Header & Controls */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Compass className="w-5 h-5 text-indigo-400" />
            <span>Discover</span>
          </h2>
          <p className="text-xs text-gray-400">
            {filteredUsers.length} member{filteredUsers.length === 1 ? '' : 's'} found
          </p>
        </div>

        {/* Shuffle Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setAutoShuffle(!autoShuffle)}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold transition ${
              autoShuffle
                ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                : 'bg-white/5 text-gray-400'
            }`}
          >
            Auto: {autoShuffle ? 'ON' : 'OFF'}
          </button>

          <button
            onClick={handleManualShuffle}
            className={`px-3 py-1.5 rounded-xl ${theme.accent} text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition`}
            title="Shuffle Profiles"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>Shuffle</span>
          </button>
        </div>
      </div>

      {/* Direct Username Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-gray-400" />
        <input
          type="text"
          placeholder="Search by @username, name, or country..."
          value={searchUsername}
          onChange={(e) => setSearchUsername(e.target.value)}
          className={`w-full pl-10 pr-10 py-2.5 rounded-2xl ${theme.inputBg} border ${theme.border} text-xs text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500`}
        />
        {searchUsername && (
          <button
            onClick={() => setSearchUsername('')}
            className="absolute right-3.5 top-3 text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* ACTIVE FLOATING FILTER TOOLBAR */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1">
          {/* Main Filter Toggle Button */}
          <button
            onClick={() => setShowFiltersPanel(!showFiltersPanel)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 transition active:scale-95 border ${
              activeFiltersCount > 0 || showFiltersPanel
                ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-900/30'
                : 'bg-white/5 hover:bg-white/10 text-gray-300 border-white/10'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filters</span>
            {activeFiltersCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-white text-indigo-700 text-[10px] font-black flex items-center justify-center">
                {activeFiltersCount}
              </span>
            )}
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showFiltersPanel ? 'rotate-180' : ''}`} />
          </button>

          {/* Quick Gender Chips */}
          {(['all', 'Female', 'Male', 'Non-binary'] as GenderFilter[]).map((g) => (
            <button
              key={g}
              onClick={() => setGenderFilter(g)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition active:scale-95 border ${
                genderFilter === g
                  ? 'bg-sky-500/20 text-sky-300 border-sky-400/50 shadow-sm'
                  : 'bg-white/5 text-gray-400 hover:text-white border-white/5'
              }`}
            >
              {g === 'all' ? 'All Genders' : g === 'Female' ? '♀️ Female' : g === 'Male' ? '♂️ Male' : '⚧️ Non-Binary'}
            </button>
          ))}

          {/* Reset button if filters active */}
          {(activeFiltersCount > 0 || searchUsername) && (
            <button
              onClick={handleResetFilters}
              className="px-2.5 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs font-semibold shrink-0 flex items-center gap-1 transition"
              title="Reset all filters"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          )}
        </div>

        {/* EXPANDABLE MULTI-FILTER DRAWER (Age Range & Country) */}
        {showFiltersPanel && (
          <div className="p-3.5 rounded-3xl bg-slate-900/90 border border-white/15 backdrop-blur-xl space-y-3.5 animate-in slide-in-from-top-2 duration-200 text-xs shadow-xl">
            {/* Age Range Filter */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                Age Range Selector
              </span>
              <div className="grid grid-cols-4 gap-2">
                {(['all', '18-25', '26-35', '36+'] as AgeFilter[]).map((range) => (
                  <button
                    key={range}
                    onClick={() => setAgeRangeFilter(range)}
                    className={`py-2 px-2 rounded-2xl text-xs font-bold transition text-center border ${
                      ageRangeFilter === range
                        ? 'bg-indigo-600 text-white border-indigo-400 shadow-md'
                        : 'bg-black/40 text-gray-400 hover:text-white border-white/5'
                    }`}
                  >
                    {range === 'all' ? 'All Ages' : range}
                  </button>
                ))}
              </div>
            </div>

            {/* Country Dropdown / Selector */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                Country Location
              </span>
              <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                <button
                  onClick={() => setCountryFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition border ${
                    countryFilter === 'all'
                      ? 'bg-indigo-600 text-white border-indigo-400'
                      : 'bg-black/40 text-gray-400 hover:text-white border-white/5'
                  }`}
                >
                  🌐 All Countries
                </button>
                {availableCountries.map((c) => (
                  <button
                    key={c}
                    onClick={() => setCountryFilter(c)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium transition flex items-center gap-1.5 border ${
                      countryFilter === c
                        ? 'bg-indigo-600 text-white border-indigo-400'
                        : 'bg-black/40 text-gray-400 hover:text-white border-white/5'
                    }`}
                  >
                    <span>{getCountryFlag(c)}</span>
                    <span>{c}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Summary / Done */}
            <div className="pt-1 flex items-center justify-between border-t border-white/10 text-[11px]">
              <span className="text-gray-400 font-mono">
                Active Filter: {genderFilter} · Age: {ageRangeFilter} · Country: {countryFilter}
              </span>
              <button
                onClick={() => setShowFiltersPanel(false)}
                className="px-3 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>

      {/* SIMPLIFIED DISCOVER GRID LAYOUT */}
      {/* Featuring only: larger circular profile picture, unique @username, country flag emoji, gender icon. NO extra text, badges, or buttons. */}
      <div
        key={shuffleKey}
        className="animate-in fade-in duration-300"
      >
        {isLoading ? (
          <DiscoverSkeletonGrid />
        ) : filteredUsers.length === 0 ? (
          <div className="col-span-full text-center py-16 text-gray-500 space-y-3">
            <Compass className="w-8 h-8 mx-auto text-indigo-400 opacity-40" />
            <p className="text-xs">No users match these active filters.</p>
            <button
              onClick={handleResetFilters}
              className="px-4 py-2 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition inline-flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset All Filters</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
            {filteredUsers.map((user) => {
              const flag = getCountryFlag(user.countryCode || user.country);
              const genderSym = getGenderIcon(user.gender);

              return (
                <div
                  key={user.id}
                  onClick={() => {
                    hapticTap(10);
                    if (onOpenProfile) {
                      onOpenProfile(user);
                    } else {
                      setActiveProfile(user);
                    }
                  }}
                  className={`p-4 rounded-3xl border ${theme.cardBorder} ${theme.card} hover:border-white/25 active:scale-95 transition-all duration-200 cursor-pointer flex flex-col items-center text-center shadow-lg hover:shadow-indigo-500/10 group relative gpu-accelerated`}
                >
                  {/* 1. Larger Circular Profile Picture */}
                  <div className="relative mb-3">
                    <div
                      className={`w-20 h-20 rounded-full ${user.avatarBg || 'bg-indigo-600'} overflow-hidden flex items-center justify-center font-bold text-xl text-white shadow-md border-2 border-white/20 group-hover:scale-105 transition-transform duration-300`}
                    >
                      {user.avatarUrl ? (
                        <img
                          src={user.avatarUrl}
                          alt={user.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        user.name[0]
                      )}
                    </div>
                    {/* Subtle Online Status Dot */}
                    <div
                      className={`w-4 h-4 rounded-full absolute bottom-0.5 right-0.5 border-2 border-slate-950 ${
                        user.online ? 'bg-emerald-400' : 'bg-gray-500'
                      }`}
                    />
                  </div>

                  {/* 2. Unique @username */}
                  <span className="text-xs font-mono font-bold text-white group-hover:text-indigo-300 transition-colors truncate max-w-full">
                    {user.handle}
                  </span>

                  {/* 3. Country Flag Emoji & 4. Gender Icon */}
                  <div className="flex items-center gap-2 mt-1.5 text-sm">
                    <span title={user.country} className="text-base select-none">
                      {flag}
                    </span>
                    <span className="text-gray-400 text-xs" title={user.gender}>
                      {genderSym}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* iOS-STYLE FULL-SCREEN PROFILE PAGE (FULL-BLEED TOUCH SLIDING & ATTRIBUTES) */}
      {activeProfile && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-2xl flex items-center justify-center p-0 animate-in fade-in duration-200">
          <div className="w-full max-w-lg h-full overflow-y-auto">
            <FullBleedProfileView
              user={activeProfile}
              isCurrentUser={false}
              onClose={() => setActiveProfile(null)}
              onOpenDM={(u) => {
                setActiveProfile(null);
                onOpenDM(u);
              }}
              theme={theme}
            />
          </div>
        </div>
      )}

    </div>
  );
}
