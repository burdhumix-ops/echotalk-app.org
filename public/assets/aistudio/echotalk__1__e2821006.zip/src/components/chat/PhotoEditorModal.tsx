import React, { useState, useRef, useEffect } from 'react';
import { 
  X, Check, Undo2, Redo2, Crop, Smile, Type, Brush, 
  RotateCcw, Sparkles, Send, EyeOff, ShieldCheck, Square, Circle, ArrowUpRight
} from 'lucide-react';
import { ThemeConfig } from '../../types';

interface PhotoEditorModalProps {
  imageSrc: string;
  onSend: (editedImage: string, isViewOnce?: boolean) => void;
  onClose: () => void;
  theme: ThemeConfig;
}

type ToolMode = 'brush' | 'blur' | 'sticker' | 'text' | 'shape' | 'crop';

export default function PhotoEditorModal({
  imageSrc,
  onSend,
  onClose,
  theme
}: PhotoEditorModalProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [activeTool, setActiveTool] = useState<ToolMode>('brush');
  const [brushColor, setBrushColor] = useState<string>('#6366F1');
  const [brushSize, setBrushSize] = useState<number>(10);
  const [selectedShape, setSelectedShape] = useState<'arrow' | 'rect' | 'circle'>('arrow');
  const [isViewOnce, setIsViewOnce] = useState<boolean>(false);
  
  // Stickers
  const [placedStickers, setPlacedStickers] = useState<{ id: number; emoji: string; x: number; y: number }[]>([]);
  // Text markups
  const [placedTexts, setPlacedTexts] = useState<{ id: number; text: string; x: number; y: number; color: string }[]>([]);
  const [textInput, setTextInput] = useState<string>('');
  const [showTextInput, setShowTextInput] = useState<boolean>(false);

  // Undo history
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  // Drawing state
  const isDrawing = useRef<boolean>(false);
  const lastPoint = useRef<{ x: number; y: number } | null>(null);
  const baseImage = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = imageSrc;
    img.onload = () => {
      baseImage.current = img;
      initCanvas(img);
    };
  }, [imageSrc]);

  const initCanvas = (img: HTMLImageElement) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    // Maintain aspect ratio inside max 1000px
    const maxDim = 900;
    let w = img.width;
    let h = img.height;
    if (w > maxDim || h > maxDim) {
      if (w > h) {
        h = (h / w) * maxDim;
        w = maxDim;
      } else {
        w = (w / h) * maxDim;
        h = maxDim;
      }
    }

    canvas.width = w;
    canvas.height = h;

    ctx.drawImage(img, 0, 0, w, h);
    saveState();
  };

  const saveState = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setHistory((prev) => [...prev.slice(0, historyIndex + 1), data]);
    setHistoryIndex((prev) => prev + 1);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const targetState = history[historyIndex - 1];
      ctx.putImageData(targetState, 0, 0);
      setHistoryIndex((idx) => idx - 1);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const targetState = history[historyIndex + 1];
      ctx.putImageData(targetState, 0, 0);
      setHistoryIndex((idx) => idx + 1);
    }
  };

  // Canvas Coordinates Helper
  const getCanvasCoords = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;

    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const startDraw = (e: React.MouseEvent | React.TouchEvent) => {
    if (activeTool === 'sticker' || activeTool === 'text') return;
    isDrawing.current = true;
    lastPoint.current = getCanvasCoords(e);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing.current || !lastPoint.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const currentPoint = getCanvasCoords(e);

    if (activeTool === 'brush') {
      // High-End Neon Glow Brush
      ctx.save();
      ctx.strokeStyle = brushColor;
      ctx.lineWidth = brushSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.shadowColor = brushColor;
      ctx.shadowBlur = brushSize * 1.5;

      ctx.beginPath();
      ctx.moveTo(lastPoint.current.x, lastPoint.current.y);
      ctx.lineTo(currentPoint.x, currentPoint.y);
      ctx.stroke();
      ctx.restore();
    } else if (activeTool === 'blur') {
      // DEDICATED BLUR BRUSH TOOL: Gaussian blur on brushed area
      ctx.save();
      ctx.beginPath();
      ctx.arc(currentPoint.x, currentPoint.y, brushSize * 1.8, 0, Math.PI * 2);
      ctx.clip();

      // Apply fast blur filter over this clip path
      ctx.filter = 'blur(14px)';
      ctx.drawImage(canvas, 0, 0);
      ctx.restore();
    }

    lastPoint.current = currentPoint;
  };

  const stopDraw = () => {
    if (isDrawing.current) {
      isDrawing.current = false;
      lastPoint.current = null;
      saveState();
    }
  };

  const handleCanvasClick = (e: React.MouseEvent) => {
    const coords = getCanvasCoords(e);
    if (activeTool === 'text' && showTextInput && textInput.trim()) {
      setPlacedTexts((prev) => [
        ...prev,
        { id: Date.now(), text: textInput.trim(), x: coords.x, y: coords.y, color: brushColor }
      ]);
      setTextInput('');
      setShowTextInput(false);
    }
  };

  const handleAddSticker = (emoji: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setPlacedStickers((prev) => [
      ...prev,
      { id: Date.now(), emoji, x: canvas.width / 2, y: canvas.height / 2 }
    ]);
  };

  const handleExportAndSend = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Render placed stickers and text onto final canvas
    for (const t of placedTexts) {
      ctx.save();
      ctx.font = 'bold 28px sans-serif';
      ctx.fillStyle = t.color;
      ctx.shadowColor = 'rgba(0,0,0,0.8)';
      ctx.shadowBlur = 8;
      ctx.fillText(t.text, t.x, t.y);
      ctx.restore();
    }

    for (const s of placedStickers) {
      ctx.save();
      ctx.font = '48px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(s.emoji, s.x, s.y);
      ctx.restore();
    }

    const finalDataUrl = canvas.toDataURL('image/jpeg', 0.92);
    onSend(finalDataUrl, isViewOnce);
  };

  const COLOR_PALETTE = ['#FFFFFF', '#6366F1', '#EC4899', '#10B981', '#F59E0B', '#06B6D4', '#EF4444'];
  const STICKER_LIST = ['🔥', '✨', '⚡', '🕶️', '👑', '❤️', '😂', '🎯', '🚀', '💯'];

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex flex-col justify-between select-none animate-in fade-in duration-200">
      
      {/* Top Header Bar */}
      <div className="h-16 px-4 bg-slate-900/90 border-b border-white/10 flex items-center justify-between z-20 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 rounded-2xl bg-white/5 hover:bg-white/15 text-gray-300 transition"
          >
            <X className="w-5 h-5" />
          </button>
          <span className="text-xs font-bold font-mono text-white tracking-wider uppercase">
            Telegram Photo Editor
          </span>
        </div>

        {/* Undo / Redo & View-Once Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleUndo}
            disabled={historyIndex <= 0}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-30 text-white transition"
            title="Undo"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            onClick={handleRedo}
            disabled={historyIndex >= history.length - 1}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-30 text-white transition"
            title="Redo"
          >
            <Redo2 className="w-4 h-4" />
          </button>

          {/* Flame View-Once Toggle */}
          <button
            onClick={() => setIsViewOnce(!isViewOnce)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 ${
              isViewOnce
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30'
                : 'bg-white/10 text-gray-300 hover:text-white'
            }`}
            title="Toggle View-Once Self Destructing"
          >
            <span>🔥</span>
            <span>{isViewOnce ? 'View-Once Active' : 'View-Once'}</span>
          </button>
        </div>
      </div>

      {/* Main Canvas Viewport */}
      <div 
        ref={containerRef}
        className="flex-1 flex items-center justify-center p-4 overflow-hidden relative"
      >
        <canvas
          ref={canvasRef}
          onMouseDown={startDraw}
          onMouseMove={draw}
          onMouseUp={stopDraw}
          onMouseLeave={stopDraw}
          onTouchStart={startDraw}
          onTouchMove={draw}
          onTouchEnd={stopDraw}
          onClick={handleCanvasClick}
          className={`max-w-full max-h-[70vh] rounded-2xl shadow-2xl touch-none border border-white/10 ${
            activeTool === 'blur' ? 'cursor-crosshair' : activeTool === 'brush' ? 'cursor-crosshair' : 'cursor-default'
          }`}
        />

        {/* Floating text input prompter */}
        {showTextInput && (
          <div className="absolute top-6 left-1/2 -translate-x-1/2 z-30 p-2.5 rounded-2xl bg-slate-900/90 border border-indigo-500/40 shadow-2xl flex items-center gap-2">
            <input
              type="text"
              placeholder="Type markup caption..."
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-black/60 border border-white/10 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
            <span className="text-[10px] text-gray-400">Click canvas to place</span>
          </div>
        )}
      </div>

      {/* Tool Sub-Bar: Color Swatches & Brush Sizes */}
      <div className="px-4 py-2 bg-slate-900/80 border-t border-white/5 flex items-center justify-between flex-wrap gap-2 z-20">
        {activeTool === 'brush' && (
          <div className="flex items-center gap-3">
            <span className="text-[10px] uppercase font-mono text-gray-400">Color:</span>
            <div className="flex items-center gap-1.5">
              {COLOR_PALETTE.map((c) => (
                <button
                  key={c}
                  onClick={() => setBrushColor(c)}
                  style={{ backgroundColor: c }}
                  className={`w-6 h-6 rounded-full transition-all ${
                    brushColor === c ? 'scale-125 ring-2 ring-white shadow-md' : 'opacity-80'
                  }`}
                />
              ))}
            </div>

            <div className="w-px h-4 bg-white/10 mx-1" />

            <div className="flex items-center gap-1">
              {[6, 12, 20].map((s) => (
                <button
                  key={s}
                  onClick={() => setBrushSize(s)}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-mono ${
                    brushSize === s ? 'bg-white text-black font-bold' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {s === 6 ? 'Fine' : s === 12 ? 'Med' : 'Bold'}
                </button>
              ))}
            </div>
          </div>
        )}

        {activeTool === 'blur' && (
          <div className="flex items-center gap-3 text-xs text-amber-300">
            <EyeOff className="w-4 h-4 text-amber-400" />
            <span className="font-semibold">Blur Brush Active:</span>
            <span className="text-[11px] text-gray-300">Drag over faces or sensitive info to apply instant Gaussian blur.</span>
            <div className="flex items-center gap-1 ml-auto">
              {[8, 16, 26].map((s) => (
                <button
                  key={s}
                  onClick={() => setBrushSize(s)}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-mono ${
                    brushSize === s ? 'bg-amber-400 text-slate-950 font-bold' : 'text-gray-400'
                  }`}
                >
                  {s === 8 ? 'Small' : s === 16 ? 'Standard' : 'Heavy'}
                </button>
              ))}
            </div>
          </div>
        )}

        {activeTool === 'crop' && (
          <div className="flex items-center gap-2 text-xs">
            <span className="text-[10px] uppercase font-mono text-cyan-400 font-bold">Crop Ratio:</span>
            {(['square', 'story', 'landscape'] as const).map((ratio) => (
              <button
                key={ratio}
                onClick={() => {
                  const canvas = canvasRef.current;
                  if (!canvas) return;
                  const ctx = canvas.getContext('2d');
                  if (!ctx) return;

                  let newWidth = canvas.width;
                  let newHeight = canvas.height;
                  let sx = 0;
                  let sy = 0;

                  if (ratio === 'square') {
                    const minDim = Math.min(canvas.width, canvas.height);
                    sx = (canvas.width - minDim) / 2;
                    sy = (canvas.height - minDim) / 2;
                    newWidth = minDim;
                    newHeight = minDim;
                  } else if (ratio === 'story') {
                    newHeight = canvas.height;
                    newWidth = Math.floor((canvas.height * 9) / 16);
                    sx = Math.max(0, Math.floor((canvas.width - newWidth) / 2));
                  } else {
                    newWidth = canvas.width;
                    newHeight = Math.floor((canvas.width * 9) / 16);
                    sy = Math.max(0, Math.floor((canvas.height - newHeight) / 2));
                  }

                  const croppedData = ctx.getImageData(sx, sy, newWidth, newHeight);
                  canvas.width = newWidth;
                  canvas.height = newHeight;
                  ctx.putImageData(croppedData, 0, 0);
                  saveState();
                }}
                className="px-3 py-1 rounded-xl bg-white/10 hover:bg-cyan-500/20 hover:text-cyan-300 text-white font-medium text-[11px] transition"
              >
                {ratio === 'square' ? '1:1 Square' : ratio === 'story' ? '9:16 Story' : '16:9 Wide'}
              </button>
            ))}
          </div>
        )}

        {activeTool === 'sticker' && (
          <div className="flex items-center gap-2 overflow-x-auto py-1 scrollbar-none">
            {STICKER_LIST.map((emoji) => (
              <button
                key={emoji}
                onClick={() => handleAddSticker(emoji)}
                className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 text-xl flex items-center justify-center transition active:scale-90 shrink-0"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Main Tool Dock & Send Button */}
      <div className="h-20 px-4 bg-slate-950 border-t border-white/10 flex items-center justify-between gap-4 z-20 shrink-0">
        <div className="flex items-center gap-2">
          {/* Crop Tool */}
          <button
            onClick={() => setActiveTool(activeTool === 'crop' ? 'brush' : 'crop')}
            className={`px-3 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 ${
              activeTool === 'crop'
                ? 'bg-cyan-600 text-white shadow-lg'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Crop className="w-4 h-4" />
            <span className="hidden sm:inline">Crop</span>
          </button>

          {/* Neon Brush Tool */}
          <button
            onClick={() => setActiveTool('brush')}
            className={`px-3.5 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition active:scale-95 ${
              activeTool === 'brush'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Brush className="w-4 h-4" />
            <span>Brush</span>
          </button>

          {/* Dedicated Blur Brush Tool */}
          <button
            onClick={() => setActiveTool('blur')}
            className={`px-3.5 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition active:scale-95 ${
              activeTool === 'blur'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <EyeOff className="w-4 h-4" />
            <span>Blur Brush</span>
          </button>

          {/* Stickers */}
          <button
            onClick={() => setActiveTool('sticker')}
            className={`px-3.5 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition active:scale-95 ${
              activeTool === 'sticker'
                ? 'bg-rose-600 text-white shadow-lg'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Smile className="w-4 h-4" />
            <span>Stickers</span>
          </button>

          {/* Text Markup */}
          <button
            onClick={() => {
              setActiveTool('text');
              setShowTextInput(true);
            }}
            className={`px-3.5 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition active:scale-95 ${
              activeTool === 'text'
                ? 'bg-emerald-600 text-white shadow-lg'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Type className="w-4 h-4" />
            <span>Text</span>
          </button>
        </div>

        {/* Send Edited Photo Button */}
        <button
          onClick={handleExportAndSend}
          className="px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs flex items-center gap-2 shadow-xl shadow-indigo-900/50 active:scale-95 transition"
        >
          <span>Send Photo</span>
          <Send className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
}
