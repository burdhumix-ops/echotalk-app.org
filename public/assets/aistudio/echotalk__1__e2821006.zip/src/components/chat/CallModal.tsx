import React, { useState, useEffect, useRef } from 'react';
import { 
  PhoneOff, Mic, MicOff, Video, VideoOff, SwitchCamera, 
  Monitor, MonitorOff, Volume2, ShieldCheck, Sparkles, User, Maximize2, Radio
} from 'lucide-react';
import { UserProfile, ThemeConfig } from '../../types';
import { hapticDoublePulse, hapticHeavyBump } from '../../utils/haptics';

interface CallModalProps {
  partner: UserProfile;
  callType: 'audio' | 'video';
  onEndCall: () => void;
  theme: ThemeConfig;
}

export default function CallModal({
  partner,
  callType: initialCallType,
  onEndCall,
  theme
}: CallModalProps) {
  const [callDuration, setCallDuration] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isVideoOff, setIsVideoOff] = useState<boolean>(initialCallType === 'audio');
  const [isScreenSharing, setIsScreenSharing] = useState<boolean>(false);
  const [isFrontCamera, setIsFrontCamera] = useState<boolean>(true);
  const [callStatus, setCallStatus] = useState<'Connecting...' | 'Secured (E2EE)' | 'Connected'>('Connecting...');
  
  const timerRef = useRef<number | null>(null);
  const selfVideoRef = useRef<HTMLVideoElement | null>(null);
  const screenCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    hapticDoublePulse();
    const connectTimer = setTimeout(() => {
      setCallStatus('Secured (E2EE)');
      setTimeout(() => {
        setCallStatus('Connected');
      }, 900);
    }, 1200);

    timerRef.current = window.setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);

    return () => {
      clearTimeout(connectTimer);
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const formatDuration = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleEnd = () => {
    hapticHeavyBump();
    onEndCall();
  };

  const toggleScreenShare = () => {
    hapticDoublePulse();
    setIsScreenSharing(!isScreenSharing);
  };

  // Animated Screen Sharing Presentation Simulation
  useEffect(() => {
    if (!isScreenSharing) return;
    const canvas = screenCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    let animId: number;

    const render = () => {
      frame++;
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Render simulated broadcast workspace/mobile presentation
      ctx.strokeStyle = '#6366f1';
      ctx.lineWidth = 2;
      ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);

      // Window Header
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(20, 20, canvas.width - 40, 36);

      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(40, 38, 5, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#eab308';
      ctx.beginPath();
      ctx.arc(56, 38, 5, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.arc(72, 38, 5, 0, Math.PI * 2);
      ctx.fill();

      // Title
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px monospace';
      ctx.fillText('Live Mobile Screen Stream (1080p 60fps)', 95, 42);

      // Waveform / activity graph
      ctx.beginPath();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      for (let x = 30; x < canvas.width - 30; x += 10) {
        const y = 140 + Math.sin((x + frame * 3) / 25) * 25 + Math.cos((x + frame * 2) / 15) * 12;
        if (x === 30) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Broadcast pill
      ctx.fillStyle = 'rgba(239, 68, 68, 0.85)';
      ctx.roundRect(canvas.width - 140, 75, 110, 24, 8);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 10px sans-serif';
      ctx.fillText('● SCREEN SHARING', canvas.width - 132, 91);

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [isScreenSharing]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between text-white select-none animate-in fade-in duration-300">
      
      {/* --- TOP CALL HEADER --- */}
      <div className="p-4 flex items-center justify-between z-30 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-mono font-bold text-gray-200">
            {callStatus} · {formatDuration(callDuration)}
          </span>
        </div>

        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/40 backdrop-blur-md border border-white/10 text-xs font-mono text-indigo-300">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>WebRTC P2P</span>
        </div>
      </div>

      {/* --- MAIN STAGE: VIDEO OR SCREEN OR AUDIO CALL --- */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        {isScreenSharing ? (
          /* Live Screen Share Canvas */
          <div className="w-full h-full p-4 flex flex-col items-center justify-center">
            <canvas
              ref={screenCanvasRef}
              width={640}
              height={360}
              className="max-w-full max-h-[70vh] rounded-3xl border border-indigo-500/40 shadow-2xl bg-black"
            />
            <div className="mt-3 flex items-center gap-2 text-xs text-indigo-300 font-mono">
              <Radio className="w-3.5 h-3.5 animate-pulse text-rose-400" />
              <span>Broadcasting device screen to {partner.name}</span>
            </div>
          </div>
        ) : isVideoOff ? (
          /* High-Definition Audio Call View */
          <div className="flex flex-col items-center text-center space-y-4 animate-in zoom-in-95 duration-200">
            <div className="relative">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-indigo-500/40 shadow-2xl">
                <img
                  src={partner.avatarUrl || '/src/assets/images/avatar_chloe_dubois_1792623177921.jpg'}
                  alt={partner.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute inset-0 rounded-full border-2 border-indigo-400/50 animate-ping pointer-events-none" />
            </div>

            <div className="space-y-1">
              <h2 className="text-2xl font-black tracking-tight">{partner.name}</h2>
              <p className="text-xs text-gray-400 font-mono">
                {isMuted ? 'Microphone Muted' : 'Audio Call Active (Noise Cancelled)'}
              </p>
            </div>
          </div>
        ) : (
          /* Full-Screen HD Video Stream */
          <div className="relative w-full h-full">
            <img
              src={partner.avatarUrl || '/src/assets/images/avatar_chloe_dubois_1792623177921.jpg'}
              alt={partner.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/40" />

            {/* Remote Partner Name Tag */}
            <div className="absolute bottom-28 left-6 bg-black/60 backdrop-blur-md px-3.5 py-1.5 rounded-2xl border border-white/10 text-xs font-bold flex items-center gap-2">
              <span>{partner.name}</span>
              <span className="text-[10px] text-emerald-400 font-mono">1080p HD</span>
            </div>
          </div>
        )}

        {/* --- FLOATING SELF-VIEW PIP --- */}
        {!isVideoOff && !isScreenSharing && (
          <div className="absolute top-16 right-4 w-28 h-40 rounded-2xl overflow-hidden border-2 border-white/20 shadow-2xl bg-slate-900 z-30 group cursor-pointer">
            <img
              src="/src/assets/images/avatar_zavier_founder_1792623177719.jpg"
              alt="Self View"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-1 right-1 bg-black/70 text-[9px] font-mono px-1.5 py-0.5 rounded-md text-white/80">
              You
            </div>
          </div>
        )}
      </div>

      {/* --- BOTTOM CALL CONTROLS DOCK --- */}
      <div className="p-6 bg-gradient-to-t from-black/90 via-black/70 to-transparent flex items-center justify-center gap-4 z-30">
        {/* Mute Mic Toggle */}
        <button
          onClick={() => {
            hapticDoublePulse();
            setIsMuted(!isMuted);
          }}
          className={`p-4 rounded-full transition active:scale-95 shadow-xl ${
            isMuted ? 'bg-amber-500 text-slate-950 ring-4 ring-amber-500/30' : 'bg-white/15 text-white hover:bg-white/25'
          }`}
          title={isMuted ? 'Unmute Mic' : 'Mute Mic'}
        >
          {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Video Toggle */}
        <button
          onClick={() => {
            hapticDoublePulse();
            setIsVideoOff(!isVideoOff);
          }}
          className={`p-4 rounded-full transition active:scale-95 shadow-xl ${
            isVideoOff ? 'bg-white/15 text-gray-400' : 'bg-indigo-600 text-white shadow-indigo-600/40'
          }`}
          title={isVideoOff ? 'Turn Video On' : 'Turn Video Off'}
        >
          {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
        </button>

        {/* Screen Share Control (🖥️) */}
        <button
          onClick={toggleScreenShare}
          className={`p-4 rounded-full transition active:scale-95 shadow-xl ${
            isScreenSharing
              ? 'bg-sky-500 text-slate-950 ring-4 ring-sky-500/40'
              : 'bg-white/15 text-white hover:bg-white/25'
          }`}
          title="Share Screen Live"
        >
          {isScreenSharing ? <MonitorOff className="w-5 h-5" /> : <Monitor className="w-5 h-5" />}
        </button>

        {/* Camera Flip */}
        {!isVideoOff && !isScreenSharing && (
          <button
            onClick={() => {
              hapticDoublePulse();
              setIsFrontCamera(!isFrontCamera);
            }}
            className="p-4 rounded-full bg-white/15 text-white hover:bg-white/25 transition active:scale-95 shadow-xl"
            title="Flip Camera"
          >
            <SwitchCamera className="w-5 h-5" />
          </button>
        )}

        {/* End Call Button */}
        <button
          onClick={handleEnd}
          className="p-4 rounded-full bg-rose-600 hover:bg-rose-500 text-white transition active:scale-95 shadow-xl shadow-rose-900/50"
          title="End Call"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>

    </div>
  );
}
