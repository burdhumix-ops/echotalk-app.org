import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Play, Pause, Volume2, Sparkles } from 'lucide-react';
import { ThemeConfig } from '../../types';

interface AudioWaveformCanvasProps {
  messageId: number;
  duration?: string;
  initialWaveform?: number[];
  audioUrl?: string;
  isMe?: boolean;
  theme?: ThemeConfig;
}

export default function AudioWaveformCanvas({
  messageId,
  duration = '0:05',
  initialWaveform,
  audioUrl,
  isMe = false,
  theme
}: AudioWaveformCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackProgress, setPlaybackProgress] = useState<number>(0); // 0 to 1
  const [currentTimeFormatted, setCurrentTimeFormatted] = useState<string>('0:00');
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1); // 1x, 1.5x, 2x

  // Audio Context & Analyser references
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceNodeRef = useRef<AudioNode | null>(null);
  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);
  const pausedAtRef = useRef<number>(0);
  const isPlayingRef = useRef<boolean>(false);

  // Parse total duration in seconds (e.g. "0:05" -> 5)
  const parseDurationSeconds = (str: string): number => {
    const parts = str.split(':');
    if (parts.length === 2) {
      return parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10) || 5;
    }
    return 5;
  };

  const totalDurationSec = parseDurationSeconds(duration);

  // Generate deterministic base waveform bars if not provided
  const baseWaveform = useRef<number[]>(
    initialWaveform && initialWaveform.length >= 24
      ? initialWaveform
      : Array.from({ length: 36 }, (_, i) => {
          // Organic speech-like amplitude curve with pauses and cadence peaks
          const seed = (messageId * 37 + i * 19) % 100;
          const curve = Math.sin((i / 36) * Math.PI); // envelope
          const variance = 0.25 + 0.7 * (seed / 100);
          return Math.max(0.18, Math.min(1.0, curve * variance * 1.3));
        })
  ).current;

  // Cleanup Web Audio nodes
  const stopAudio = useCallback(() => {
    isPlayingRef.current = false;
    setIsPlaying(false);

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    if (sourceNodeRef.current) {
      try {
        if ('stop' in sourceNodeRef.current) {
          (sourceNodeRef.current as AudioScheduledSourceNode).stop();
        }
      } catch (_) {
        // Ignored if already stopped
      }
      sourceNodeRef.current.disconnect();
      sourceNodeRef.current = null;
    }

    if (audioElRef.current) {
      audioElRef.current.pause();
    }
  }, []);

  // Format seconds into m:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Start real-time audio playback & amplitude analysis
  const playAudio = useCallback(
    async (startRatio = 0) => {
      try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioContextClass) return;

        if (!audioCtxRef.current || audioCtxRef.current.state === 'closed') {
          audioCtxRef.current = new AudioContextClass();
        }

        const ctx = audioCtxRef.current;
        if (ctx.state === 'suspended') {
          await ctx.resume();
        }

        // Create analyser
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 64;
        analyser.smoothingTimeConstant = 0.75;
        analyserRef.current = analyser;

        const effectiveDuration = totalDurationSec / playbackSpeed;
        const startOffset = startRatio * effectiveDuration;

        // If a real audioUrl is provided and valid, stream it
        if (audioUrl && audioUrl.startsWith('blob:')) {
          if (!audioElRef.current) {
            audioElRef.current = new Audio(audioUrl);
          }
          const audio = audioElRef.current;
          audio.currentTime = startRatio * totalDurationSec;
          audio.playbackRate = playbackSpeed;

          const source = ctx.createMediaElementSource(audio);
          source.connect(analyser);
          analyser.connect(ctx.destination);
          sourceNodeRef.current = source;

          audio.onended = () => {
            stopAudio();
            setPlaybackProgress(0);
            setCurrentTimeFormatted('0:00');
          };

          await audio.play();
        } else {
          // Synthesize a natural human vocal cadence sequence
          // Using modulated dual-oscillator voice synth with formant biquad filter
          const osc1 = ctx.createOscillator();
          const osc2 = ctx.createOscillator();
          const vocalFilter = ctx.createBiquadFilter();
          const mainGain = ctx.createGain();

          osc1.type = 'sawtooth';
          osc2.type = 'triangle';

          // Human speaking pitch modulation (~140Hz - 240Hz with natural inflection)
          const basePitch = isMe ? 165 : 210;
          osc1.frequency.setValueAtTime(basePitch, ctx.currentTime);
          osc2.frequency.setValueAtTime(basePitch * 1.5, ctx.currentTime);

          // Subtle pitch flutter & speech-like inflection
          const cadenceSteps = [0, 2, -1, 3, 1, -2, 4, 0, -1, 2];
          cadenceSteps.forEach((step, idx) => {
            const t = ctx.currentTime + (idx * (effectiveDuration / cadenceSteps.length));
            osc1.frequency.exponentialRampToValueAtTime(
              Math.max(100, basePitch + step * 18),
              t
            );
          });

          // Vocal Formant Bandpass Filter (human vowel resonance ~1100Hz)
          vocalFilter.type = 'bandpass';
          vocalFilter.frequency.setValueAtTime(1100, ctx.currentTime);
          vocalFilter.Q.setValueAtTime(3.5, ctx.currentTime);

          // Dynamic speech amplitude envelope with word pauses
          mainGain.gain.setValueAtTime(0, ctx.currentTime);
          mainGain.gain.linearRampToValueAtTime(0.18, ctx.currentTime + 0.1);

          // Modulate gain to mimic speech syllables
          const syllableCount = Math.floor(effectiveDuration * 3.5);
          for (let s = 0; s < syllableCount; s++) {
            const timePoint = ctx.currentTime + (s / syllableCount) * effectiveDuration;
            const amp = (baseWaveform[s % baseWaveform.length] || 0.5) * 0.22;
            mainGain.gain.setValueAtTime(amp, timePoint);
            mainGain.gain.linearRampToValueAtTime(amp * 0.3, timePoint + 0.18 / playbackSpeed);
          }

          mainGain.gain.setValueAtTime(0.15, ctx.currentTime + effectiveDuration - 0.1);
          mainGain.gain.linearRampToValueAtTime(0, ctx.currentTime + effectiveDuration);

          // Routing
          osc1.connect(vocalFilter);
          osc2.connect(vocalFilter);
          vocalFilter.connect(mainGain);
          mainGain.connect(analyser);
          analyser.connect(ctx.destination);

          osc1.start(ctx.currentTime);
          osc2.start(ctx.currentTime);
          osc1.stop(ctx.currentTime + effectiveDuration - startOffset);
          osc2.stop(ctx.currentTime + effectiveDuration - startOffset);

          sourceNodeRef.current = osc1;

          osc1.onended = () => {
            stopAudio();
            setPlaybackProgress(0);
            setCurrentTimeFormatted('0:00');
          };
        }

        startTimeRef.current = performance.now() - startOffset * 1000;
        isPlayingRef.current = true;
        setIsPlaying(true);

        // Run real-time 60fps waveform animation loop
        const dataArray = new Uint8Array(analyser.frequencyBinCount);

        const renderLoop = () => {
          if (!isPlayingRef.current) return;

          const now = performance.now();
          const elapsed = (now - startTimeRef.current) / 1000;
          const progress = Math.min(1.0, elapsed / effectiveDuration);

          setPlaybackProgress(progress);
          setCurrentTimeFormatted(formatTime(progress * totalDurationSec));

          // Read real-time frequency amplitude from Web Audio AnalyserNode
          analyser.getByteFrequencyData(dataArray);

          // Compute average amplitude (0 to 1)
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i];
          }
          const liveRms = sum / (dataArray.length * 255);

          // Render canvas with real-time reactive bar heights & glowing playhead
          drawWaveform(progress, dataArray, liveRms);

          if (progress < 1.0) {
            animationFrameRef.current = requestAnimationFrame(renderLoop);
          } else {
            stopAudio();
            setPlaybackProgress(0);
            setCurrentTimeFormatted('0:00');
            drawWaveform(0, null, 0);
          }
        };

        animationFrameRef.current = requestAnimationFrame(renderLoop);
      } catch (err) {
        console.error('Audio playback error:', err);
        stopAudio();
      }
    },
    [audioUrl, baseWaveform, isMe, playbackSpeed, stopAudio, totalDurationSec]
  );

  // Canvas drawing function with Retina sharpness and real-time reactive amplitude
  const drawWaveform = useCallback(
    (progress: number, freqData: Uint8Array | null, liveAmplitude: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const dpr = window.devicePixelRatio || 1;
      const width = canvas.width / dpr;
      const height = canvas.height / dpr;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      ctx.scale(dpr, dpr);

      const barCount = baseWaveform.length;
      const totalSpacingRatio = 0.35;
      const availableWidth = width;
      const barWidth = Math.max(2.2, (availableWidth * (1 - totalSpacingRatio)) / barCount);
      const gap = (availableWidth - barWidth * barCount) / (barCount - 1);

      const centerY = height / 2;
      const maxHalfHeight = (height - 6) / 2;

      // Create glowing linear gradient for played portion
      const playedGradient = ctx.createLinearGradient(0, 0, width * progress, 0);
      playedGradient.addColorStop(0, '#38bdf8'); // Sky Cyan
      playedGradient.addColorStop(0.5, '#6366f1'); // Indigo
      playedGradient.addColorStop(1, '#a855f7'); // Violet neon

      // Draw each vertical amplitude bar
      for (let i = 0; i < barCount; i++) {
        const x = i * (barWidth + gap);
        const barProgress = (i + 0.5) / barCount;
        const isPlayed = barProgress <= progress;

        const baseVal = baseWaveform[i] || 0.5;

        // If playing and live frequency data is available, react to actual amplitude!
        let reactiveVal = baseVal;
        if (freqData && freqData.length > 0) {
          // Map bar index to frequency bin
          const binIdx = Math.floor((i / barCount) * freqData.length);
          const freqNorm = freqData[binIdx] / 255;
          // Blend base fingerprint with live instantaneous amplitude
          const proximityToPlayhead = Math.max(0, 1 - Math.abs(barProgress - progress) * 4);
          const liveBoost = (freqNorm * 0.7 + liveAmplitude * 0.5) * (1 + proximityToPlayhead * 0.8);
          reactiveVal = Math.min(1.0, baseVal * 0.65 + liveBoost * 0.75);
        }

        const barHalfHeight = Math.max(2.5, reactiveVal * maxHalfHeight);
        const topY = centerY - barHalfHeight;
        const barHeight = barHalfHeight * 2;
        const radius = barWidth / 2;

        ctx.beginPath();
        if (typeof ctx.roundRect === 'function') {
          ctx.roundRect(x, topY, barWidth, barHeight, radius);
        } else {
          // Manual rounded bar
          ctx.arc(x + radius, topY + radius, radius, Math.PI, 0, false);
          ctx.lineTo(x + barWidth, topY + barHeight - radius);
          ctx.arc(x + radius, topY + barHeight - radius, radius, 0, Math.PI, false);
          ctx.closePath();
        }

        if (isPlayed) {
          ctx.fillStyle = playedGradient;
          ctx.shadowColor = 'rgba(56, 189, 248, 0.45)';
          ctx.shadowBlur = 4;
        } else {
          // Unplayed bar: clean soft translucency
          ctx.fillStyle = isMe ? 'rgba(255, 255, 255, 0.4)' : 'rgba(255, 255, 255, 0.28)';
          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;
        }

        ctx.fill();
      }

      // Draw dynamic playhead line & glowing pulse bead
      if (progress > 0 && progress < 1) {
        const playheadX = Math.min(width - 2, Math.max(2, progress * width));

        // Vertical glowing needle
        ctx.beginPath();
        ctx.moveTo(playheadX, 2);
        ctx.lineTo(playheadX, height - 2);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.5;
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 6;
        ctx.stroke();

        // Pulsing bead indicator at center
        const beadRadius = 3 + liveAmplitude * 3.5;
        ctx.beginPath();
        ctx.arc(playheadX, centerY, beadRadius, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 8;
        ctx.fill();

        // Outer ripple ring reacting to live volume
        if (liveAmplitude > 0.08) {
          ctx.beginPath();
          ctx.arc(playheadX, centerY, beadRadius + liveAmplitude * 9, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(56, 189, 248, ${Math.max(0.2, 0.9 - liveAmplitude)})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }

      ctx.restore();
    },
    [baseWaveform, isMe]
  );

  // Initialize canvas with proper resolution
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const width = rect.width || 180;
    const height = rect.height || 36;

    canvas.width = width * dpr;
    canvas.height = height * dpr;

    drawWaveform(playbackProgress, null, 0);
  }, [drawWaveform, playbackProgress]);

  // Handle Play / Pause Toggle
  const handleTogglePlay = () => {
    if (isPlaying) {
      pausedAtRef.current = playbackProgress;
      stopAudio();
    } else {
      const startAt = playbackProgress >= 0.98 ? 0 : playbackProgress;
      playAudio(startAt);
    }
  };

  // Handle Interactive Scrubbing / Seeking on canvas tap
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const newProgress = Math.max(0, Math.min(1, clickX / rect.width));

    setPlaybackProgress(newProgress);
    setCurrentTimeFormatted(formatTime(newProgress * totalDurationSec));

    if (isPlaying) {
      stopAudio();
      playAudio(newProgress);
    } else {
      pausedAtRef.current = newProgress;
      drawWaveform(newProgress, null, 0);
    }
  };

  // Cycle speed (1x -> 1.5x -> 2x)
  const handleCycleSpeed = (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextSpeed = playbackSpeed === 1 ? 1.5 : playbackSpeed === 1.5 ? 2 : 1;
    setPlaybackSpeed(nextSpeed);

    if (isPlaying) {
      const currentRatio = playbackProgress;
      stopAudio();
      setTimeout(() => playAudio(currentRatio), 50);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopAudio();
      if (audioCtxRef.current && audioCtxRef.current.state !== 'closed') {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, [stopAudio]);

  return (
    <div className="flex items-center gap-2.5 py-1 px-1 select-none w-full max-w-[270px]">
      {/* Modern Round Play / Pause Button with Glow */}
      <button
        onClick={handleTogglePlay}
        className={`w-9 h-9 rounded-full flex items-center justify-center transition-all duration-200 active:scale-90 shrink-0 shadow-md ${
          isPlaying
            ? 'bg-gradient-to-r from-sky-400 to-indigo-500 text-white ring-2 ring-sky-400/40 shadow-sky-500/30'
            : isMe
            ? 'bg-white/25 hover:bg-white/35 text-white'
            : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-950/40'
        }`}
        title={isPlaying ? 'Pause Voice Note' : 'Play Voice Note'}
        aria-label={isPlaying ? 'Pause Voice Note' : 'Play Voice Note'}
      >
        {isPlaying ? (
          <Pause className="w-4 h-4 fill-current" />
        ) : (
          <Play className="w-4 h-4 fill-current ml-0.5" />
        )}
      </button>

      {/* Main Waveform Body */}
      <div className="flex-1 flex flex-col justify-center space-y-1 min-w-0">
        {/* Real-time HTML5 Canvas Waveform */}
        <div className="relative w-full h-8 flex items-center">
          <canvas
            ref={canvasRef}
            onClick={handleCanvasClick}
            className="w-full h-full cursor-pointer touch-none"
            title="Tap to scrub voice note"
          />
        </div>

        {/* Timestamp Readout & Speed Toggle */}
        <div className="flex items-center justify-between text-[10px] font-mono leading-none px-0.5">
          <div className="flex items-center gap-1 text-white/80">
            <span className="font-semibold">{isPlaying ? currentTimeFormatted : duration}</span>
            {isPlaying && (
              <span className="text-[9px] text-sky-300 font-normal">/ {duration}</span>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            {/* Speed Toggle Pill */}
            <button
              onClick={handleCycleSpeed}
              className="px-1.5 py-0.5 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-[9px] font-bold text-white/90 transition border border-white/10"
              title="Toggle playback speed (1x, 1.5x, 2x)"
            >
              {playbackSpeed}x
            </button>

            {isPlaying && (
              <div className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-ping" />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
