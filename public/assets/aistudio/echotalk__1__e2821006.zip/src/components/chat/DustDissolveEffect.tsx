import React, { useEffect, useRef } from 'react';

interface DustDissolveEffectProps {
  onComplete: () => void;
  width?: number;
  height?: number;
}

export default function DustDissolveEffect({
  onComplete,
  width = 240,
  height = 60
}: DustDissolveEffectProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = width;
    canvas.height = height;

    // Create particles matching Telegram dust effect
    const particleCount = 120;
    const particles: {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      alpha: number;
      color: string;
      life: number;
      maxLife: number;
    }[] = [];

    const colors = ['#818CF8', '#A78BFA', '#60A5FA', '#E0E7FF', '#F43F5E', '#CBD5E1'];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 3 + (Math.random() > 0.5 ? 1 : -1) * 1.5,
        vy: -Math.random() * 2.5 - 0.5,
        radius: Math.random() * 2.5 + 1,
        alpha: 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        life: 0,
        maxLife: 24 + Math.random() * 12
      });
    }

    let animationFrameId: number;
    const startTime = performance.now();
    const duration = 400; // 400ms Telegram dust effect

    const render = (time: number) => {
      const elapsed = time - startTime;
      const progress = Math.min(1, elapsed / duration);

      ctx.clearRect(0, 0, width, height);

      let allDead = true;

      for (const p of particles) {
        p.life++;
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.96;
        p.vy += 0.05; // slight gravity
        p.alpha = Math.max(0, 1 - progress);

        if (p.alpha > 0) {
          allDead = false;
          ctx.save();
          ctx.globalAlpha = p.alpha;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius * (1 - progress * 0.4), 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      }

      if (progress < 1 && !allDead) {
        animationFrameId = requestAnimationFrame(render);
      } else {
        onComplete();
      }
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [width, height, onComplete]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none z-30"
      style={{ willChange: 'transform, opacity' }}
    />
  );
}
