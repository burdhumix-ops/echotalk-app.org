import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, ArrowRight, ShieldCheck, Lock, User, UserPlus, LogIn, Crown } from 'lucide-react';
import { ThemeConfig } from '../types';

interface SplashScreenProps {
  onLogin: (userName: string, userRole?: 'owner' | 'admin' | 'member') => void;
  onOpenSecretPasscode: () => void;
  theme: ThemeConfig;
}

export default function SplashScreen({
  onLogin,
  onOpenSecretPasscode,
  theme
}: SplashScreenProps) {
  const [authMode, setAuthMode] = useState<'landing' | 'login' | 'signup'>('landing');
  const [usernameInput, setUsernameInput] = useState<string>('Zavier');
  const [passwordInput, setPasswordInput] = useState<string>('••••••••');
  
  // 8-second hold states
  const [holdProgress, setHoldProgress] = useState<number>(0); // 0 to 100%
  const [isHolding, setIsHolding] = useState<boolean>(false);
  const holdTimerRef = useRef<NodeJS.Timeout | null>(null);
  const holdIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const holdStartTimeRef = useRef<number>(0);

  const HOLD_DURATION_MS = 8000;

  const startHold = (e: React.SyntheticEvent) => {
    e.preventDefault();
    setIsHolding(true);
    holdStartTimeRef.current = Date.now();
    setHoldProgress(0);

    // Progress updater every 50ms
    holdIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - holdStartTimeRef.current;
      const pct = Math.min(100, (elapsed / HOLD_DURATION_MS) * 100);
      setHoldProgress(pct);
    }, 50);

    // 8 second trigger
    holdTimerRef.current = setTimeout(() => {
      clearHold();
      onOpenSecretPasscode();
    }, HOLD_DURATION_MS);
  };

  const clearHold = () => {
    setIsHolding(false);
    setHoldProgress(0);
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
    }
    if (holdIntervalRef.current) {
      clearInterval(holdIntervalRef.current);
      holdIntervalRef.current = null;
    }
  };

  useEffect(() => {
    return () => {
      if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
      if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex flex-col items-center justify-between p-6 select-none bg-slate-950">
      {/* Vivid Multi-Color Gradient Background with Glowing Floating Orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Orb 1: Violet/Indigo */}
        <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-gradient-to-br from-indigo-600/40 via-purple-600/30 to-pink-600/30 blur-3xl animate-pulse" />
        {/* Orb 2: Cyan/Emerald */}
        <div className="absolute top-1/3 -right-24 w-80 h-80 rounded-full bg-gradient-to-tr from-cyan-500/35 via-teal-500/25 to-emerald-500/30 blur-3xl animate-pulse delay-700" />
        {/* Orb 3: Rose/Amber bottom */}
        <div className="absolute -bottom-24 left-1/4 w-96 h-96 rounded-full bg-gradient-to-tl from-rose-500/30 via-amber-500/25 to-purple-600/25 blur-3xl" />
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 bg-[radial-gradient(rgba(255,255,255,0.06)_1px,transparent_1px)] [background-size:20px_20px] opacity-40" />
      </div>

      {/* Glassmorphic Layer: backdrop-filter: blur(24px) */}
      <div className="absolute inset-0 backdrop-blur-[24px] pointer-events-none" />

      {/* Top Header / Branding */}
      <div className="relative z-10 w-full max-w-md flex items-center justify-between pt-4">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-ping" />
          <span className="text-xs font-mono uppercase tracking-widest text-indigo-300/80">
            EchoTalk OS 3.0
          </span>
        </div>

        <span className="text-[11px] font-mono text-gray-400 bg-white/5 border border-white/10 px-2.5 py-1 rounded-full">
          Encrypted & Synced
        </span>
      </div>

      {/* Central Hero Section */}
      <div className="relative z-10 w-full max-w-sm my-auto flex flex-col items-center text-center space-y-6">
        
        {/* Interactive Logo with 8-Second Secret Press Trigger */}
        <div className="relative flex flex-col items-center">
          <div
            onMouseDown={startHold}
            onMouseUp={clearHold}
            onMouseLeave={clearHold}
            onTouchStart={startHold}
            onTouchEnd={clearHold}
            onTouchCancel={clearHold}
            className="relative cursor-pointer group active:scale-95 transition-transform"
            title="Press and hold 8s for secret terminal"
          >
            {/* Circular Progress Ring */}
            <svg className="w-24 h-24 transform -rotate-90">
              <circle
                cx="48"
                cy="48"
                r="44"
                className="stroke-white/10"
                strokeWidth="4"
                fill="transparent"
              />
              <circle
                cx="48"
                cy="48"
                r="44"
                className="stroke-indigo-400 transition-all duration-75"
                strokeWidth="4"
                fill="transparent"
                strokeDasharray={276.46}
                strokeDashoffset={276.46 - (276.46 * holdProgress) / 100}
                strokeLinecap="round"
              />
            </svg>

            {/* Logo Emblem in Center */}
            <div className="absolute inset-2 rounded-full bg-gradient-to-tr from-indigo-600 via-indigo-500 to-rose-500 p-0.5 shadow-2xl flex items-center justify-center">
              <div className="w-full h-full rounded-full bg-slate-950/80 backdrop-blur-md flex items-center justify-center text-white font-black text-2xl shadow-inner group-hover:scale-105 transition">
                ⚡
              </div>
            </div>
          </div>

          {/* Secret hold progress indicator feedback */}
          {isHolding && (
            <div className="mt-2 text-[10px] font-mono text-indigo-300 animate-pulse bg-indigo-950/80 px-2.5 py-1 rounded-full border border-indigo-500/30">
              Holding for Secret Terminal... {Math.round((holdProgress / 100) * 8 * 10) / 10}s / 8.0s
            </div>
          )}
        </div>

        {/* Title & Tagline */}
        <div className="space-y-2">
          <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight drop-shadow-md">
            EchoTalk
          </h1>
          <p className="text-sm text-gray-300 max-w-xs leading-relaxed font-normal">
            Next-generation glassmorphism social messenger, live audio lounges, and 1v1 arcade duels.
          </p>
        </div>

        {/* Auth Mode: Landing Buttons vs Input Form */}
        {authMode === 'landing' ? (
          <div className="w-full space-y-3 pt-4">
            <button
              onClick={() => onLogin('Zavier', 'owner')}
              className={`w-full py-3.5 rounded-2xl ${theme.accent} text-white font-bold text-sm shadow-xl active:scale-95 transition flex items-center justify-center gap-2 group`}
            >
              <span>Instant Launch (Continue as Zavier)</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => setAuthMode('login')}
                className="py-3 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs border border-white/15 backdrop-blur-md transition active:scale-95 flex items-center justify-center gap-1.5"
              >
                <LogIn className="w-3.5 h-3.5 text-indigo-400" />
                <span>Log In</span>
              </button>

              <button
                onClick={() => setAuthMode('signup')}
                className="py-3 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs border border-white/15 backdrop-blur-md transition active:scale-95 flex items-center justify-center gap-1.5"
              >
                <UserPlus className="w-3.5 h-3.5 text-rose-400" />
                <span>Sign Up</span>
              </button>
            </div>
          </div>
        ) : (
          /* Login / Sign Up Glass Form */
          <div className="w-full rounded-3xl bg-slate-900/80 border border-white/15 p-5 backdrop-blur-xl shadow-2xl space-y-3 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                {authMode === 'login' ? 'Account Log In' : 'Create New Account'}
              </span>
              <button
                onClick={() => setAuthMode('landing')}
                className="text-[11px] text-gray-400 hover:text-white"
              >
                Back
              </button>
            </div>

            <div className="space-y-2 text-left">
              <div>
                <label className="text-[10px] text-gray-400 uppercase font-semibold block mb-1">
                  Username
                </label>
                <div className="relative">
                  <User className="w-3.5 h-3.5 absolute left-3 top-3 text-gray-500" />
                  <input
                    type="text"
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    placeholder="Enter your handle..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950/80 border border-white/10 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-gray-400 uppercase font-semibold block mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-3.5 h-3.5 absolute left-3 top-3 text-gray-500" />
                  <input
                    type="password"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950/80 border border-white/10 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={() => onLogin(usernameInput.trim() || 'Zavier', 'member')}
              className={`w-full py-2.5 rounded-xl ${theme.accent} text-white font-bold text-xs shadow-md active:scale-95 transition mt-2`}
            >
              {authMode === 'login' ? 'Confirm & Enter' : 'Register Account'}
            </button>
          </div>
        )}

      </div>

      {/* Footer Info */}
      <div className="relative z-10 w-full max-w-sm text-center pt-4">
        <p className="text-[11px] text-gray-400/80">
          Tip: Hold the EchoTalk logo for 8 seconds to activate the Owner / Admin backdoor.
        </p>
      </div>
    </div>
  );
}
