import React, { useState } from 'react';
import { X, ShieldAlert, Lock, Unlock, Eye, Trash2, Download, Terminal, Search, AlertCircle } from 'lucide-react';
import { AdminVaultEntry, ThemeConfig } from '../types';

interface AdminVaultModalProps {
  onClose: () => void;
  vaultLogs: AdminVaultEntry[];
  onClearLogs: () => void;
  theme: ThemeConfig;
}

export default function AdminVaultModal({ onClose, vaultLogs, onClearLogs, theme }: AdminVaultModalProps) {
  const [selectedEntry, setSelectedEntry] = useState<AdminVaultEntry | null>(null);
  const [filterText, setFilterText] = useState<string>('');

  const filteredLogs = vaultLogs.filter(log =>
    log.sender.toLowerCase().includes(filterText.toLowerCase()) ||
    log.target.toLowerCase().includes(filterText.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-2xl flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl border border-red-500/40 bg-slate-950 p-5 space-y-4 shadow-2xl relative max-h-[90vh] flex flex-col">
        
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-red-500/30 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400">
              <ShieldAlert className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-red-400 tracking-wide uppercase">Admin Secret View-Once Logger</h2>
              <span className="text-[10px] text-gray-400">Classified Surveillance · View-Once Interceptor</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-white/10 text-gray-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning pill */}
        <div className="p-2.5 rounded-2xl bg-red-950/40 border border-red-500/30 flex items-start gap-2 text-[11px] text-red-200">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <span>
            <strong>Confidential Operator Notice:</strong> Media displayed here was sent with self-destruct "View Once" flags. The platform's secret admin logger intercepted the raw payload prior to client-side incineration.
          </span>
        </div>

        {/* Search & Actions Bar */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-gray-500" />
            <input
              type="text"
              placeholder="Search by sender or recipient..."
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
            />
          </div>
          {vaultLogs.length > 0 && (
            <button
              onClick={onClearLogs}
              className="p-2 rounded-xl bg-red-950/60 hover:bg-red-900/80 border border-red-500/40 text-red-300 transition text-xs flex items-center gap-1"
              title="Purge logs"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Purge</span>
            </button>
          )}
        </div>

        {/* Log Stream */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-[220px]">
          {filteredLogs.length === 0 ? (
            <div className="text-center py-12 text-gray-500 space-y-2">
              <Terminal className="w-8 h-8 mx-auto opacity-40 text-red-400" />
              <p className="text-xs">No intercepted view-once transmissions recorded yet.</p>
              <p className="text-[10px] text-gray-600">Send a view-once image or doodle in chat to see it appear here!</p>
            </div>
          ) : (
            filteredLogs.map((entry) => (
              <div
                key={entry.id}
                onClick={() => setSelectedEntry(entry)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  selectedEntry?.id === entry.id
                    ? 'bg-red-950/60 border-red-500/80 shadow-md'
                    : 'bg-slate-900/70 border-white/10 hover:border-red-500/40 hover:bg-slate-900'
                }`}
              >
                {/* Media thumbnail */}
                <div className="w-12 h-12 rounded-xl overflow-hidden bg-black/60 border border-white/10 shrink-0 relative flex items-center justify-center">
                  {entry.mediaUrl ? (
                    <img
                      src={entry.mediaUrl}
                      alt="Intercepted"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Eye className="w-5 h-5 text-gray-500" />
                  )}
                  <div className="absolute inset-0 bg-red-500/10 pointer-events-none" />
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-white truncate">
                    <span className="text-red-400">{entry.sender}</span>
                    <span className="text-gray-500">➔</span>
                    <span className="text-gray-300">{entry.target}</span>
                  </div>
                  <p className="text-[10px] text-gray-400 truncate mt-0.5">
                    {entry.previewText || '[ Encrypted Image Payload ]'}
                  </p>
                  <div className="flex items-center gap-2 mt-1 text-[9px] text-gray-500 font-mono">
                    <span>{entry.timestamp}</span>
                    <span>·</span>
                    <span className="text-emerald-400">{entry.interceptionStatus}</span>
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-red-500/10 text-red-400">
                  <Eye className="w-4 h-4" />
                </div>
              </div>
            ))
          )}
        </div>

        {/* Selected Image Detail Preview Modal */}
        {selectedEntry && (
          <div className="p-3 bg-black/80 rounded-2xl border border-red-500/40 space-y-2 animate-in zoom-in-95">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-red-300">Decrypted Payload Inspection:</span>
              <button
                onClick={() => setSelectedEntry(null)}
                className="text-[10px] text-gray-400 hover:text-white"
              >
                Close Preview
              </button>
            </div>
            <div className="max-h-48 overflow-hidden rounded-xl border border-white/20 bg-black flex items-center justify-center">
              {selectedEntry.mediaUrl ? (
                <img
                  src={selectedEntry.mediaUrl}
                  alt="Full Intercepted"
                  referrerPolicy="no-referrer"
                  className="max-h-48 w-full object-contain"
                />
              ) : (
                <p className="text-xs text-gray-400 p-4">{selectedEntry.previewText}</p>
              )}
            </div>
            <p className="text-[10px] text-gray-400 text-center font-mono">
              Intercepted from: {selectedEntry.sender} · Recipient: {selectedEntry.target} · Timestamp: {selectedEntry.timestamp}
            </p>
          </div>
        )}

      </div>
    </div>
  );
}
