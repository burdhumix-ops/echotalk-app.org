import React, { useState } from 'react';
import { 
  X, Palette, EyeOff, Eye, Ban, Trash2, ShieldCheck, UserCheck, 
  Sparkles, Check, AlertTriangle, Moon, Sun, ArrowLeft, Crown, 
  Sliders, KeyRound, Type, ToggleLeft, ToggleRight, LogOut, CheckCircle2, Lock
} from 'lucide-react';
import { ThemeConfig, ThemeKey, BlockedUser, OwnerConfig } from '../types';
import { THEMES } from '../themes';

interface SettingsModalProps {
  onClose: () => void;
  activeTheme: ThemeKey;
  setActiveTheme: (theme: ThemeKey) => void;
  blockedUsers: BlockedUser[];
  onUnblockUser: (id: number) => void;
  currentUser: { 
    name: string; 
    role: 'owner' | 'admin' | 'member'; 
    isHidden: boolean; 
    bio: string;
    age?: number;
    country?: string;
    countryCode?: string;
  };
  setCurrentUser: React.Dispatch<React.SetStateAction<any>>;
  onDeleteAccount: () => void;
  ownerConfig: OwnerConfig;
  setOwnerConfig: React.Dispatch<React.SetStateAction<OwnerConfig>>;
  onLogout: () => void;
  onPreviewProfile?: () => void;
  theme: ThemeConfig;
}

export default function SettingsModal({
  onClose,
  activeTheme,
  setActiveTheme,
  blockedUsers,
  onUnblockUser,
  currentUser,
  setCurrentUser,
  onDeleteAccount,
  ownerConfig,
  setOwnerConfig,
  onLogout,
  onPreviewProfile,
  theme
}: SettingsModalProps) {
  const isOwner = currentUser.role === 'owner';
  const [activeTab, setActiveTab] = useState<'themes' | 'privacy' | 'blocked' | 'owner' | 'account'>('themes');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);
  const [tempName, setTempName] = useState<string>(currentUser.name);
  const [tempAge, setTempAge] = useState<number>(currentUser.age || 24);

  // Owner state drafts
  const [newAdminPin, setNewAdminPin] = useState<string>(ownerConfig.adminPin);
  const [newOwnerPin, setNewOwnerPin] = useState<string>(ownerConfig.ownerPin);
  const [tabLabelsDraft, setTabLabelsDraft] = useState({
    Discover: ownerConfig.tabLabels.Discover || 'Discover',
    Lounge: ownerConfig.tabLabels.Lounge || ownerConfig.tabLabels.Rooms || 'Lounge',
    DMs: ownerConfig.tabLabels.DMs || 'DMs',
    Arcade: ownerConfig.tabLabels.Arcade || ownerConfig.tabLabels.Games || 'Arcade',
    Profile: ownerConfig.tabLabels.Profile || 'Profile'
  });
  const [savedOwnerNotification, setSavedOwnerNotification] = useState<string>('');

  // 5 Unified Dynamic Theme options
  const themeList = [
    THEMES['classic'],
    THEMES['ios-glass'],
    THEMES['warm-sand'],
    THEMES['midnight-emerald'],
    THEMES['obsidian']
  ].filter(Boolean);

  const handleSaveOwnerSettings = () => {
    if (newAdminPin.length !== 4 || !/^\d{4}$/.test(newAdminPin)) {
      setSavedOwnerNotification('Admin PIN must be exactly 4 digits');
      return;
    }
    if (newOwnerPin.length !== 4 || !/^\d{4}$/.test(newOwnerPin)) {
      setSavedOwnerNotification('Owner PIN must be exactly 4 digits');
      return;
    }

    setOwnerConfig((prev) => ({
      ...prev,
      adminPin: newAdminPin,
      ownerPin: newOwnerPin,
      tabLabels: { ...prev.tabLabels, ...tabLabelsDraft }
    }));

    setSavedOwnerNotification('Owner settings saved successfully!');
    setTimeout(() => setSavedOwnerNotification(''), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-2xl flex items-end sm:items-center justify-center p-0 sm:p-4 select-none animate-in fade-in duration-200">
      <div className={`w-full max-w-lg rounded-t-3xl sm:rounded-3xl border ${theme.cardBorder} ${theme.card} p-5 space-y-4 shadow-2xl max-h-[92vh] flex flex-col text-slate-100`}>
        
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold tracking-tight flex items-center gap-2">
              <span>Settings & Preferences</span>
              {isOwner && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Owner Active
                </span>
              )}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-white/10 text-gray-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Segmented Navigation */}
        <div className="flex p-1 bg-black/30 rounded-2xl border border-white/5 overflow-x-auto scrollbar-none gap-1">
          <button
            onClick={() => setActiveTab('themes')}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 shrink-0 ${
              activeTab === 'themes' ? `${theme.accent} text-white shadow-md` : 'text-gray-400 hover:text-white'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Theme</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 shrink-0 ${
              activeTab === 'privacy' ? `${theme.accent} text-white shadow-md` : 'text-gray-400 hover:text-white'
            }`}
          >
            <EyeOff className="w-3.5 h-3.5" />
            <span>Profile</span>
          </button>

          <button
            onClick={() => setActiveTab('blocked')}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 shrink-0 ${
              activeTab === 'blocked' ? `${theme.accent} text-white shadow-md` : 'text-gray-400 hover:text-white'
            }`}
          >
            <Ban className="w-3.5 h-3.5" />
            <span>Blocked</span>
          </button>

          {isOwner && (
            <button
              onClick={() => setActiveTab('owner')}
              className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shrink-0 ${
                activeTab === 'owner' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-amber-400 hover:text-amber-300'
              }`}
            >
              <Crown className="w-3.5 h-3.5" />
              <span>Owner</span>
            </button>
          )}

          <button
            onClick={() => setActiveTab('account')}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 shrink-0 ${
              activeTab === 'account' ? 'bg-red-600 text-white shadow-md' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Session</span>
          </button>
        </div>

        {/* TAB 1: 5 UNIFIED DYNAMIC THEME SELECTOR */}
        {activeTab === 'themes' && (
          <div className="space-y-3 overflow-y-auto max-h-[60vh] pr-1">
            <div className="text-xs text-gray-400">
              Select one of the 5 unified dynamic theme palettes. Dynamic adaptive contrast guarantees legible text on all backgrounds:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {themeList.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setActiveTheme(t.id)}
                  className={`p-3.5 rounded-2xl border text-left transition-all relative overflow-hidden flex flex-col justify-between h-28 ${
                    activeTheme === t.id
                      ? `border-white ring-2 ring-white/40 ${t.bg} shadow-xl scale-[1.02]`
                      : `border-white/10 hover:border-white/20 ${t.bg} opacity-85`
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <div>
                      <span className={`text-xs font-bold truncate block ${t.text}`}>{t.name}</span>
                      <span className={`text-[10px] ${t.textMuted}`}>{t.isDark ? 'Dark Mode' : 'Light Mode'}</span>
                    </div>
                    {activeTheme === t.id && (
                      <div className="w-5 h-5 rounded-full bg-white text-black flex items-center justify-center shrink-0 shadow">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <div className={`w-5 h-5 rounded-full ${t.accent} shadow-md`} />
                    <div className="w-5 h-5 rounded-full bg-white/20 border border-white/30" />
                    <div className="w-5 h-5 rounded-full bg-slate-900 border border-white/20" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* TAB 2: PRIVACY & PROFILE PREFERENCES */}
        {activeTab === 'privacy' && (
          <div className="space-y-4 overflow-y-auto max-h-[60vh] pr-1 text-xs">
            {/* Preview Profile Button */}
            {onPreviewProfile && (
              <button
                onClick={() => {
                  onPreviewProfile();
                  onClose();
                }}
                className="w-full py-3 rounded-2xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-bold transition flex items-center justify-center gap-2 shadow"
              >
                <Eye className="w-4 h-4" />
                <span>Preview 100% Full-Screen Profile</span>
              </button>
            )}

            {/* Ghost Mode Toggle */}
            <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 flex items-center justify-between">
              <div className="space-y-0.5 max-w-[80%]">
                <span className="font-semibold text-white flex items-center gap-1.5">
                  <EyeOff className="w-4 h-4 text-indigo-400" />
                  Hide Account (Ghost Mode)
                </span>
                <p className="text-[11px] text-gray-400">
                  When enabled, your profile and 10-photo grid are hidden from the Discover and Lounge directories.
                </p>
              </div>
              <button
                onClick={() => setCurrentUser((prev: any) => ({ ...prev, isHidden: !prev.isHidden }))}
                className={`w-12 h-7 rounded-full p-1 transition-colors ${
                  currentUser.isHidden ? theme.accent : 'bg-white/20'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    currentUser.isHidden ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Display Name Edit */}
            <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 space-y-2">
              <span className="font-semibold text-white block">Display Name</span>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-white text-xs focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={() => setCurrentUser((prev: any) => ({ ...prev, name: tempName }))}
                  className={`px-3 py-2 rounded-xl ${theme.accent} text-white font-semibold transition`}
                >
                  Save
                </button>
              </div>
            </div>

            {/* Age Input Management */}
            <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 space-y-2">
              <span className="font-semibold text-white block">Age (Years)</span>
              <div className="flex gap-2">
                <input
                  type="number"
                  min={18}
                  max={100}
                  value={tempAge}
                  onChange={(e) => setTempAge(Number(e.target.value))}
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-white text-xs focus:outline-none focus:border-indigo-500 font-mono"
                />
                <button
                  onClick={() => setCurrentUser((prev: any) => ({ ...prev, age: tempAge }))}
                  className={`px-3 py-2 rounded-xl ${theme.accent} text-white font-semibold transition`}
                >
                  Update Age
                </button>
              </div>
            </div>

            {/* Automatic IP-Based Location (Locked) */}
            <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Country & Region (Locked)</span>
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">IP Verified</span>
              </div>
              <p className="text-[11px] text-gray-300">
                {currentUser.country || 'United States'} ({currentUser.countryCode || 'US'})
              </p>
              <p className="text-[10px] text-gray-500">
                Detected automatically from your connection IP to prevent location spoofing.
              </p>
            </div>

            {/* Role Switcher */}
            <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 space-y-2">
              <span className="font-semibold text-white flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                Role Permissions Switcher:
              </span>
              <p className="text-[10px] text-gray-400">
                Current role: <strong className="text-white uppercase">{currentUser.role}</strong>
              </p>
              <div className="grid grid-cols-3 gap-2 pt-1">
                {(['owner', 'admin', 'member'] as const).map((r) => (
                  <button
                    key={r}
                    onClick={() => setCurrentUser((prev: any) => ({ ...prev, role: r }))}
                    className={`py-2 rounded-xl capitalize font-semibold transition ${
                      currentUser.role === r
                        ? `${theme.accent} text-white shadow-md`
                        : 'bg-white/5 text-gray-400 hover:text-white'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: BLOCKED USERS */}
        {activeTab === 'blocked' && (
          <div className="space-y-3 overflow-y-auto max-h-[60vh] pr-1">
            <div className="text-xs text-gray-400 flex items-center justify-between">
              <span>Blocked Users List ({blockedUsers.length})</span>
              <span className="text-[10px] text-gray-500">Tap unblock to restore</span>
            </div>

            {blockedUsers.length === 0 ? (
              <div className="text-center py-12 text-gray-500 space-y-2">
                <UserCheck className="w-8 h-8 mx-auto text-emerald-400 opacity-60" />
                <p className="text-xs">No blocked users on your account.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {blockedUsers.map((user) => (
                  <div
                    key={user.id}
                    className="p-3 rounded-2xl bg-black/30 border border-white/10 flex items-center justify-between"
                  >
                    <div>
                      <h4 className="text-xs font-semibold text-white">{user.name}</h4>
                      <span className="text-[10px] text-gray-400">{user.handle} · Blocked</span>
                    </div>
                    <button
                      onClick={() => onUnblockUser(user.id)}
                      className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-emerald-600/30 hover:text-emerald-300 text-xs text-gray-300 transition font-semibold"
                    >
                      Unblock
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: EXCLUSIVE OWNER SUITE */}
        {activeTab === 'owner' && isOwner && (
          <div className="space-y-4 overflow-y-auto max-h-[60vh] pr-1 text-xs">
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2.5 text-amber-300">
              <Crown className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <strong className="block font-bold">Owner Management Dashboard</strong>
                <span className="text-[11px] text-amber-300/80">
                  Full authority over secret passcodes, tab names, and core app mechanics.
                </span>
              </div>
            </div>

            {savedOwnerNotification && (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{savedOwnerNotification}</span>
              </div>
            )}

            {/* Secret 4-Digit Passcodes */}
            <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 space-y-3">
              <span className="font-bold text-white flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-indigo-400" />
                Secret 4-Digit Backdoor Passcodes
              </span>
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="text-[10px] uppercase font-mono text-gray-400 block mb-1">
                    Admin PIN Code
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    value={newAdminPin}
                    onChange={(e) => setNewAdminPin(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-white font-mono text-center tracking-widest text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] uppercase font-mono text-gray-400 block mb-1">
                    Owner PIN Code
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    value={newOwnerPin}
                    onChange={(e) => setNewOwnerPin(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-amber-300 font-mono text-center tracking-widest text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            </div>

            {/* Rename 5 Tabs */}
            <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 space-y-3">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Type className="w-4 h-4 text-indigo-400" />
                Dynamic Tab Navigation Labels (5 Tabs)
              </span>
              <div className="grid grid-cols-2 gap-2.5">
                {['Discover', 'Lounge', 'DMs', 'Arcade', 'Profile'].map((tabKey) => (
                  <div key={tabKey}>
                    <label className="text-[10px] text-gray-400 uppercase font-mono block mb-1">
                      {tabKey}
                    </label>
                    <input
                      type="text"
                      value={(tabLabelsDraft as any)[tabKey] || tabKey}
                      onChange={(e) => {
                        const val = e.target.value;
                        setTabLabelsDraft((prev) => ({ ...prev, [tabKey]: val }));
                      }}
                      className="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-white/10 text-white text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={handleSaveOwnerSettings}
              className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg active:scale-95 transition"
            >
              Apply All Owner Suite Changes
            </button>
          </div>
        )}

        {/* TAB 5: ACCOUNT SESSION & LOG OUT */}
        {activeTab === 'account' && (
          <div className="space-y-4 py-2 text-xs">
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white">Active Session: {currentUser.name}</h4>
                  <span className="text-[11px] text-gray-400">
                    Role: <strong className="text-indigo-400 uppercase">{currentUser.role}</strong>
                  </span>
                </div>
                <button
                  onClick={() => {
                    onLogout();
                    onClose();
                  }}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-1.5 transition active:scale-95"
                >
                  <LogOut className="w-3.5 h-3.5 text-rose-400" />
                  <span>Log Out / Sign In</span>
                </button>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-red-950/40 border border-red-500/30 space-y-2 text-red-200">
              <div className="flex items-center gap-2 text-red-400 font-bold">
                <AlertTriangle className="w-4 h-4" />
                <span>Delete Account & Purge Data</span>
              </div>
              <p className="text-[11px] text-red-300/80 leading-relaxed">
                Permanently delete account and local data.
              </p>
            </div>

            {!showDeleteConfirm ? (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="w-full py-3 rounded-2xl bg-red-600/80 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete My EchoTalk Account</span>
              </button>
            ) : (
              <div className="p-4 rounded-2xl bg-black/60 border border-red-500/50 space-y-3">
                <span className="text-xs font-bold text-white block text-center">
                  Are you absolutely sure?
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      onDeleteAccount();
                      onClose();
                    }}
                    className="flex-1 py-2.5 rounded-xl bg-red-600 text-white text-xs font-bold hover:bg-red-500 transition"
                  >
                    Yes, Permanently Delete
                  </button>
                  <button
                    onClick={() => setShowDeleteConfirm(false)}
                    className="px-4 py-2.5 rounded-xl bg-white/10 text-gray-300 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
