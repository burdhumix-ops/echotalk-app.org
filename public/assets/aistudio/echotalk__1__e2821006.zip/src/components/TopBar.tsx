import React, { useState, useRef, useEffect } from 'react';
import { Settings, Smartphone, Monitor } from 'lucide-react';
import { ThemeConfig, OwnerConfig } from '../types';

interface TopBarProps {
  theme: ThemeConfig;
  onOpenSettings: () => void;
  isPhoneFrame: boolean;
  onTogglePhoneFrame: () => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  pendingRequestsCount: number;
  ownerConfig?: OwnerConfig;
  onTriggerSecretPasscode?: () => void;
  currentUser?: {
    name: string;
    avatarUrl?: string;
    avatarColor?: string;
    isHidden: boolean;
  };
}

export default function TopBar({
  theme,
  onOpenSettings,
  isPhoneFrame,
  onTogglePhoneFrame,
  activeTab,
  onSelectTab,
  pendingRequestsCount,
  ownerConfig,
  onTriggerSecretPasscode,
  currentUser
}: TopBarProps) {
  // 8-second long-press on logo
  const [holdProgress, setHoldProgress] = useState<number>(0);
  const [isHolding, setIsHolding] = useState<boolean>(false);
  const holdTimerRef = useRef<NodeJS.Timeout | null>(null);
  const holdIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const holdStartTimeRef = useRef<number>(0);

  const HOLD_DURATION_MS = 8000;

  const startHold = (e: React.SyntheticEvent) => {
    e.preventDefault();
    if (!onTriggerSecretPasscode) return;
    setIsHolding(true);
    holdStartTimeRef.current = Date.now();
    setHoldProgress(0);

    holdIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - holdStartTimeRef.current;
      const pct = Math.min(100, (elapsed / HOLD_DURATION_MS) * 100);
      setHoldProgress(pct);
    }, 50);

    holdTimerRef.current = setTimeout(() => {
      clearHold();
      onTriggerSecretPasscode();
    }, HOLD_DURATION_MS);
  };

  const clearHold = () => {
    setIsHolding(false);
    setHoldProgress(0);
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
    }
    if (holdIntervalRef.current) {
      clearInterval(holdIntervalRef.current);
      holdIntervalRef.current = null;
    }
  };

  useEffect(() => {
    return () => {
      if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
      if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
    };
  }, []);

  const labels = ownerConfig?.tabLabels || {
    Discover: 'Discover',
    Lounge: 'Lounge',
    DMs: 'DMs',
    Arcade: 'Arcade',
    Profile: 'Profile'
  };

  const tabs = [
    { id: 'Discover', label: labels.Discover || 'Discover' },
    { id: 'Lounge', label: labels.Lounge || labels.Rooms || 'Lounge' },
    { id: 'DMs', label: labels.DMs || 'DMs', badge: pendingRequestsCount },
    { id: 'Arcade', label: labels.Arcade || labels.Games || 'Arcade' },
    { id: 'Profile', label: labels.Profile || 'Profile' }
  ];

  return (
    <header className={`h-16 px-4 sm:px-6 flex items-center justify-between gap-6 border-b ${theme.border} ${theme.surface} z-30 shrink-0 select-none shadow-sm`}>
      {/* Zone 1: Single text wordmark with 8-second secret logo hold */}
      <div className="flex items-center gap-2.5 shrink-0 relative">
        <div
          onMouseDown={startHold}
          onMouseUp={clearHold}
          onMouseLeave={clearHold}
          onTouchStart={startHold}
          onTouchEnd={clearHold}
          onTouchCancel={clearHold}
          className="relative cursor-pointer flex items-center gap-2 group p-1 -m-1 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition"
          title="Hold 8s for secret terminal"
        >
          {/* Logo indicator with animated progress ring when held */}
          <div className="relative w-7 h-7 flex items-center justify-center">
            {isHolding && (
              <svg className="w-8 h-8 absolute inset-0 -top-0.5 -left-0.5 transform -rotate-90">
                <circle
                  cx="16"
                  cy="16"
                  r="14"
                  className={theme.isDark ? 'stroke-indigo-400' : 'stroke-blue-600'}
                  strokeWidth="2.5"
                  fill="transparent"
                  strokeDasharray={87.96}
                  strokeDashoffset={87.96 - (87.96 * holdProgress) / 100}
                />
              </svg>
            )}
            <div className={`w-3.5 h-3.5 rounded-full ${theme.accent} shadow-md group-hover:scale-110 transition`} />
          </div>

          <span className={`text-lg font-black tracking-tight whitespace-nowrap ${theme.text}`}>
            EchoTalk
          </span>
        </div>

        {/* Floating progress badge during 8s hold */}
        {isHolding && (
          <div className="absolute top-12 left-0 z-40 bg-slate-900 border border-indigo-500/40 px-2.5 py-1 rounded-xl shadow-xl text-[10px] text-indigo-300 font-mono whitespace-nowrap animate-pulse">
            Hold for secret PIN terminal... {Math.round((holdProgress / 100) * 8 * 10) / 10}s
          </div>
        )}
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-semibold">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id || (tab.id === 'Lounge' && activeTab === 'Rooms') || (tab.id === 'Arcade' && activeTab === 'Games');
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 py-1 ${
                isActive 
                  ? `${theme.text} border-b-2 ${theme.isDark ? 'border-indigo-400' : 'border-blue-600'} font-bold` 
                  : `${theme.textMuted} hover:${theme.text}`
              }`}
            >
              <span>{tab.label}</span>
              {tab.badge && tab.badge > 0 ? (
                <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] flex items-center justify-center">
                  {tab.badge}
                </span>
              ) : null}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Actions & User Avatar */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Mobile / Desktop Viewport preview toggle */}
        <button
          onClick={onTogglePhoneFrame}
          className={`p-2 rounded-xl transition text-xs hidden lg:flex items-center gap-1.5 ${
            theme.isDark ? 'bg-white/5 hover:bg-white/10 text-gray-300' : 'bg-black/5 hover:bg-black/10 text-gray-700'
          }`}
          title={isPhoneFrame ? 'Expand to Desktop View' : 'Switch to iPhone Frame'}
        >
          {isPhoneFrame ? <Monitor className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
          <span className="text-[11px] font-medium">{isPhoneFrame ? 'Desktop' : 'iOS Frame'}</span>
        </button>

        {/* Profile Avatar Button with Ghost Mode Ring */}
        {currentUser && (
          <button
            onClick={() => onSelectTab('Profile')}
            className="relative group transition active:scale-95"
            title={currentUser.isHidden ? `${currentUser.name} (Ghost Mode Active)` : `${currentUser.name} (Public)`}
          >
            <div className={`w-8 h-8 rounded-full overflow-hidden border ${
              currentUser.isHidden ? 'border-amber-400 ring-2 ring-amber-400/30' : 'border-indigo-400 ring-1 ring-white/20'
            } ${currentUser.avatarColor || theme.accent} flex items-center justify-center font-bold text-xs text-white shadow-sm`}>
              {currentUser.avatarUrl ? (
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                currentUser.name[0]
              )}
            </div>
            {/* Status dot */}
            <div
              className={`w-2.5 h-2.5 rounded-full absolute -bottom-0.5 -right-0.5 border border-slate-950 ${
                currentUser.isHidden ? 'bg-amber-400' : 'bg-emerald-400'
              }`}
            />
          </button>
        )}

        <button
          onClick={onOpenSettings}
          className={`p-2.5 rounded-full transition active:scale-95 ${
            theme.isDark ? 'hover:bg-white/10 text-gray-300 hover:text-white' : 'hover:bg-black/5 text-gray-600 hover:text-black'
          }`}
          aria-label="Settings"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
}
