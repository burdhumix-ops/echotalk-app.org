import React from 'react';
import { Compass, Radio, MessageSquare, Gamepad2, User } from 'lucide-react';
import { ThemeConfig, OwnerConfig } from '../types';
import { hapticTap } from '../utils/haptics';

interface BottomNavProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  theme: ThemeConfig;
  pendingRequestsCount: number;
  ownerConfig?: OwnerConfig;
}

export default function BottomNav({
  activeTab,
  onSelectTab,
  theme,
  pendingRequestsCount,
  ownerConfig
}: BottomNavProps) {
  const labels = ownerConfig?.tabLabels || {
    Discover: 'Discover',
    Lounge: 'Lounge',
    DMs: 'DMs',
    Arcade: 'Arcade',
    Profile: 'Profile'
  };

  const tabs = [
    { id: 'Discover', label: labels.Discover || 'Discover', icon: Compass },
    { id: 'Lounge', label: labels.Lounge || labels.Rooms || 'Lounge', icon: Radio },
    { id: 'DMs', label: labels.DMs || 'DMs', icon: MessageSquare, badge: pendingRequestsCount },
    { id: 'Arcade', label: labels.Arcade || labels.Games || 'Arcade', icon: Gamepad2 },
    { id: 'Profile', label: labels.Profile || 'Profile', icon: User }
  ];

  return (
    <nav 
      style={{ paddingBottom: 'max(8px, env(safe-area-inset-bottom))' }}
      className={`h-auto min-h-16 py-1 px-3 flex items-center justify-around ${theme.navBg || theme.surface} shrink-0 z-30 select-none shadow-[0_-4px_24px_rgba(0,0,0,0.1)] border-t ${theme.border}`}
    >
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id || (tab.id === 'Lounge' && activeTab === 'Rooms') || (tab.id === 'Arcade' && activeTab === 'Games');

        return (
          <button
            key={tab.id}
            onClick={() => {
              hapticTap(10);
              onSelectTab(tab.id);
            }}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-all duration-200 relative group active:scale-95`}
          >
            <div className={`px-4 py-1.5 rounded-2xl relative transition-all duration-300 flex items-center justify-center ${
              isActive 
                ? (theme.isDark ? `${theme.accent} shadow-md ${theme.accentGlow}` : `${theme.accent} shadow-md`)
                : 'bg-transparent hover:bg-black/5 dark:hover:bg-white/5'
            }`}>
              <Icon className={`w-5 h-5 transition-colors duration-200 ${
                isActive 
                  ? 'text-white' 
                  : (theme.isDark ? 'text-slate-400 group-hover:text-slate-200' : 'text-slate-500 group-hover:text-slate-800')
              }`} />
              
              {tab.badge && tab.badge > 0 ? (
                <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center shadow-sm">
                  {tab.badge}
                </div>
              ) : null}
            </div>

            <span className={`text-[10px] font-semibold mt-0.5 tracking-tight transition-colors duration-200 ${
              isActive 
                ? (theme.isDark ? 'text-white font-bold' : `${theme.accentText} font-bold`)
                : (theme.isDark ? 'text-slate-400' : 'text-slate-500')
            }`}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
