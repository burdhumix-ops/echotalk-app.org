import React, { useState } from 'react';
import { ArrowLeft, Trophy, Swords, Bot, Sparkles, Volume2 } from 'lucide-react';
import { GameChallengeData, ThemeConfig } from '../../types';
import ChessGame from './ChessGame';
import LudoGame from './LudoGame';

interface OneOnOneMatchModalProps {
  challenge: GameChallengeData;
  onClose: () => void;
  theme: ThemeConfig;
}

export default function OneOnOneMatchModal({
  challenge,
  onClose,
  theme
}: OneOnOneMatchModalProps) {
  const isChess = challenge.game === 'chess';
  const isLudo = challenge.game === 'ludo';
  const [selectedDifficulty, setSelectedDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');

  return (
    <div className={`fixed inset-0 z-50 flex flex-col ${theme.bg} ${theme.text} select-none animate-in fade-in duration-200 overflow-hidden`}>
      {/* 1v1 Match Top Navigation Header */}
      <header className={`h-16 px-4 flex items-center justify-between border-b ${theme.border} ${theme.surface} frosted-glass shrink-0 z-30`}>
        <button
          onClick={onClose}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Exit to Chat</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Swords className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight">
              1v1 {isChess ? 'Chess Duel' : 'Ludo Master'}
            </h2>
            <span className="text-[10px] text-gray-400 font-mono">
              Live In-DM Challenge Match
            </span>
          </div>
        </div>

        {/* Difficulty Level Selector for AI / Practice matches */}
        {isChess && (
          <div className="flex items-center gap-1 p-0.5 bg-black/40 rounded-xl border border-white/10 text-[10px]">
            <span className="text-gray-400 px-1 hidden sm:inline">AI:</span>
            {(['easy', 'medium', 'hard'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setSelectedDifficulty(lvl)}
                className={`px-2 py-0.5 rounded-lg capitalize font-medium transition ${
                  selectedDifficulty === lvl
                    ? 'bg-amber-400 text-slate-950 font-bold shadow'
                    : 'text-gray-400 hover:text-white'
                }`}
                title={`Set AI Bot to ${lvl === 'hard' ? 'Grandmaster' : lvl}`}
              >
                {lvl === 'hard' ? 'GM' : lvl}
              </button>
            ))}
          </div>
        )}

        {!isChess && <div className="w-16" />}
      </header>

      {/* Versus Player HUD Banner */}
      <div className="bg-black/40 border-b border-white/10 px-4 py-2 flex items-center justify-around text-xs">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-indigo-600 flex items-center justify-center font-bold text-white shadow text-xs">
            {challenge.challenger[0]}
          </div>
          <div>
            <span className="font-bold text-white block truncate max-w-[100px]">
              {challenge.challenger}
            </span>
            <span className="text-[10px] text-indigo-300 font-mono">
              {isChess ? 'White Pieces' : 'Red Yard'}
            </span>
          </div>
        </div>

        <div className="flex flex-col items-center">
          <span className="text-xs font-black text-amber-400 font-mono tracking-widest">VS</span>
          <span className="text-[9px] text-gray-400 font-mono">
            {isChess ? `AI: ${selectedDifficulty === 'hard' ? 'Grandmaster' : selectedDifficulty}` : 'SYNCED'}
          </span>
        </div>

        <div className="flex items-center gap-2 text-right">
          <div>
            <span className="font-bold text-white block truncate max-w-[100px]">
              {challenge.opponent}
            </span>
            <span className="text-[10px] text-emerald-300 font-mono">
              {isChess ? 'Black Pieces' : 'Green Yard'}
            </span>
          </div>
          <div className="w-7 h-7 rounded-xl bg-purple-600 flex items-center justify-center font-bold text-white shadow text-xs">
            {challenge.opponent[0]}
          </div>
        </div>
      </div>

      {/* Dedicated Interactive Game Board */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 flex items-center justify-center">
        <div className="w-full max-w-md">
          {isChess && (
            <ChessGame
              theme={theme}
              isFullScreen={true}
              initialDifficulty={selectedDifficulty}
              challengeMatch={{
                playerWhite: challenge.challenger,
                playerBlack: challenge.opponent,
                gameTitle: '1v1 Chess'
              }}
              onClose={onClose}
            />
          )}

          {isLudo && (
            <LudoGame
              theme={theme}
              isFullScreen={true}
              challengeMatch={{
                playerRed: challenge.challenger,
                playerGreen: challenge.opponent,
                gameTitle: '1v1 Ludo'
              }}
              onClose={onClose}
            />
          )}
        </div>
      </div>
    </div>
  );
}
