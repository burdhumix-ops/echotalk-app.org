import React, { useState } from 'react';
import { RotateCcw, Bot, User, Crown, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { ThemeConfig } from '../../types';

interface CheckersGameProps {
  theme: ThemeConfig;
  onClose: () => void;
}

type CheckersColor = 'red' | 'black';

interface CheckersPiece {
  color: CheckersColor;
  isKing: boolean;
}

type BoardState = (CheckersPiece | null)[][];

function createInitialBoard(): BoardState {
  const board: BoardState = Array(8).fill(null).map(() => Array(8).fill(null));
  // Black on top (rows 0, 1, 2) on dark squares
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 8; c++) {
      if ((r + c) % 2 === 1) {
        board[r][c] = { color: 'black', isKing: false };
      }
    }
  }
  // Red on bottom (rows 5, 6, 7) on dark squares
  for (let r = 5; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if ((r + c) % 2 === 1) {
        board[r][c] = { color: 'red', isKing: false };
      }
    }
  }
  return board;
}

export default function CheckersGame({ theme, onClose }: CheckersGameProps) {
  const [board, setBoard] = useState<BoardState>(createInitialBoard);
  const [turn, setTurn] = useState<CheckersColor>('red');
  const [selectedPos, setSelectedPos] = useState<[number, number] | null>(null);
  const [vsBot, setVsBot] = useState<boolean>(true);
  const [redCaptured, setRedCaptured] = useState<number>(0); // Captured by black
  const [blackCaptured, setBlackCaptured] = useState<number>(0); // Captured by red
  const [statusMessage, setStatusMessage] = useState<string>('Red to move. Tap a red checker.');

  const getMovesForPiece = (r: number, c: number, currentBoard: BoardState) => {
    const piece = currentBoard[r][c];
    if (!piece) return { regular: [], jumps: [] };

    const regular: [number, number][] = [];
    const jumps: { to: [number, number]; jumped: [number, number] }[] = [];

    const dirs: number[] = [];
    if (piece.color === 'red' || piece.isKing) dirs.push(-1); // Up
    if (piece.color === 'black' || piece.isKing) dirs.push(1); // Down

    dirs.forEach(dr => {
      [-1, 1].forEach(dc => {
        const nr = r + dr;
        const nc = c + dc;
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          if (!currentBoard[nr][nc]) {
            regular.push([nr, nc]);
          } else if (currentBoard[nr][nc]?.color !== piece.color) {
            // Check for jump
            const jnr = r + 2 * dr;
            const jnc = c + 2 * dc;
            if (jnr >= 0 && jnr < 8 && jnc >= 0 && jnc < 8 && !currentBoard[jnr][jnc]) {
              jumps.push({ to: [jnr, jnc], jumped: [nr, nc] });
            }
          }
        }
      });
    });

    return { regular, jumps };
  };

  const handleCellClick = (r: number, c: number) => {
    const cell = board[r][c];

    if (!selectedPos) {
      if (cell && cell.color === turn) {
        setSelectedPos([r, c]);
        setStatusMessage(`Selected checker at [${r}, ${c}].`);
      }
      return;
    }

    const [selR, selC] = selectedPos;
    const selectedPiece = board[selR][selC];
    if (!selectedPiece) {
      setSelectedPos(null);
      return;
    }

    // Clicking own piece switches selection
    if (cell && cell.color === turn) {
      if (selR === r && selC === c) {
        setSelectedPos(null);
        setStatusMessage(`${turn === 'red' ? 'Red' : 'Black'} to move.`);
      } else {
        setSelectedPos([r, c]);
      }
      return;
    }

    const { regular, jumps } = getMovesForPiece(selR, selC, board);
    const jumpMove = jumps.find(j => j.to[0] === r && j.to[1] === c);
    const regularMove = regular.some(([rr, rc]) => rr === r && rc === c);

    if (jumpMove) {
      executeJump(selR, selC, jumpMove.to[0], jumpMove.to[1], jumpMove.jumped[0], jumpMove.jumped[1]);
    } else if (regularMove) {
      executeRegular(selR, selC, r, c);
    } else {
      setStatusMessage('Invalid square. Choose a highlighted destination.');
    }
  };

  const executeRegular = (fromR: number, fromC: number, toR: number, toC: number) => {
    const piece = board[fromR][fromC]!;
    const newBoard = board.map(row => [...row]);
    newBoard[fromR][fromC] = null;

    const isKing = piece.isKing || (piece.color === 'red' && toR === 0) || (piece.color === 'black' && toR === 7);
    newBoard[toR][toC] = { ...piece, isKing };

    setBoard(newBoard);
    setSelectedPos(null);

    const nextTurn = piece.color === 'red' ? 'black' : 'red';
    setTurn(nextTurn);
    setStatusMessage(`${nextTurn === 'red' ? 'Red' : 'Black'} to move.`);

    if (vsBot && nextTurn === 'black') {
      setTimeout(() => makeBotMove(newBoard), 500);
    }
  };

  const executeJump = (fromR: number, fromC: number, toR: number, toC: number, jumpR: number, jumpC: number) => {
    const piece = board[fromR][fromC]!;
    const newBoard = board.map(row => [...row]);
    newBoard[fromR][fromC] = null;
    newBoard[jumpR][jumpC] = null; // Captured!

    const isKing = piece.isKing || (piece.color === 'red' && toR === 0) || (piece.color === 'black' && toR === 7);
    newBoard[toR][toC] = { ...piece, isKing };

    if (piece.color === 'red') {
      setBlackCaptured(prev => {
        const updated = prev + 1;
        if (updated >= 12) {
          confetti({ particleCount: 90, spread: 70 });
          setStatusMessage('Game Over! Red Wins all checkers!');
        }
        return updated;
      });
    } else {
      setRedCaptured(prev => {
        const updated = prev + 1;
        if (updated >= 12) {
          setStatusMessage('Game Over! Black Wins all checkers!');
        }
        return updated;
      });
    }

    setBoard(newBoard);
    setSelectedPos(null);

    const nextTurn = piece.color === 'red' ? 'black' : 'red';
    setTurn(nextTurn);
    setStatusMessage(`${nextTurn === 'red' ? 'Red' : 'Black'} to move.`);

    if (vsBot && nextTurn === 'black') {
      setTimeout(() => makeBotMove(newBoard), 500);
    }
  };

  const makeBotMove = (currentBoard: BoardState) => {
    const jumpMoves: { from: [number, number]; to: [number, number]; jumped: [number, number] }[] = [];
    const regMoves: { from: [number, number]; to: [number, number] }[] = [];

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        if (currentBoard[r][c]?.color === 'black') {
          const { regular, jumps } = getMovesForPiece(r, c, currentBoard);
          jumps.forEach(j => jumpMoves.push({ from: [r, c], to: j.to, jumped: j.jumped }));
          regular.forEach(m => regMoves.push({ from: [r, c], to: m }));
        }
      }
    }

    // Always prioritize jumps if available
    if (jumpMoves.length > 0) {
      const j = jumpMoves[Math.floor(Math.random() * jumpMoves.length)];
      executeJump(j.from[0], j.from[1], j.to[0], j.to[1], j.jumped[0], j.jumped[1]);
    } else if (regMoves.length > 0) {
      const m = regMoves[Math.floor(Math.random() * regMoves.length)];
      executeRegular(m.from[0], m.from[1], m.to[0], m.to[1]);
    } else {
      setStatusMessage('Black has no valid moves! Red wins!');
      confetti({ particleCount: 70, spread: 60 });
    }
  };

  const handleReset = () => {
    setBoard(createInitialBoard());
    setTurn('red');
    setSelectedPos(null);
    setRedCaptured(0);
    setBlackCaptured(0);
    setStatusMessage('Game reset. Red to move.');
  };

  const currentPieceMoves = selectedPos ? getMovesForPiece(selectedPos[0], selectedPos[1], board) : { regular: [], jumps: [] };

  return (
    <div className="space-y-4">
      {/* Header controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setVsBot(!vsBot)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition ${
              vsBot ? 'bg-rose-600 text-white shadow-md' : 'bg-white/10 text-white/70'
            }`}
          >
            {vsBot ? <Bot className="w-3.5 h-3.5" /> : <User className="w-3.5 h-3.5" />}
            <span>{vsBot ? 'vs AI Bot' : 'Pass & Play'}</span>
          </button>
        </div>

        <button
          onClick={handleReset}
          className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition"
          title="Reset Checkers"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Score bar */}
      <div className="flex items-center justify-around px-3 py-2 bg-black/20 rounded-xl text-xs font-semibold">
        <div className="flex items-center gap-2 text-rose-400">
          <div className="w-4 h-4 rounded-full bg-rose-500 shadow" />
          <span>Red Captures: {blackCaptured}</span>
        </div>
        <div className="flex items-center gap-2 text-slate-300">
          <div className="w-4 h-4 rounded-full bg-slate-900 border border-white/40 shadow" />
          <span>Black Captures: {redCaptured}</span>
        </div>
      </div>

      {/* Board */}
      <div className="w-full max-w-[340px] mx-auto aspect-square rounded-2xl overflow-hidden border-2 border-white/20 shadow-2xl grid grid-cols-8 grid-rows-8 bg-neutral-900">
        {board.map((row, r) =>
          row.map((cell, c) => {
            const isDark = (r + c) % 2 === 1;
            const isSelected = selectedPos?.[0] === r && selectedPos?.[1] === c;
            const isJumpTarget = currentPieceMoves.jumps.some(j => j.to[0] === r && j.to[1] === c);
            const isRegularTarget = currentPieceMoves.regular.some(([rr, rc]) => rr === r && rc === c);

            return (
              <button
                key={`${r}-${c}`}
                onClick={() => handleCellClick(r, c)}
                className={`w-full h-full flex items-center justify-center relative transition-colors ${
                  isSelected
                    ? 'bg-amber-400/80'
                    : isJumpTarget
                    ? 'bg-rose-500/70 animate-pulse'
                    : isRegularTarget
                    ? 'bg-emerald-500/60'
                    : isDark
                    ? 'bg-[#2E282A]'
                    : 'bg-[#D6C7B2]'
                }`}
              >
                {cell && (
                  <div
                    className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 border-2 ${
                      cell.color === 'red'
                        ? 'bg-gradient-to-tr from-rose-700 to-rose-500 border-rose-300'
                        : 'bg-gradient-to-tr from-slate-950 to-slate-800 border-slate-600'
                    }`}
                  >
                    {cell.isKing && (
                      <Crown className="w-4 h-4 text-amber-300 animate-bounce" />
                    )}
                  </div>
                )}
                {(isRegularTarget || isJumpTarget) && !cell && (
                  <div className="w-2.5 h-2.5 rounded-full bg-white/60" />
                )}
              </button>
            );
          })
        )}
      </div>

      <div className="text-center">
        <p className="text-xs font-medium text-gray-300">{statusMessage}</p>
      </div>
    </div>
  );
}
