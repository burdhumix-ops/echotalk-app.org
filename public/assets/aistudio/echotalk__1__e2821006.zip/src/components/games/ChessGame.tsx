import React, { useState } from 'react';
import { RotateCcw, Bot, User, Trophy, Crown, Sparkles, Volume2, ShieldAlert } from 'lucide-react';
import confetti from 'canvas-confetti';
import { ThemeConfig } from '../../types';
import { audioFX } from '../../utils/audioFX';

interface ChessGameProps {
  theme: ThemeConfig;
  onClose?: () => void;
  isFullScreen?: boolean;
  challengeMatch?: {
    playerWhite: string;
    playerBlack: string;
    gameTitle?: string;
  };
  initialDifficulty?: 'easy' | 'medium' | 'hard';
}

type PieceColor = 'w' | 'b';
type PieceType = 'p' | 'r' | 'n' | 'b' | 'q' | 'k';
type DifficultyLevel = 'easy' | 'medium' | 'hard';

interface Piece {
  color: PieceColor;
  type: PieceType;
  id?: string;
}

type BoardState = (Piece | null)[][];

const PIECE_SYMBOLS: Record<PieceColor, Record<PieceType, string>> = {
  w: { k: '♔', q: '♕', r: '♖', b: '♗', n: '♘', p: '♙' },
  b: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' }
};

const INITIAL_BOARD: BoardState = [
  [
    { color: 'b', type: 'r', id: 'br1' }, { color: 'b', type: 'n', id: 'bn1' }, { color: 'b', type: 'b', id: 'bb1' }, { color: 'b', type: 'q', id: 'bq' },
    { color: 'b', type: 'k', id: 'bk' }, { color: 'b', type: 'b', id: 'bb2' }, { color: 'b', type: 'n', id: 'bn2' }, { color: 'b', type: 'r', id: 'br2' }
  ],
  Array(8).fill(null).map((_, i) => ({ color: 'b', type: 'p' as PieceType, id: `bp${i}` })),
  Array(8).fill(null),
  Array(8).fill(null),
  Array(8).fill(null),
  Array(8).fill(null),
  Array(8).fill(null).map((_, i) => ({ color: 'w', type: 'p' as PieceType, id: `wp${i}` })),
  [
    { color: 'w', type: 'r', id: 'wr1' }, { color: 'w', type: 'n', id: 'wn1' }, { color: 'w', type: 'b', id: 'wb1' }, { color: 'w', type: 'q', id: 'wq' },
    { color: 'w', type: 'k', id: 'wk' }, { color: 'w', type: 'b', id: 'wb2' }, { color: 'w', type: 'n', id: 'wn2' }, { color: 'w', type: 'r', id: 'wr2' }
  ]
];

// Positional bonuses for center control
const CENTER_BONUS: number[][] = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 1, 1, 0, 0, 0],
  [0, 0, 2, 4, 4, 2, 0, 0],
  [0, 1, 4, 6, 6, 4, 1, 0],
  [0, 1, 4, 6, 6, 4, 1, 0],
  [0, 0, 2, 4, 4, 2, 0, 0],
  [0, 0, 0, 1, 1, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0]
];

export default function ChessGame({
  theme,
  onClose,
  isFullScreen = false,
  challengeMatch,
  initialDifficulty = 'medium'
}: ChessGameProps) {
  const [board, setBoard] = useState<BoardState>(INITIAL_BOARD);
  const [selectedSquare, setSelectedSquare] = useState<[number, number] | null>(null);
  const [turn, setTurn] = useState<PieceColor>('w');
  const [vsBot, setVsBot] = useState<boolean>(!challengeMatch);
  const [difficulty, setDifficulty] = useState<DifficultyLevel>(initialDifficulty);
  const [whiteCaptures, setWhiteCaptures] = useState<string[]>([]);
  const [blackCaptures, setBlackCaptures] = useState<string[]>([]);
  const [moveCount, setMoveCount] = useState<number>(0);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [inCheck, setInCheck] = useState<PieceColor | null>(null);
  const [lastMoveSquares, setLastMoveSquares] = useState<[[number, number], [number, number]] | null>(null);

  // Castling tracking flags: whether king or rooks moved
  const [hasMoved, setHasMoved] = useState<{
    wk: boolean;
    bk: boolean;
    wra: boolean; // a1 rook
    wrh: boolean; // h1 rook
    bra: boolean; // a8 rook
    brh: boolean; // h8 rook
  }>({
    wk: false,
    bk: false,
    wra: false,
    wrh: false,
    bra: false,
    brh: false
  });

  // En passant target square (square skipped by double pawn push)
  const [enPassantTarget, setEnPassantTarget] = useState<[number, number] | null>(null);

  // Pawn promotion modal state
  const [promotionPending, setPromotionPending] = useState<{
    from: [number, number];
    to: [number, number];
    color: PieceColor;
  } | null>(null);

  const [statusMessage, setStatusMessage] = useState<string>(
    challengeMatch
      ? `${challengeMatch.playerWhite} (White) to move.`
      : 'White to move. Tap a piece to play.'
  );

  const isInside = (nr: number, nc: number) => nr >= 0 && nr < 8 && nc >= 0 && nc < 8;

  // Find King position
  const findKing = (color: PieceColor, currentBoard: BoardState): [number, number] | null => {
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const p = currentBoard[r][c];
        if (p && p.color === color && p.type === 'k') {
          return [r, c];
        }
      }
    }
    return null;
  };

  // Check if square is attacked by opponent
  const isSquareAttacked = (r: number, c: number, attackerColor: PieceColor, currentBoard: BoardState): boolean => {
    for (let pr = 0; pr < 8; pr++) {
      for (let pc = 0; pc < 8; pc++) {
        const piece = currentBoard[pr][pc];
        if (piece && piece.color === attackerColor) {
          const rawMoves = getRawMoves(pr, pc, currentBoard);
          if (rawMoves.some(([tr, tc]) => tr === r && tc === c)) {
            return true;
          }
        }
      }
    }
    return false;
  };

  // Get raw piece moves without castling/en-passant recursion
  const getRawMoves = (r: number, c: number, currentBoard: BoardState): [number, number][] => {
    const piece = currentBoard[r][c];
    if (!piece) return [];
    const moves: [number, number][] = [];
    const color = piece.color;
    const enemyColor = color === 'w' ? 'b' : 'w';

    if (piece.type === 'p') {
      const dir = color === 'w' ? -1 : 1;
      const startRow = color === 'w' ? 6 : 1;
      if (isInside(r + dir, c) && !currentBoard[r + dir][c]) {
        moves.push([r + dir, c]);
        if (r === startRow && !currentBoard[r + 2 * dir][c]) {
          moves.push([r + 2 * dir, c]);
        }
      }
      [-1, 1].forEach((dc) => {
        const nr = r + dir;
        const nc = c + dc;
        if (isInside(nr, nc)) {
          if (currentBoard[nr][nc]?.color === enemyColor) {
            moves.push([nr, nc]);
          }
          // En Passant
          if (enPassantTarget && enPassantTarget[0] === nr && enPassantTarget[1] === nc) {
            moves.push([nr, nc]);
          }
        }
      });
    } else if (piece.type === 'n') {
      const offsets = [
        [-2, -1], [-2, 1], [-1, -2], [-1, 2],
        [1, -2], [1, 2], [2, -1], [2, 1]
      ];
      offsets.forEach(([dr, dc]) => {
        const nr = r + dr;
        const nc = c + dc;
        if (isInside(nr, nc) && currentBoard[nr][nc]?.color !== color) {
          moves.push([nr, nc]);
        }
      });
    } else if (piece.type === 'k') {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nr = r + dr;
          const nc = c + dc;
          if (isInside(nr, nc) && currentBoard[nr][nc]?.color !== color) {
            moves.push([nr, nc]);
          }
        }
      }
    } else {
      const directions: [number, number][] = [];
      if (piece.type === 'r' || piece.type === 'q') directions.push([1, 0], [-1, 0], [0, 1], [0, -1]);
      if (piece.type === 'b' || piece.type === 'q') directions.push([1, 1], [1, -1], [-1, 1], [-1, -1]);

      directions.forEach(([dr, dc]) => {
        let step = 1;
        while (true) {
          const nr = r + dr * step;
          const nc = c + dc * step;
          if (!isInside(nr, nc)) break;
          const target = currentBoard[nr][nc];
          if (!target) {
            moves.push([nr, nc]);
          } else {
            if (target.color === enemyColor) moves.push([nr, nc]);
            break;
          }
          step++;
        }
      });
    }

    return moves;
  };

  // Full legal move generator with Castling validation
  const getValidMoves = (r: number, c: number, currentBoard: BoardState): [number, number][] => {
    const piece = currentBoard[r][c];
    if (!piece) return [];
    const rawMoves = getRawMoves(r, c, currentBoard);

    // Castling checks for King
    if (piece.type === 'k') {
      const enemy = piece.color === 'w' ? 'b' : 'w';
      if (piece.color === 'w' && !hasMoved.wk && r === 7 && c === 4) {
        // Kingside castling O-O (e1 -> g1)
        if (!hasMoved.wrh && !currentBoard[7][5] && !currentBoard[7][6] && currentBoard[7][7]?.type === 'r') {
          if (!isSquareAttacked(7, 4, enemy, currentBoard) && !isSquareAttacked(7, 5, enemy, currentBoard) && !isSquareAttacked(7, 6, enemy, currentBoard)) {
            rawMoves.push([7, 6]);
          }
        }
        // Queenside castling O-O-O (e1 -> c1)
        if (!hasMoved.wra && !currentBoard[7][3] && !currentBoard[7][2] && !currentBoard[7][1] && currentBoard[7][0]?.type === 'r') {
          if (!isSquareAttacked(7, 4, enemy, currentBoard) && !isSquareAttacked(7, 3, enemy, currentBoard) && !isSquareAttacked(7, 2, enemy, currentBoard)) {
            rawMoves.push([7, 2]);
          }
        }
      } else if (piece.color === 'b' && !hasMoved.bk && r === 0 && c === 4) {
        // Kingside castling O-O (e8 -> g8)
        if (!hasMoved.brh && !currentBoard[0][5] && !currentBoard[0][6] && currentBoard[0][7]?.type === 'r') {
          if (!isSquareAttacked(0, 4, enemy, currentBoard) && !isSquareAttacked(0, 5, enemy, currentBoard) && !isSquareAttacked(0, 6, enemy, currentBoard)) {
            rawMoves.push([0, 6]);
          }
        }
        // Queenside castling O-O-O (e8 -> c8)
        if (!hasMoved.bra && !currentBoard[0][3] && !currentBoard[0][2] && !currentBoard[0][1] && currentBoard[0][0]?.type === 'r') {
          if (!isSquareAttacked(0, 4, enemy, currentBoard) && !isSquareAttacked(0, 3, enemy, currentBoard) && !isSquareAttacked(0, 2, enemy, currentBoard)) {
            rawMoves.push([0, 2]);
          }
        }
      }
    }

    return rawMoves;
  };

  const handleSquareClick = (r: number, c: number) => {
    if (isGameOver || promotionPending) return;
    const clickedPiece = board[r][c];

    if (!selectedSquare) {
      if (clickedPiece && clickedPiece.color === turn) {
        setSelectedSquare([r, c]);
        setStatusMessage(`Selected ${clickedPiece.type.toUpperCase()} at [${r}, ${c}].`);
      }
      return;
    }

    const [selR, selC] = selectedSquare;
    const selectedPiece = board[selR][selC];
    if (!selectedPiece) {
      setSelectedSquare(null);
      return;
    }

    if (clickedPiece && clickedPiece.color === turn) {
      if (selR === r && selC === c) {
        setSelectedSquare(null);
        setStatusMessage(`${turn === 'w' ? 'White' : 'Black'} to move.`);
      } else {
        setSelectedSquare([r, c]);
        setStatusMessage(`Selected ${clickedPiece.type.toUpperCase()} at [${r}, ${c}].`);
      }
      return;
    }

    const validMoves = getValidMoves(selR, selC, board);
    const isMoveValid = validMoves.some(([vr, vc]) => vr === r && vc === c);

    if (isMoveValid) {
      // Check for Pawn Promotion: pawn reaching rank 0 or 7
      if (selectedPiece.type === 'p' && (r === 0 || r === 7)) {
        setPromotionPending({ from: [selR, selC], to: [r, c], color: selectedPiece.color });
        return;
      }
      executeMove(selR, selC, r, c, board);
    } else {
      setStatusMessage('Invalid square. Choose a highlighted destination.');
    }
  };

  const executeMove = (
    fromR: number,
    fromC: number,
    toR: number,
    toC: number,
    currentBoard: BoardState,
    promotedToPiece?: PieceType
  ) => {
    const movingPiece = currentBoard[fromR][fromC]!;
    let capturedPiece = currentBoard[toR][toC];
    let isEnPassant = false;
    let isCastling = false;

    const newBoard = currentBoard.map(row => [...row]);
    newBoard[fromR][fromC] = null;

    // Check for En Passant capture
    if (movingPiece.type === 'p' && enPassantTarget && toR === enPassantTarget[0] && toC === enPassantTarget[1]) {
      const epCapturedRow = movingPiece.color === 'w' ? toR + 1 : toR - 1;
      capturedPiece = newBoard[epCapturedRow][toC];
      newBoard[epCapturedRow][toC] = null;
      isEnPassant = true;
    }

    // Check for Castling move execution
    if (movingPiece.type === 'k' && Math.abs(toC - fromC) === 2) {
      isCastling = true;
      if (toC === 6) {
        // Kingside castling: move rook from col 7 to col 5
        const rook = newBoard[fromR][7];
        newBoard[fromR][7] = null;
        newBoard[fromR][5] = rook;
      } else if (toC === 2) {
        // Queenside castling: move rook from col 0 to col 3
        const rook = newBoard[fromR][0];
        newBoard[fromR][0] = null;
        newBoard[fromR][3] = rook;
      }
    }

    // Place moved or promoted piece
    if (promotedToPiece) {
      newBoard[toR][toC] = { color: movingPiece.color, type: promotedToPiece };
    } else {
      newBoard[toR][toC] = movingPiece;
    }

    // Update hasMoved flags for castling
    if (movingPiece.color === 'w') {
      if (movingPiece.type === 'k') setHasMoved(prev => ({ ...prev, wk: true }));
      if (fromR === 7 && fromC === 0) setHasMoved(prev => ({ ...prev, wra: true }));
      if (fromR === 7 && fromC === 7) setHasMoved(prev => ({ ...prev, wrh: true }));
    } else {
      if (movingPiece.type === 'k') setHasMoved(prev => ({ ...prev, bk: true }));
      if (fromR === 0 && fromC === 0) setHasMoved(prev => ({ ...prev, bra: true }));
      if (fromR === 0 && fromC === 7) setHasMoved(prev => ({ ...prev, brh: true }));
    }

    // Update En Passant square for two-step pawn move
    if (movingPiece.type === 'p' && Math.abs(toR - fromR) === 2) {
      setEnPassantTarget([(fromR + toR) / 2, fromC]);
    } else {
      setEnPassantTarget(null);
    }

    // Handle captures audio and visual tally
    if (capturedPiece) {
      audioFX.playCaptureSound();
      const sym = PIECE_SYMBOLS[capturedPiece.color][capturedPiece.type];
      if (capturedPiece.color === 'b') {
        setWhiteCaptures(prev => [...prev, sym]);
      } else {
        setBlackCaptures(prev => [...prev, sym]);
      }

      if (capturedPiece.type === 'k') {
        audioFX.playCheckmateSound();
        confetti({ particleCount: 120, spread: 80 });
        const winnerName = movingPiece.color === 'w'
          ? (challengeMatch ? challengeMatch.playerWhite : 'White')
          : (challengeMatch ? challengeMatch.playerBlack : 'Black');
        setStatusMessage(`Checkmate! ${winnerName} WINS THE MATCH!`);
        setBoard(newBoard);
        setSelectedSquare(null);
        setIsGameOver(true);
        return;
      }
    } else {
      audioFX.playMoveSound();
    }

    setLastMoveSquares([[fromR, fromC], [toR, toC]]);
    setBoard(newBoard);
    setSelectedSquare(null);
    setMoveCount(prev => prev + 1);

    const nextTurn = movingPiece.color === 'w' ? 'b' : 'w';
    setTurn(nextTurn);

    // Check detection for next player's King
    const nextKingPos = findKing(nextTurn, newBoard);
    if (nextKingPos && isSquareAttacked(nextKingPos[0], nextKingPos[1], movingPiece.color, newBoard)) {
      setInCheck(nextTurn);
      audioFX.playCheckSound();
      setStatusMessage(`⚠️ Check! ${nextTurn === 'w' ? 'White' : 'Black'} King is under attack!`);
    } else {
      setInCheck(null);
      const nextPlayerName = nextTurn === 'w'
        ? (challengeMatch ? challengeMatch.playerWhite : 'White')
        : (challengeMatch ? challengeMatch.playerBlack : 'Black');
      setStatusMessage(`${nextPlayerName} to move.`);
    }

    // Trigger AI Bot move if playing against AI
    if (vsBot && !challengeMatch && nextTurn === 'b') {
      setTimeout(() => {
        makeSmartBotMove(newBoard);
      }, 500);
    }
  };

  // Smart Offline AI Bot with 3 Difficulty Levels
  const makeSmartBotMove = (currentBoard: BoardState) => {
    const allMoves: { from: [number, number]; to: [number, number]; score: number }[] = [];

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        if (currentBoard[r][c]?.color === 'b') {
          const moves = getValidMoves(r, c, currentBoard);
          moves.forEach(([tr, tc]) => {
            const target = currentBoard[tr][tc];
            let score = 0;

            // Target piece value
            if (target) {
              if (target.type === 'k') score += 10000;
              else if (target.type === 'q') score += 900;
              else if (target.type === 'r') score += 500;
              else if (target.type === 'b' || target.type === 'n') score += 320;
              else score += 100;
            }

            // Medium & Hard: Add center control and development heuristics
            if (difficulty === 'medium' || difficulty === 'hard') {
              score += CENTER_BONUS[tr][tc] * 12;
              if (currentBoard[r][c]?.type === 'p') score += (tr - r) * 15;
            }

            // Grandmaster Level: tactical safety, castling preference
            if (difficulty === 'hard') {
              if (Math.abs(tc - c) === 2 && currentBoard[r][c]?.type === 'k') score += 80; // Castle bonus
              if (target?.type === 'p' && (currentBoard[r][c]?.type === 'q' || currentBoard[r][c]?.type === 'r')) {
                score -= 40;
              }
              if (currentBoard[r][c]?.type === 'k' && r > 2) score -= 150;
            }

            if (difficulty === 'easy') {
              score += Math.random() * 60;
            }

            allMoves.push({ from: [r, c], to: [tr, tc], score });
          });
        }
      }
    }

    if (allMoves.length === 0) {
      setStatusMessage('Stalemate! Game is a draw.');
      setIsGameOver(true);
      return;
    }

    allMoves.sort((a, b) => b.score - a.score);
    const topScore = allMoves[0].score;
    const candidates = allMoves.filter(m => m.score === topScore);
    const chosen = candidates[Math.floor(Math.random() * candidates.length)];

    executeMove(chosen.from[0], chosen.from[1], chosen.to[0], chosen.to[1], currentBoard, 'q');
  };

  const handleReset = () => {
    setBoard(INITIAL_BOARD);
    setSelectedSquare(null);
    setTurn('w');
    setWhiteCaptures([]);
    setBlackCaptures([]);
    setMoveCount(0);
    setIsGameOver(false);
    setInCheck(null);
    setLastMoveSquares(null);
    setEnPassantTarget(null);
    setHasMoved({ wk: false, bk: false, wra: false, wrh: false, bra: false, brh: false });
    setStatusMessage(
      challengeMatch
        ? `${challengeMatch.playerWhite} to move.`
        : 'Game reset. White to move.'
    );
  };

  const validTargetSquares = selectedSquare ? getValidMoves(selectedSquare[0], selectedSquare[1], board) : [];

  return (
    <div className={`space-y-4 max-w-lg mx-auto ${isFullScreen ? 'p-2' : ''}`}>
      {/* 1v1 Challenge Header if in direct challenge match */}
      {challengeMatch && (
        <div className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-500/40 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-amber-400" />
              1v1 DM Challenge Match
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono">
            <span className="text-white bg-slate-800 px-2 py-0.5 rounded border border-white/20">
              White: {challengeMatch.playerWhite}
            </span>
            <span className="text-gray-400">vs</span>
            <span className="text-slate-200 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
              Black: {challengeMatch.playerBlack}
            </span>
          </div>
        </div>
      )}

      {/* Game Mode & AI Difficulty Controls (Always available!) */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setVsBot(!vsBot)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition ${
              vsBot ? 'bg-indigo-600 text-white shadow-md' : 'bg-white/10 text-white/70'
            }`}
          >
            {vsBot ? <Bot className="w-3.5 h-3.5" /> : <User className="w-3.5 h-3.5" />}
            <span>{vsBot ? 'vs AI Engine' : 'Pass & Play'}</span>
          </button>

          {/* AI Difficulty Selector */}
          <div className="flex items-center gap-1 p-0.5 bg-black/40 rounded-xl border border-white/10 text-[10px]">
            {(['easy', 'medium', 'hard'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setDifficulty(lvl)}
                className={`px-2 py-1 rounded-lg capitalize font-medium transition ${
                  difficulty === lvl
                    ? 'bg-amber-400 text-slate-950 font-bold shadow'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {lvl === 'hard' ? 'Grandmaster' : lvl}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-gray-400 font-mono">Move {moveCount}</span>
          <button
            onClick={handleReset}
            className="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition"
            title="Reset Game"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Check indicator alert */}
      {inCheck && (
        <div className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs flex items-center justify-center gap-2 font-bold animate-pulse">
          <ShieldAlert className="w-4 h-4" />
          <span>CHECK! {inCheck === 'w' ? 'White' : 'Black'} King is in danger!</span>
        </div>
      )}

      {/* Captured Trays */}
      <div className="flex items-center justify-between text-xs px-3 py-1.5 bg-black/30 rounded-2xl border border-white/5">
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-gray-400">Captured (Black):</span>
          <span className="text-sm tracking-widest text-slate-900 drop-shadow-[0_1px_1px_rgba(255,255,255,0.4)]">
            {whiteCaptures.join('') || '—'}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-gray-400">Captured (White):</span>
          <span className="text-sm tracking-widest text-white">
            {blackCaptures.join('') || '—'}
          </span>
        </div>
      </div>

      {/* Chessboard with smooth piece transitions and move highlighting */}
      <div className="w-full max-w-[340px] sm:max-w-[360px] mx-auto aspect-square rounded-3xl overflow-hidden border-2 border-white/20 shadow-2xl grid grid-cols-8 grid-rows-8 bg-slate-900 relative">
        {board.map((row, r) =>
          row.map((cell, c) => {
            const isLight = (r + c) % 2 === 0;
            const isSelected = selectedSquare?.[0] === r && selectedSquare?.[1] === c;
            const isValidTarget = validTargetSquares.some(([vr, vc]) => vr === r && vc === c);
            const isLastMove = lastMoveSquares && (
              (lastMoveSquares[0][0] === r && lastMoveSquares[0][1] === c) ||
              (lastMoveSquares[1][0] === r && lastMoveSquares[1][1] === c)
            );
            const isKingInCheckSquare = cell?.type === 'k' && cell?.color === inCheck;

            return (
              <button
                key={`${r}-${c}`}
                onClick={() => handleSquareClick(r, c)}
                className={`w-full h-full flex items-center justify-center relative transition-all duration-150 ${
                  isKingInCheckSquare
                    ? 'bg-rose-600/90 animate-pulse'
                    : isSelected
                    ? 'bg-amber-400/80 shadow-inner'
                    : isValidTarget
                    ? isLight
                      ? 'bg-emerald-300/80'
                      : 'bg-emerald-600/80'
                    : isLastMove
                    ? isLight
                      ? 'bg-yellow-200/60'
                      : 'bg-yellow-600/50'
                    : isLight
                    ? 'bg-[#E3D7B5]'
                    : 'bg-[#B5884B]'
                }`}
              >
                {cell && (
                  <span
                    className={`text-2xl sm:text-3xl leading-none select-none transition-transform duration-200 active:scale-95 hover:scale-105 ${
                      cell.color === 'w'
                        ? 'text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]'
                        : 'text-slate-950 font-bold'
                    }`}
                  >
                    {PIECE_SYMBOLS[cell.color][cell.type]}
                  </span>
                )}

                {/* Target Dot for empty valid square */}
                {isValidTarget && !cell && (
                  <div className="w-3 h-3 rounded-full bg-emerald-950/40 animate-ping" />
                )}
              </button>
            );
          })
        )}
      </div>

      {/* Pawn Promotion Modal */}
      {promotionPending && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="p-4 rounded-3xl bg-slate-900 border border-white/20 text-center space-y-3 max-w-xs w-full shadow-2xl">
            <span className="text-xs font-bold text-white block">Promote Pawn:</span>
            <div className="grid grid-cols-4 gap-2">
              {(['q', 'r', 'b', 'n'] as const).map(type => (
                <button
                  key={type}
                  onClick={() => {
                    executeMove(
                      promotionPending.from[0],
                      promotionPending.from[1],
                      promotionPending.to[0],
                      promotionPending.to[1],
                      board,
                      type
                    );
                    setPromotionPending(null);
                  }}
                  className="p-3 rounded-2xl bg-white/10 hover:bg-white/20 text-2xl flex items-center justify-center transition active:scale-95"
                >
                  <span className={promotionPending.color === 'w' ? 'text-white' : 'text-slate-950 font-bold'}>
                    {PIECE_SYMBOLS[promotionPending.color][type]}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Status Bar */}
      <div className="text-center pt-1">
        <p className={`text-xs font-semibold ${isGameOver ? 'text-amber-400 font-bold text-sm' : 'text-gray-300'}`}>
          {statusMessage}
        </p>
      </div>
    </div>
  );
}
