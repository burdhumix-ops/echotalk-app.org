import React, { useState } from 'react';
import { RotateCcw, Dices, Trophy, Sparkles, Star, Shield, Play } from 'lucide-react';
import confetti from 'canvas-confetti';
import { ThemeConfig } from '../../types';
import { audioFX } from '../../utils/audioFX';

interface LudoGameProps {
  theme: ThemeConfig;
  onClose?: () => void;
  isFullScreen?: boolean;
  challengeMatch?: {
    playerRed: string;
    playerGreen: string;
    gameTitle?: string;
  };
}

type LudoColor = 'red' | 'green' | 'yellow' | 'blue';

interface PlayerConfig {
  name: string;
  bg: string;
  text: string;
  border: string;
  startTrackIdx: number; // Index on 0..51 loop
}

const PLAYERS: Record<LudoColor, PlayerConfig> = {
  red: { name: 'Red Team', bg: 'bg-rose-500', text: 'text-rose-400', border: 'border-rose-500', startTrackIdx: 0 },
  green: { name: 'Green Team', bg: 'bg-emerald-500', text: 'text-emerald-400', border: 'border-emerald-500', startTrackIdx: 13 },
  yellow: { name: 'Yellow Team', bg: 'bg-amber-400', text: 'text-amber-400', border: 'border-amber-400', startTrackIdx: 26 },
  blue: { name: 'Blue Team', bg: 'bg-sky-500', text: 'text-sky-400', border: 'border-sky-500', startTrackIdx: 39 }
};

// Safe squares on 0..51 loop
const SAFE_TILES = new Set([0, 8, 13, 21, 26, 34, 39, 47]);

// 15x15 board coordinate map for 52 track tiles
const TRACK_COORDS: [number, number][] = [
  // Red start & column up (0..4)
  [6, 1], [6, 2], [6, 3], [6, 4], [6, 5],
  // Turn up into green approach (5..10)
  [5, 6], [4, 6], [3, 6], [2, 6], [1, 6], [0, 6],
  // Top corner to Green start (11..12)
  [0, 7], [0, 8],
  // Down right green track (13..17)
  [1, 8], [2, 8], [3, 8], [4, 8], [5, 8],
  // Turn right toward yellow (18..23)
  [6, 9], [6, 10], [6, 11], [6, 12], [6, 13], [6, 14],
  // Right edge down (24..25)
  [7, 14], [8, 14],
  // Yellow start & moving left (26..30)
  [8, 13], [8, 12], [8, 11], [8, 10], [8, 9],
  // Turn down toward blue approach (31..36)
  [9, 8], [10, 8], [11, 8], [12, 8], [13, 8], [14, 8],
  // Bottom edge (37..38)
  [14, 7], [14, 6],
  // Blue start & moving up (39..43)
  [13, 6], [12, 6], [11, 6], [10, 6], [9, 6],
  // Turn left back toward red approach (44..49)
  [8, 5], [8, 4], [8, 3], [8, 2], [8, 1], [8, 0],
  // Left edge (50..51)
  [7, 0], [6, 0]
];

// Colored home corridors leading to central goal (5 tiles each)
const HOME_CORRIDORS: Record<LudoColor, [number, number][]> = {
  red: [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5]],
  green: [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]],
  yellow: [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9]],
  blue: [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7]]
};

export default function LudoGame({
  theme,
  onClose,
  isFullScreen = false,
  challengeMatch
}: LudoGameProps) {
  const is1v1 = Boolean(challengeMatch);
  const activePlayers: LudoColor[] = is1v1 ? ['red', 'green'] : ['red', 'green', 'yellow', 'blue'];

  // Token positions: -1 = Base yard, 0..50 = On track (relative steps from start), 51..55 = Home corridor, 56 = Home Goal
  const [tokens, setTokens] = useState<Record<LudoColor, number[]>>({
    red: [-1, -1, -1, -1],
    green: [-1, -1, -1, -1],
    yellow: [-1, -1, -1, -1],
    blue: [-1, -1, -1, -1]
  });

  const [currentTurn, setCurrentTurn] = useState<LudoColor>('red');
  const [diceRoll, setDiceRoll] = useState<number>(6);
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [rolledThisTurn, setRolledThisTurn] = useState<boolean>(false);
  const [winner, setWinner] = useState<LudoColor | null>(null);

  const getPlayerLabel = (color: LudoColor) => {
    if (challengeMatch) {
      if (color === 'red') return challengeMatch.playerRed;
      if (color === 'green') return challengeMatch.playerGreen;
    }
    return PLAYERS[color].name;
  };

  const [statusMessage, setStatusMessage] = useState<string>(
    challengeMatch
      ? `${challengeMatch.playerRed} (Red), roll the dice!`
      : 'Red Team’s turn. Roll the dice to begin!'
  );

  // Convert player relative steps (0..50) into global track index (0..51)
  const getGlobalTrackIndex = (color: LudoColor, relativeSteps: number): number => {
    return (PLAYERS[color].startTrackIdx + relativeSteps) % 52;
  };

  const rollDice = () => {
    if (isRolling || rolledThisTurn || winner) return;
    setIsRolling(true);
    audioFX.playDiceSound();

    let counter = 0;
    const interval = setInterval(() => {
      setDiceRoll(Math.floor(Math.random() * 6) + 1);
      counter++;
      if (counter >= 8) {
        clearInterval(interval);
        const finalRoll = Math.floor(Math.random() * 6) + 1;
        setDiceRoll(finalRoll);
        setIsRolling(false);
        setRolledThisTurn(true);

        // Check if any token can move
        const playerTokens = tokens[currentTurn];
        const canMove = playerTokens.some(pos => {
          if (pos === -1) return finalRoll === 6; // Needs a 6 to enter
          if (pos < 56) return pos + finalRoll <= 56;
          return false;
        });

        if (!canMove) {
          setStatusMessage(`Rolled a ${finalRoll}. No valid moves! Passing to next player...`);
          setTimeout(() => advanceTurn(), 1200);
        } else {
          setStatusMessage(`Rolled a ${finalRoll}! Tap one of your active or base tokens to move.`);
        }
      }
    }, 60);
  };

  const advanceTurn = () => {
    const nextIdx = (activePlayers.indexOf(currentTurn) + 1) % activePlayers.length;
    const nextColor = activePlayers[nextIdx];
    setCurrentTurn(nextColor);
    setRolledThisTurn(false);
    setStatusMessage(`${getPlayerLabel(nextColor)}'s turn. Roll the dice!`);
  };

  const handleTokenClick = (color: LudoColor, tokenIdx: number) => {
    if (color !== currentTurn || !rolledThisTurn || winner) return;

    const currentPos = tokens[color][tokenIdx];

    // Releasing token from base yard
    if (currentPos === -1) {
      if (diceRoll === 6) {
        moveToken(color, tokenIdx, 0); // Enters track at relative step 0
      } else {
        setStatusMessage('You need a 6 to release a token from the base yard!');
      }
      return;
    }

    // Moving token on track or corridor
    const nextPos = currentPos + diceRoll;
    if (nextPos <= 56) {
      moveToken(color, tokenIdx, nextPos);
    } else {
      setStatusMessage('Roll exceeds Home Goal! Choose another token.');
    }
  };

  const moveToken = (color: LudoColor, tokenIdx: number, newPos: number) => {
    audioFX.playMoveSound();

    let extraTurn = diceRoll === 6;
    let didCapture = false;

    // Check for capturing opponent token if on main track (0..50)
    if (newPos >= 0 && newPos <= 50) {
      const globalIdx = getGlobalTrackIndex(color, newPos);
      const isSafe = SAFE_TILES.has(globalIdx);

      if (!isSafe) {
        // Inspect all opponent tokens
        const newTokensMap = { ...tokens };
        (Object.keys(newTokensMap) as LudoColor[]).forEach(otherColor => {
          if (otherColor !== color) {
            newTokensMap[otherColor] = newTokensMap[otherColor].map(otherPos => {
              if (otherPos >= 0 && otherPos <= 50) {
                const otherGlobalIdx = getGlobalTrackIndex(otherColor, otherPos);
                if (otherGlobalIdx === globalIdx) {
                  didCapture = true;
                  audioFX.playLudoCaptureSound();
                  return -1; // Send back to base!
                }
              }
              return otherPos;
            });
          }
        });
        setTokens(newTokensMap);
      }
    }

    // Update current player's token
    setTokens(prev => {
      const updated = [...prev[color]];
      updated[tokenIdx] = newPos;
      return { ...prev, [color]: updated };
    });

    if (didCapture) {
      extraTurn = true;
      setStatusMessage(`💥 CAPTURE! ${getPlayerLabel(color)} sent an opponent back to base and earned an extra roll!`);
    }

    // Check victory condition: all 4 tokens in Home Goal (56)
    const updatedPlayerTokens = [...tokens[color]];
    updatedPlayerTokens[tokenIdx] = newPos;
    if (updatedPlayerTokens.every(p => p === 56)) {
      setWinner(color);
      audioFX.playCheckmateSound();
      confetti({ particleCount: 150, spread: 90 });
      setStatusMessage(`🏆 VICTORY! ${getPlayerLabel(color)} WINS LUDO!`);
      return;
    }

    if (extraTurn) {
      setRolledThisTurn(false);
      if (!didCapture) {
        setStatusMessage(`Bonus Roll! ${getPlayerLabel(color)} rolled a 6 and rolls again.`);
      }
    } else {
      advanceTurn();
    }
  };

  const handleReset = () => {
    setTokens({
      red: [-1, -1, -1, -1],
      green: [-1, -1, -1, -1],
      yellow: [-1, -1, -1, -1],
      blue: [-1, -1, -1, -1]
    });
    setCurrentTurn('red');
    setDiceRoll(6);
    setRolledThisTurn(false);
    setWinner(null);
    setStatusMessage('Game reset. Red Team’s turn to roll.');
  };

  // Helper to determine what occupies a 15x15 board cell
  const getCellTokens = (r: number, c: number) => {
    const list: { color: LudoColor; tokenIdx: number }[] = [];

    (Object.keys(tokens) as LudoColor[]).forEach(color => {
      tokens[color].forEach((pos, tokenIdx) => {
        if (pos >= 0 && pos <= 50) {
          const globalIdx = getGlobalTrackIndex(color, pos);
          const [tr, tc] = TRACK_COORDS[globalIdx];
          if (tr === r && tc === c) list.push({ color, tokenIdx });
        } else if (pos > 50 && pos < 56) {
          const corridorIdx = pos - 51;
          const [cr, cc] = HOME_CORRIDORS[color][corridorIdx];
          if (cr === r && cc === c) list.push({ color, tokenIdx });
        }
      });
    });

    return list;
  };

  return (
    <div className={`space-y-4 max-w-lg mx-auto ${isFullScreen ? 'p-2' : ''}`}>
      {/* 1v1 Challenge Header */}
      {challengeMatch && (
        <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-500/40 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="font-bold text-white">1v1 Authentic Ludo Duel</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono">
            <span className="text-rose-400 font-bold">{challengeMatch.playerRed} (Red)</span>
            <span className="text-gray-400">vs</span>
            <span className="text-emerald-400 font-bold">{challengeMatch.playerGreen} (Green)</span>
          </div>
        </div>
      )}

      {/* Turn & Status Bar */}
      <div className="flex items-center justify-between px-3.5 py-2 bg-black/40 rounded-2xl border border-white/10">
        <div className="flex items-center gap-2">
          <div className={`w-3.5 h-3.5 rounded-full ${PLAYERS[currentTurn].bg} animate-pulse`} />
          <span className={`text-xs font-bold ${PLAYERS[currentTurn].text}`}>
            {getPlayerLabel(currentTurn)}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={rollDice}
            disabled={isRolling || rolledThisTurn || Boolean(winner)}
            className={`px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1.5 active:scale-95 transition disabled:opacity-40`}
          >
            <Dices className={`w-4 h-4 text-amber-400 ${isRolling ? 'animate-spin' : ''}`} />
            <span>Roll: {diceRoll}</span>
          </button>

          <button
            onClick={handleReset}
            className="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition"
            title="Reset Game"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Realistic 15x15 Ludo Board Grid */}
      <div className="w-full max-w-[360px] sm:max-w-[380px] mx-auto aspect-square rounded-3xl p-2 bg-slate-950 border-2 border-white/20 shadow-2xl relative select-none">
        <div className="w-full h-full grid grid-cols-15 grid-rows-15 gap-[1px] bg-slate-900 rounded-2xl overflow-hidden border border-white/10">
          
          {/* Top-Left Red Base (6x6) with Dynamic Corner Dice */}
          <div className={`col-span-6 row-span-6 bg-rose-950/70 border-r-2 border-b-2 border-rose-500/60 p-2 flex flex-col justify-between transition-all ${
            currentTurn === 'red' ? 'ring-2 ring-rose-400/80 shadow-[inset_0_0_20px_rgba(244,63,94,0.3)]' : ''
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black text-rose-400 tracking-wider">RED BASE</span>
              {currentTurn === 'red' && (
                <button
                  onClick={rollDice}
                  disabled={isRolling || rolledThisTurn || Boolean(winner)}
                  className="px-2 py-1 rounded-xl bg-rose-500 text-white text-[10px] font-black shadow-lg flex items-center gap-1 active:scale-90 transition animate-pulse"
                  title="Click to roll dice"
                >
                  <Dices className={`w-3.5 h-3.5 ${isRolling ? 'animate-spin' : ''}`} />
                  <span>{isRolling ? '...' : diceRoll}</span>
                </button>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2 p-1">
              {tokens.red.map((pos, idx) => (
                <button
                  key={idx}
                  onClick={() => handleTokenClick('red', idx)}
                  className={`w-8 h-8 rounded-full border-2 border-white flex items-center justify-center font-bold text-xs text-white shadow-lg transition-all ${
                    pos === -1 ? 'bg-rose-500 hover:scale-110 active:scale-95' : 'bg-rose-900/40 opacity-30 pointer-events-none'
                  } ${currentTurn === 'red' && rolledThisTurn && diceRoll === 6 && pos === -1 ? 'ring-4 ring-white animate-bounce' : ''}`}
                >
                  R{idx + 1}
                </button>
              ))}
            </div>
          </div>

          {/* Top-Middle Green Corridor (3x6) */}
          <div className="col-span-3 row-span-6 grid grid-cols-3 grid-rows-6 gap-[1px] bg-slate-900">
            {Array.from({ length: 18 }).map((_, i) => {
              const r = Math.floor(i / 3);
              const c = 6 + (i % 3);
              const isGreenHome = c === 7 && r > 0;
              const isGreenStart = r === 1 && c === 8;
              const cellTokens = getCellTokens(r, c);

              return (
                <div
                  key={i}
                  className={`flex items-center justify-center relative ${
                    isGreenHome ? 'bg-emerald-600' : isGreenStart ? 'bg-emerald-500/70' : 'bg-slate-800'
                  }`}
                >
                  {isGreenStart && <Star className="w-2.5 h-2.5 text-white/80" />}
                  {cellTokens.map((t, ti) => (
                    <button
                      key={ti}
                      onClick={() => handleTokenClick(t.color, t.tokenIdx)}
                      className={`w-5 h-5 rounded-full ${PLAYERS[t.color].bg} border border-white text-[9px] font-bold text-white flex items-center justify-center shadow-md animate-in zoom-in`}
                    >
                      {t.color[0].toUpperCase()}
                    </button>
                  ))}
                </div>
              );
            })}
          </div>

          {/* Top-Right Green Base (6x6) with Dynamic Corner Dice */}
          <div className={`col-span-6 row-span-6 bg-emerald-950/70 border-l-2 border-b-2 border-emerald-500/60 p-2 flex flex-col justify-between transition-all ${
            currentTurn === 'green' ? 'ring-2 ring-emerald-400/80 shadow-[inset_0_0_20px_rgba(16,185,129,0.3)]' : ''
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black text-emerald-400 tracking-wider">GREEN BASE</span>
              {currentTurn === 'green' && (
                <button
                  onClick={rollDice}
                  disabled={isRolling || rolledThisTurn || Boolean(winner)}
                  className="px-2 py-1 rounded-xl bg-emerald-500 text-white text-[10px] font-black shadow-lg flex items-center gap-1 active:scale-90 transition animate-pulse"
                  title="Click to roll dice"
                >
                  <Dices className={`w-3.5 h-3.5 ${isRolling ? 'animate-spin' : ''}`} />
                  <span>{isRolling ? '...' : diceRoll}</span>
                </button>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2 p-1">
              {tokens.green.map((pos, idx) => (
                <button
                  key={idx}
                  onClick={() => handleTokenClick('green', idx)}
                  className={`w-8 h-8 rounded-full border-2 border-white flex items-center justify-center font-bold text-xs text-white shadow-lg transition-all ${
                    pos === -1 ? 'bg-emerald-500 hover:scale-110 active:scale-95' : 'bg-emerald-900/40 opacity-30 pointer-events-none'
                  } ${currentTurn === 'green' && rolledThisTurn && diceRoll === 6 && pos === -1 ? 'ring-4 ring-white animate-bounce' : ''}`}
                >
                  G{idx + 1}
                </button>
              ))}
            </div>
          </div>

          {/* Middle-Left Track & Red Home Row (6x3) */}
          <div className="col-span-6 row-span-3 grid grid-cols-6 grid-rows-3 gap-[1px] bg-slate-900">
            {Array.from({ length: 18 }).map((_, i) => {
              const r = 6 + Math.floor(i / 6);
              const c = i % 6;
              const isRedHome = r === 7 && c > 0;
              const isRedStart = r === 6 && c === 1;
              const cellTokens = getCellTokens(r, c);

              return (
                <div
                  key={i}
                  className={`flex items-center justify-center relative ${
                    isRedHome ? 'bg-rose-600' : isRedStart ? 'bg-rose-500/70' : 'bg-slate-800'
                  }`}
                >
                  {isRedStart && <Star className="w-2.5 h-2.5 text-white/80" />}
                  {cellTokens.map((t, ti) => (
                    <button
                      key={ti}
                      onClick={() => handleTokenClick(t.color, t.tokenIdx)}
                      className={`w-5 h-5 rounded-full ${PLAYERS[t.color].bg} border border-white text-[9px] font-bold text-white flex items-center justify-center shadow-md animate-in zoom-in`}
                    >
                      {t.color[0].toUpperCase()}
                    </button>
                  ))}
                </div>
              );
            })}
          </div>

          {/* Center Home Triangle Goal (3x3) */}
          <div className="col-span-3 row-span-3 bg-slate-950 border border-white/20 relative flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 grid grid-cols-2 grid-rows-2">
              <div className="bg-rose-600/40 flex items-center justify-center text-[9px] font-bold text-rose-300">R</div>
              <div className="bg-emerald-600/40 flex items-center justify-center text-[9px] font-bold text-emerald-300">G</div>
              <div className="bg-sky-600/40 flex items-center justify-center text-[9px] font-bold text-sky-300">B</div>
              <div className="bg-amber-600/40 flex items-center justify-center text-[9px] font-bold text-amber-300">Y</div>
            </div>
            <Trophy className="w-6 h-6 text-amber-300 z-10 drop-shadow" />
          </div>

          {/* Middle-Right Track & Yellow Home Row (6x3) */}
          <div className="col-span-6 row-span-3 grid grid-cols-6 grid-rows-3 gap-[1px] bg-slate-900">
            {Array.from({ length: 18 }).map((_, i) => {
              const r = 6 + Math.floor(i / 6);
              const c = 9 + (i % 6);
              const isYellowHome = r === 7 && c < 14;
              const isYellowStart = r === 8 && c === 13;
              const cellTokens = getCellTokens(r, c);

              return (
                <div
                  key={i}
                  className={`flex items-center justify-center relative ${
                    isYellowHome ? 'bg-amber-500' : isYellowStart ? 'bg-amber-400/70' : 'bg-slate-800'
                  }`}
                >
                  {isYellowStart && <Star className="w-2.5 h-2.5 text-slate-950/80" />}
                  {cellTokens.map((t, ti) => (
                    <button
                      key={ti}
                      onClick={() => handleTokenClick(t.color, t.tokenIdx)}
                      className={`w-5 h-5 rounded-full ${PLAYERS[t.color].bg} border border-white text-[9px] font-bold text-white flex items-center justify-center shadow-md animate-in zoom-in`}
                    >
                      {t.color[0].toUpperCase()}
                    </button>
                  ))}
                </div>
              );
            })}
          </div>

          {/* Bottom-Left Blue Base (6x6) with Dynamic Corner Dice */}
          <div className={`col-span-6 row-span-6 bg-sky-950/70 border-r-2 border-t-2 border-sky-500/60 p-2 flex flex-col justify-between transition-all ${
            currentTurn === 'blue' ? 'ring-2 ring-sky-400/80 shadow-[inset_0_0_20px_rgba(14,165,233,0.3)]' : ''
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black text-sky-400 tracking-wider">BLUE BASE</span>
              {currentTurn === 'blue' && (
                <button
                  onClick={rollDice}
                  disabled={isRolling || rolledThisTurn || Boolean(winner)}
                  className="px-2 py-1 rounded-xl bg-sky-500 text-white text-[10px] font-black shadow-lg flex items-center gap-1 active:scale-90 transition animate-pulse"
                  title="Click to roll dice"
                >
                  <Dices className={`w-3.5 h-3.5 ${isRolling ? 'animate-spin' : ''}`} />
                  <span>{isRolling ? '...' : diceRoll}</span>
                </button>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2 p-1">
              {tokens.blue.map((pos, idx) => (
                <button
                  key={idx}
                  onClick={() => handleTokenClick('blue', idx)}
                  className={`w-8 h-8 rounded-full border-2 border-white flex items-center justify-center font-bold text-xs text-white shadow-lg transition-all ${
                    pos === -1 ? 'bg-sky-500 hover:scale-110 active:scale-95' : 'bg-sky-900/40 opacity-30 pointer-events-none'
                  } ${currentTurn === 'blue' && rolledThisTurn && diceRoll === 6 && pos === -1 ? 'ring-4 ring-white animate-bounce' : ''}`}
                >
                  B{idx + 1}
                </button>
              ))}
            </div>
          </div>

          {/* Bottom-Middle Track (3x6) */}
          <div className="col-span-3 row-span-6 grid grid-cols-3 grid-rows-6 gap-[1px] bg-slate-900">
            {Array.from({ length: 18 }).map((_, i) => {
              const r = 9 + Math.floor(i / 3);
              const c = 6 + (i % 3);
              const isBlueHome = c === 7 && r < 14;
              const isBlueStart = r === 13 && c === 6;
              const cellTokens = getCellTokens(r, c);

              return (
                <div
                  key={i}
                  className={`flex items-center justify-center relative ${
                    isBlueHome ? 'bg-sky-600' : isBlueStart ? 'bg-sky-500/70' : 'bg-slate-800'
                  }`}
                >
                  {isBlueStart && <Star className="w-2.5 h-2.5 text-white/80" />}
                  {cellTokens.map((t, ti) => (
                    <button
                      key={ti}
                      onClick={() => handleTokenClick(t.color, t.tokenIdx)}
                      className={`w-5 h-5 rounded-full ${PLAYERS[t.color].bg} border border-white text-[9px] font-bold text-white flex items-center justify-center shadow-md animate-in zoom-in`}
                    >
                      {t.color[0].toUpperCase()}
                    </button>
                  ))}
                </div>
              );
            })}
          </div>

          {/* Bottom-Right Yellow Base (6x6) with Dynamic Corner Dice */}
          <div className={`col-span-6 row-span-6 bg-amber-950/70 border-l-2 border-t-2 border-amber-500/60 p-2 flex flex-col justify-between transition-all ${
            currentTurn === 'yellow' ? 'ring-2 ring-amber-400/80 shadow-[inset_0_0_20px_rgba(245,158,11,0.3)]' : ''
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black text-amber-400 tracking-wider">YELLOW BASE</span>
              {currentTurn === 'yellow' && (
                <button
                  onClick={rollDice}
                  disabled={isRolling || rolledThisTurn || Boolean(winner)}
                  className="px-2 py-1 rounded-xl bg-amber-400 text-slate-950 text-[10px] font-black shadow-lg flex items-center gap-1 active:scale-90 transition animate-pulse"
                  title="Click to roll dice"
                >
                  <Dices className={`w-3.5 h-3.5 ${isRolling ? 'animate-spin' : ''}`} />
                  <span>{isRolling ? '...' : diceRoll}</span>
                </button>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2 p-1">
              {tokens.yellow.map((pos, idx) => (
                <button
                  key={idx}
                  onClick={() => handleTokenClick('yellow', idx)}
                  className={`w-8 h-8 rounded-full border-2 border-white flex items-center justify-center font-bold text-xs text-slate-950 shadow-lg transition-all ${
                    pos === -1 ? 'bg-amber-400 hover:scale-110 active:scale-95' : 'bg-amber-900/40 opacity-30 pointer-events-none'
                  } ${currentTurn === 'yellow' && rolledThisTurn && diceRoll === 6 && pos === -1 ? 'ring-4 ring-white animate-bounce' : ''}`}
                >
                  Y{idx + 1}
                </button>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* Status banner */}
      <div className="text-center px-2">
        <p className="text-xs font-semibold text-gray-300">{statusMessage}</p>
      </div>
    </div>
  );
}
