import React, { useState, useEffect } from 'react';
import { 
  Shield, Moon, Sun, Skull, Eye, Heart, Users, RotateCcw, 
  Play, CheckCircle2, AlertTriangle, Sparkles, Trophy, Flame, Vote 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ThemeConfig } from '../../types';
import { audioFX } from '../../utils/audioFX';

interface MafiaGameProps {
  theme: ThemeConfig;
  onClose?: () => void;
}

type Role = 'mafia' | 'doctor' | 'detective' | 'villager';

interface MafiaPlayer {
  id: number;
  name: string;
  role: Role;
  alive: boolean;
  avatarSeed: string;
  votes: number;
}

const DEFAULT_PLAYERS = [
  { name: 'Zavier (You)', seed: 'Z' },
  { name: 'Lucas Silva', seed: 'L' },
  { name: 'Chloe Dubois', seed: 'C' },
  { name: 'Liam O’Connor', seed: 'Li' },
  { name: 'Kenji Sato', seed: 'K' },
  { name: 'Elena Rostova', seed: 'E' }
];

export default function MafiaGame({ theme, onClose }: MafiaGameProps) {
  const [phase, setPhase] = useState<'setup' | 'reveal' | 'night' | 'day' | 'gameover'>('setup');
  const [players, setPlayers] = useState<MafiaPlayer[]>([]);
  const [activeRevealIndex, setActiveRevealIndex] = useState<number>(0);
  const [isCardFlipped, setIsCardFlipped] = useState<boolean>(false);
  
  // Night actions
  const [mafiaTarget, setMafiaTarget] = useState<number | null>(null);
  const [doctorTarget, setDoctorTarget] = useState<number | null>(null);
  const [detectiveTarget, setDetectiveTarget] = useState<number | null>(null);
  const [detectiveResult, setDetectiveResult] = useState<string | null>(null);

  // Day voting
  const [dayVoteTarget, setDayVoteTarget] = useState<number | null>(null);
  const [dayLog, setDayLog] = useState<string[]>([]);
  const [dayTimer, setDayTimer] = useState<number>(60);
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const [winner, setWinner] = useState<string | null>(null);

  const startGame = () => {
    const roles: Role[] = ['mafia', 'mafia', 'detective', 'doctor', 'villager', 'villager'];
    const shuffledRoles = [...roles].sort(() => Math.random() - 0.5);

    const generatedPlayers: MafiaPlayer[] = DEFAULT_PLAYERS.map((p, i) => ({
      id: i + 1,
      name: p.name,
      avatarSeed: p.seed,
      role: shuffledRoles[i],
      alive: true,
      votes: 0
    }));

    setPlayers(generatedPlayers);
    setActiveRevealIndex(0);
    setIsCardFlipped(false);
    setPhase('reveal');
  };

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (phase === 'day' && timerRunning && dayTimer > 0) {
      interval = setInterval(() => setDayTimer((t: number) => t - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [phase, timerRunning, dayTimer]);

  const checkVictory = (currentPlayers: MafiaPlayer[]): boolean => {
    const aliveMafia = currentPlayers.filter((p: MafiaPlayer) => p.alive && p.role === 'mafia').length;
    const aliveCivilians = currentPlayers.filter((p: MafiaPlayer) => p.alive && p.role !== 'mafia').length;

    if (aliveMafia === 0) {
      setWinner('Town & Civilians Win! All Syndicate members eliminated!');
      setPhase('gameover');
      audioFX.playCheckmateSound();
      confetti({ particleCount: 120, spread: 80 });
      return true;
    }
    if (aliveMafia >= aliveCivilians) {
      setWinner('Mafia Syndicate Wins! The town has fallen.');
      setPhase('gameover');
      audioFX.playEliminationSound();
      return true;
    }
    return false;
  };

  const resolveNight = () => {
    let victim: MafiaPlayer | null = null;
    let saved = false;

    if (mafiaTarget !== null) {
      victim = players.find((p: MafiaPlayer) => p.id === mafiaTarget) || null;
    }
    if (doctorTarget !== null && mafiaTarget !== null && doctorTarget === mafiaTarget) {
      saved = true;
    }

    const updated = players.map((p: MafiaPlayer) => {
      if (victim && p.id === victim.id && !saved) {
        return { ...p, alive: false };
      }
      return p;
    });

    setPlayers(updated);

    if (victim && !saved) {
      audioFX.playEliminationSound();
    }

    const logEntry = saved
      ? `Dawn breaks: The Doctor successfully saved the target! No casualties tonight.`
      : victim
      ? `Dawn breaks: ${victim.name} was eliminated by the Syndicate.`
      : `Dawn breaks: Quiet night. Nobody was harmed.`;

    setDayLog([logEntry]);
    setMafiaTarget(null);
    setDoctorTarget(null);
    setDetectiveTarget(null);
    setDetectiveResult(null);

    if (!checkVictory(updated)) {
      setPhase('day');
      setDayTimer(60);
      setTimerRunning(true);
    }
  };

  const castVote = (id: number) => {
    setDayVoteTarget(id);
    setPlayers(prev => prev.map(p => ({
      ...p,
      votes: p.id === id ? p.votes + 1 : p.votes
    })));
  };

  const resolveDayVote = () => {
    if (dayVoteTarget === null) return;
    const target = players.find((p: MafiaPlayer) => p.id === dayVoteTarget);
    if (!target) return;

    audioFX.playEliminationSound();
    const updated = players.map((p: MafiaPlayer) => (p.id === target.id ? { ...p, alive: false } : p));
    setPlayers(updated);
    setDayLog((prev: string[]) => [
      ...prev,
      `Town Trial Execution: ${target.name} was sentenced to exile! Role was [${target.role.toUpperCase()}].`
    ]);
    setDayVoteTarget(null);
    setTimerRunning(false);

    if (!checkVictory(updated)) {
      setTimeout(() => {
        setPhase('night');
      }, 1500);
    }
  };

  const inspectSuspect = (id: number) => {
    const suspect = players.find((p: MafiaPlayer) => p.id === id);
    if (!suspect) return;
    setDetectiveTarget(id);
    if (suspect.role === 'mafia') {
      setDetectiveResult(`⚠️ ${suspect.name} IS GUILTY! Member of the Mafia.`);
    } else {
      setDetectiveResult(`✅ ${suspect.name} is INNOCENT civilian.`);
    }
  };

  return (
    <div className="space-y-4 max-w-lg mx-auto select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
            <Skull className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight">Mafia Round Table</h3>
            <span className="text-[10px] text-gray-400 font-mono">Visual Social Deduction</span>
          </div>
        </div>

        <button
          onClick={() => setPhase('setup')}
          className="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition"
          title="Restart Game"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* PHASE 1: SETUP */}
      {phase === 'setup' && (
        <div className="space-y-4 text-center py-2 animate-in fade-in">
          <div className="p-4 rounded-3xl bg-slate-900/80 border border-white/10 text-left space-y-3">
            <span className="text-xs font-bold text-purple-300 block">Roundtable Roster (6 Players):</span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {DEFAULT_PLAYERS.map((p, i) => (
                <div key={i} className="flex items-center gap-2 p-1.5 rounded-xl bg-white/5 border border-white/5 text-gray-300">
                  <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center justify-center">
                    {p.seed}
                  </div>
                  <span className="truncate">{p.name}</span>
                </div>
              ))}
            </div>
            <p className="text-[11px] text-gray-400">
              Secret roles to deal: 2 Mafia Syndicate, 1 Detective, 1 Doctor, 2 Civilians.
            </p>
          </div>

          <button
            onClick={startGame}
            className={`w-full py-3.5 rounded-2xl ${theme.accent} text-white font-bold text-xs uppercase tracking-wider shadow-xl flex items-center justify-center gap-2 active:scale-95 transition`}
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Deal Secret Roles & Gather</span>
          </button>
        </div>
      )}

      {/* PHASE 2: SECRET REVEAL CARD */}
      {phase === 'reveal' && (
        <div className="space-y-4 text-center py-2 animate-in zoom-in-95">
          <div className="p-2.5 bg-purple-950/40 border border-purple-500/30 rounded-2xl text-xs text-purple-200">
            Pass device to: <strong className="text-white text-sm">{players[activeRevealIndex]?.name}</strong>
          </div>

          {/* 3D Flip Card */}
          <div
            onClick={() => setIsCardFlipped(!isCardFlipped)}
            className="w-full h-56 rounded-3xl cursor-pointer relative perspective-1000 transition-all duration-500"
          >
            <div className={`w-full h-full rounded-3xl p-5 border-2 flex flex-col items-center justify-center transition-all duration-500 shadow-2xl ${
              isCardFlipped
                ? 'bg-gradient-to-tr from-purple-950 to-indigo-950 border-purple-400 shadow-purple-500/20'
                : 'bg-slate-900 border-white/20 hover:border-white/40'
            }`}>
              {isCardFlipped ? (
                <div className="space-y-2 text-center animate-in zoom-in">
                  <span className="text-4xl">
                    {players[activeRevealIndex]?.role === 'mafia' ? '🕶️' : players[activeRevealIndex]?.role === 'detective' ? '🔍' : players[activeRevealIndex]?.role === 'doctor' ? '💉' : '🌾'}
                  </span>
                  <h4 className="text-xl font-black uppercase tracking-wider text-purple-300">
                    {players[activeRevealIndex]?.role}
                  </h4>
                  <p className="text-xs text-gray-300 max-w-xs">
                    {players[activeRevealIndex]?.role === 'mafia' && 'Eliminate civilians each night. Blend in during the day.'}
                    {players[activeRevealIndex]?.role === 'detective' && 'Investigate one suspect each night to expose them.'}
                    {players[activeRevealIndex]?.role === 'doctor' && 'Protect one player each night from elimination.'}
                    {players[activeRevealIndex]?.role === 'villager' && 'Find the truth through daytime discussions and voting.'}
                  </p>
                  <span className="text-[10px] text-white/40 block pt-1">Tap card to hide again</span>
                </div>
              ) : (
                <div className="space-y-2 text-gray-400 text-center">
                  <Eye className="w-8 h-8 mx-auto text-purple-400 animate-pulse" />
                  <span className="text-xs font-bold block text-white">Tap Card to Reveal Secret Identity</span>
                  <span className="text-[10px] text-gray-500 block">Ensure nobody else is looking</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-2">
            {activeRevealIndex < players.length - 1 ? (
              <button
                onClick={() => {
                  setActiveRevealIndex(prev => prev + 1);
                  setIsCardFlipped(false);
                }}
                className={`w-full py-3 rounded-2xl ${theme.accent} text-white text-xs font-bold transition`}
              >
                Next Player ({activeRevealIndex + 1}/{players.length})
              </button>
            ) : (
              <button
                onClick={() => setPhase('night')}
                className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center justify-center gap-1.5"
              >
                <Moon className="w-4 h-4" />
                <span>Begin First Night Phase</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* PHASE 3 & 4: VISUAL CIRCULAR ROUNDTABLE (NIGHT & DAY) */}
      {(phase === 'night' || phase === 'day') && (
        <div className={`p-4 rounded-3xl border transition-all duration-700 relative overflow-hidden ${
          phase === 'night'
            ? 'bg-slate-950 border-indigo-900/60 shadow-[inset_0_0_80px_rgba(30,27,75,0.8)]'
            : 'bg-stone-950 border-amber-900/40 shadow-[inset_0_0_80px_rgba(120,53,15,0.4)]'
        }`}>
          {/* Phase Banner */}
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/10 text-xs">
            <div className="flex items-center gap-1.5 font-bold">
              {phase === 'night' ? (
                <>
                  <Moon className="w-4 h-4 text-indigo-400" />
                  <span className="text-indigo-300">Night Phase: Syndicate Strikes</span>
                </>
              ) : (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span className="text-amber-300">Day Trial: Town Assembly ({dayTimer}s)</span>
                </>
              )}
            </div>
            {phase === 'day' && (
              <button
                onClick={() => setTimerRunning(!timerRunning)}
                className="px-2 py-0.5 rounded-lg bg-white/10 text-[10px] text-white"
              >
                {timerRunning ? 'Pause' : 'Start'}
              </button>
            )}
          </div>

          {/* Central Roundtable Radial Layout */}
          <div className="relative w-full aspect-square max-w-[320px] mx-auto flex items-center justify-center my-3">
            {/* Center Campfire / Monument */}
            <div className="w-20 h-20 rounded-full bg-black/60 border-2 border-white/20 flex flex-col items-center justify-center z-10 shadow-2xl">
              {phase === 'night' ? (
                <>
                  <Moon className="w-6 h-6 text-indigo-400 animate-pulse" />
                  <span className="text-[9px] text-indigo-300 font-mono">ASLEEP</span>
                </>
              ) : (
                <>
                  <Flame className="w-6 h-6 text-amber-400 animate-bounce" />
                  <span className="text-[9px] text-amber-300 font-mono">COUNCIL</span>
                </>
              )}
            </div>

            {/* Circular arrangement of 6 player avatars */}
            {players.map((p, idx) => {
              const angle = (idx * (360 / players.length) - 90) * (Math.PI / 180);
              const radius = 115; // Distance from center
              const x = Math.round(radius * Math.cos(angle));
              const y = Math.round(radius * Math.sin(angle));

              const isTargeted = mafiaTarget === p.id || dayVoteTarget === p.id;
              const isProtected = doctorTarget === p.id;

              return (
                <div
                  key={p.id}
                  style={{ transform: `translate(${x}px, ${y}px)` }}
                  onClick={() => {
                    if (!p.alive) return;
                    if (phase === 'night') {
                      if (!mafiaTarget) setMafiaTarget(p.id);
                      else if (!doctorTarget) setDoctorTarget(p.id);
                      else inspectSuspect(p.id);
                    } else if (phase === 'day') {
                      castVote(p.id);
                    }
                  }}
                  className={`absolute w-16 h-16 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all ${
                    !p.alive
                      ? 'bg-black/60 border border-red-900/40 opacity-40 grayscale'
                      : isTargeted
                      ? 'bg-rose-950 border-2 border-rose-500 scale-110 shadow-lg shadow-rose-500/40 ring-2 ring-rose-400/50'
                      : isProtected
                      ? 'bg-emerald-950 border-2 border-emerald-500'
                      : 'bg-slate-900/90 border border-white/20 hover:border-white/50 hover:scale-105'
                  }`}
                >
                  <span className="text-xs font-bold text-white leading-tight truncate max-w-[54px]">
                    {p.avatarSeed}
                  </span>
                  <span className="text-[8px] text-gray-300 truncate max-w-[56px]">
                    {p.name.split(' ')[0]}
                  </span>
                  {!p.alive && (
                    <Skull className="w-3.5 h-3.5 text-red-500 absolute -top-1 -right-1" />
                  )}
                  {phase === 'day' && p.votes > 0 && p.alive && (
                    <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-slate-950 font-bold text-[9px] flex items-center justify-center">
                      {p.votes}
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Action HUD based on Phase */}
          {phase === 'night' && (
            <div className="space-y-2 pt-2 border-t border-white/10 text-xs">
              <div className="flex justify-between items-center text-[11px] text-gray-300">
                <span>1. Mafia Target: <strong className="text-rose-400">{players.find(p => p.id === mafiaTarget)?.name || 'None selected'}</strong></span>
                <span>2. Doctor Protected: <strong className="text-emerald-400">{players.find(p => p.id === doctorTarget)?.name || 'None'}</strong></span>
              </div>
              {detectiveResult && (
                <div className="p-2 rounded-xl bg-sky-950/80 border border-sky-400/40 text-[11px] font-bold text-sky-200">
                  {detectiveResult}
                </div>
              )}
              <button
                onClick={resolveNight}
                disabled={mafiaTarget === null}
                className={`w-full py-2.5 rounded-xl ${theme.accent} text-white font-bold text-xs disabled:opacity-40 transition flex items-center justify-center gap-1.5`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>Wake Council & Resolve Night</span>
              </button>
            </div>
          )}

          {phase === 'day' && (
            <div className="space-y-2 pt-2 border-t border-white/10 text-xs">
              <div className="space-y-1">
                {dayLog.map((log, i) => (
                  <p key={i} className="text-[11px] text-amber-200/90 leading-tight">
                    {log}
                  </p>
                ))}
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={resolveDayVote}
                  disabled={dayVoteTarget === null}
                  className={`flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs disabled:opacity-40 transition flex items-center justify-center gap-1.5`}
                >
                  <Vote className="w-3.5 h-3.5" />
                  <span>Execute Accused Suspect</span>
                </button>
                <button
                  onClick={() => {
                    setDayLog(prev => [...prev, 'Town council decided to skip voting today.']);
                    setPhase('night');
                  }}
                  className="px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs transition"
                >
                  Skip
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* PHASE 5: GAME OVER */}
      {phase === 'gameover' && (
        <div className="text-center py-6 space-y-4 animate-in zoom-in-95">
          <Trophy className="w-12 h-12 text-amber-400 mx-auto animate-bounce" />
          <h3 className="text-base font-black text-white">{winner}</h3>
          
          <div className="p-4 rounded-3xl bg-slate-900 border border-white/10 space-y-2 text-left">
            <span className="text-xs font-bold text-gray-300 block">Final Identity Reveal:</span>
            <div className="space-y-1 text-xs">
              {players.map(p => (
                <div key={p.id} className="flex justify-between items-center text-gray-300">
                  <span className={p.alive ? 'text-white font-semibold' : 'line-through text-gray-500'}>{p.name}</span>
                  <span className="capitalize font-bold text-purple-400">{p.role}</span>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={startGame}
            className={`w-full py-3.5 rounded-2xl ${theme.accent} text-white font-bold text-xs uppercase tracking-wider transition`}
          >
            Play Another Game
          </button>
        </div>
      )}
    </div>
  );
}
