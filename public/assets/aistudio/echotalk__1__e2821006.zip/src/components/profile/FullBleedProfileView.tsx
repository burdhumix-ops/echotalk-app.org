import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, MessageSquare, UserPlus, Gift, Sparkles, Globe, 
  X, Check, Lock, Edit3, Settings, Camera, ShieldCheck, ChevronLeft, ChevronRight, Share2,
  Music, Volume2, VolumeX, Play, Pause, Disc
} from 'lucide-react';
import { ThemeConfig, UserProfile } from '../../types';
import { getCountryFlag, getGenderIcon } from '../../utils/profileUtils';
import { detectUserLocation } from '../../services/ipLocation';
import { hapticTap } from '../../utils/haptics';

// Procedural 5-second soothing lo-fi synth chord progression via Web Audio API
function playMusicPreview(onEnd?: () => void): () => void {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return () => {};
    const ctx = new AudioContextClass();

    const chords = [
      { time: 0.0, freqs: [261.63, 329.63, 392.00, 493.88] }, // Cmaj7
      { time: 1.6, freqs: [220.00, 261.63, 329.63, 392.00] }, // Am7
      { time: 3.2, freqs: [174.61, 220.00, 261.63, 329.63] }  // Fmaj7
    ];

    const master = ctx.createGain();
    master.gain.setValueAtTime(0.12, ctx.currentTime);
    master.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 5.0);
    master.connect(ctx.destination);

    chords.forEach((chord) => {
      chord.freqs.forEach((freq, fIdx) => {
        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();
        osc.type = fIdx % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + chord.time);
        noteGain.gain.setValueAtTime(0.001, ctx.currentTime + chord.time);
        noteGain.gain.linearRampToValueAtTime(0.07, ctx.currentTime + chord.time + 0.1);
        noteGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + chord.time + 1.5);
        osc.connect(noteGain);
        noteGain.connect(master);
        osc.start(ctx.currentTime + chord.time);
        osc.stop(ctx.currentTime + chord.time + 1.6);
      });
    });

    const timer = setTimeout(() => {
      try { ctx.close(); } catch (_) {}
      onEnd && onEnd();
    }, 5000);

    return () => {
      clearTimeout(timer);
      try { ctx.close(); } catch (_) {}
    };
  } catch (_) {
    return () => {};
  }
}

interface FullBleedProfileViewProps {
  user: UserProfile;
  isCurrentUser?: boolean;
  onOpenDM?: (user: UserProfile) => void;
  onOpenSettings?: () => void;
  onClose?: () => void;
  theme: ThemeConfig;
  onUpdateCurrentUser?: (updater: (prev: any) => any) => void;
}

export default function FullBleedProfileView({
  user,
  isCurrentUser = false,
  onOpenDM,
  onOpenSettings,
  onClose,
  theme,
  onUpdateCurrentUser
}: FullBleedProfileViewProps) {
  const [likeCount, setLikeCount] = useState<number>(user.likeCount || 142);
  const [isLiked, setIsLiked] = useState<boolean>(user.isLiked || false);
  const [friendReqSent, setFriendReqSent] = useState<boolean>(user.isFriendReqSent || false);
  const [giftSentMessage, setGiftSentMessage] = useState<string>('');
  
  // Carousel active index
  const [activeSlide, setActiveSlide] = useState<number>(0);
  const [expandedPhoto, setExpandedPhoto] = useState<string | null>(null);

  // Dynamic Profile Banner & 5-Second Favorite Music Preview
  const [bannerMode, setBannerMode] = useState<'photo' | 'animated'>('photo');
  const [isPlayingMusic, setIsPlayingMusic] = useState<boolean>(false);
  const [musicProgress, setMusicProgress] = useState<number>(0);
  const stopAudioRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    // Softly play 5-second favorite music preview when profile view opens
    const autoPlayTimeout = setTimeout(() => {
      startMusicPlayback();
    }, 500);

    return () => {
      clearTimeout(autoPlayTimeout);
      if (stopAudioRef.current) {
        stopAudioRef.current();
      }
    };
  }, []);

  const startMusicPlayback = () => {
    if (stopAudioRef.current) stopAudioRef.current();
    setIsPlayingMusic(true);
    let progress = 0;
    const progressInterval = setInterval(() => {
      progress += 4;
      if (progress >= 100) {
        clearInterval(progressInterval);
        setMusicProgress(100);
      } else {
        setMusicProgress(progress);
      }
    }, 200);

    stopAudioRef.current = playMusicPreview(() => {
      setIsPlayingMusic(false);
      setMusicProgress(0);
      clearInterval(progressInterval);
    });
  };

  const toggleMusicPlayback = () => {
    hapticTap(10);
    if (isPlayingMusic) {
      if (stopAudioRef.current) stopAudioRef.current();
      setIsPlayingMusic(false);
      setMusicProgress(0);
    } else {
      startMusicPlayback();
    }
  };

  // Automatic IP-based detected location
  const [detectedLocation, setDetectedLocation] = useState<{ country: string; countryCode: string; flag: string }>({
    country: user.country || 'United States',
    countryCode: user.countryCode || 'US',
    flag: getCountryFlag(user.countryCode || user.country)
  });

  useEffect(() => {
    if (isCurrentUser) {
      detectUserLocation().then((loc) => {
        setDetectedLocation({
          country: loc.country,
          countryCode: loc.countryCode,
          flag: loc.flag
        });
        if (onUpdateCurrentUser) {
          onUpdateCurrentUser((prev: any) => ({
            ...prev,
            country: loc.country,
            countryCode: loc.countryCode
          }));
        }
      });
    }
  }, [isCurrentUser]);

  const portfolio = user.portfolio && user.portfolio.length > 0 
    ? user.portfolio 
    : [
        user.avatarUrl || '/src/assets/images/avatar_zavier_founder_1792623177719.jpg',
        '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
        '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg',
        '/src/assets/images/gallery_desert_oasis_1792620681182.jpg',
        '/src/assets/images/view_once_aurora_1792618101621.jpg'
      ];

  const handleLike = () => {
    if (isLiked) {
      setLikeCount((c) => c - 1);
      setIsLiked(false);
    } else {
      setLikeCount((c) => c + 1);
      setIsLiked(true);
    }
  };

  const handleFriendReq = () => {
    setFriendReqSent(!friendReqSent);
  };

  const handleSendGift = () => {
    setGiftSentMessage('✨ Sent VIP Golden Rose to ' + user.name + '!');
    setTimeout(() => setGiftSentMessage(''), 2500);
  };

  return (
    <div className="w-full min-h-full flex flex-col bg-slate-950 text-white select-none pb-20 relative overflow-x-hidden">
      
      {/* 1. TOP FULL-BLEED PHOTO CAROUSEL (Auto-Fitting clamp(300px, 42vh, 480px)) */}
      <div 
        style={{ height: 'clamp(300px, 42vh, 480px)', width: '100%', position: 'relative' }}
        className="bg-slate-900 overflow-hidden shrink-0 gpu-accelerated"
      >
        <div 
          className="flex h-full w-full overflow-x-scroll snap-x snap-mandatory scrollbar-none touch-pan-x"
          style={{ 
            scrollSnapType: 'x mandatory',
            overflowX: 'scroll',
            WebkitOverflowScrolling: 'touch'
          }}
          onScroll={(e) => {
            const el = e.currentTarget;
            const index = Math.round(el.scrollLeft / el.clientWidth);
            setActiveSlide(index);
          }}
        >
          {portfolio.map((imgUrl, i) => (
            <div
              key={i}
              onClick={() => setExpandedPhoto(imgUrl)}
              className="w-full h-full flex-shrink-0 snap-center relative cursor-zoom-in"
              style={{ scrollSnapAlign: 'center', scrollSnapStop: 'always' }}
            >
              <img
                src={imgUrl}
                alt={`${user.name} photo ${i + 1}`}
                style={{ objectFit: 'cover', width: '100%', height: '100%' }}
                className="w-full h-full object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/35 pointer-events-none" />
            </div>
          ))}
        </div>

        {/* Dynamic Animated Live Banner Overlay */}
        {bannerMode === 'animated' && (
          <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden mix-blend-screen opacity-90">
            <div className="absolute -inset-10 bg-gradient-to-r from-purple-600/30 via-pink-600/20 to-cyan-500/30 blur-2xl animate-pulse" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-500/30 via-transparent to-transparent" />
          </div>
        )}

        {/* Top Header Floating Buttons */}
        <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between pointer-events-auto">
          {onClose ? (
            <button
              onClick={onClose}
              className="p-2.5 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md text-white transition active:scale-95 shadow-lg border border-white/15"
              title="Close Profile"
            >
              <X className="w-5 h-5" />
            </button>
          ) : (
            <div className="flex items-center gap-2 bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/15 text-xs font-mono text-emerald-400 shadow-md">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Verified Identity</span>
            </div>
          )}

          <div className="flex items-center gap-2">
            {/* Dynamic Animated Profile Banner Toggle */}
            <button
              onClick={() => {
                hapticTap(10);
                setBannerMode(bannerMode === 'photo' ? 'animated' : 'photo');
              }}
              className={`p-2 rounded-full backdrop-blur-md transition active:scale-95 shadow-lg border text-xs font-semibold flex items-center gap-1 ${
                bannerMode === 'animated'
                  ? 'bg-gradient-to-r from-pink-500/40 to-cyan-500/40 border-pink-400 text-white'
                  : 'bg-black/50 hover:bg-black/80 border-white/15 text-gray-300'
              }`}
              title="Toggle Dynamic Animated Profile Banner"
            >
              <Sparkles className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
              <span className="text-[11px] pr-1 hidden sm:inline">{bannerMode === 'animated' ? 'Live Banner' : 'Banner'}</span>
            </button>

            {isCurrentUser && onOpenSettings && (
              <button
                onClick={onOpenSettings}
                className="p-2.5 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md text-white transition active:scale-95 shadow-lg border border-white/15"
                title="Profile Settings"
              >
                <Settings className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Auto-Positioned Indicator Dots relative to bottom edge */}
        <div 
          className="pointer-events-none"
          style={{ position: 'absolute', bottom: '12px', left: '50%', transform: 'translateX(-50%)', zIndex: 10 }}
        >
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 shadow-md">
            {portfolio.map((_, i) => (
              <div
                key={i}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  activeSlide === i ? 'w-5 bg-white shadow-sm' : 'w-1.5 bg-white/40'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* 2. DYNAMIC ACTION QUICK BAR (Auto-adjusting flex row with touch-action: pan-x scrolling) */}
      <div 
        style={{
          display: 'flex',
          flexWrap: 'nowrap',
          overflowX: 'auto',
          width: '100%',
          padding: '12px 16px',
          gap: '10px',
          scrollSnapType: 'x mandatory',
          WebkitOverflowScrolling: 'touch',
          touchAction: 'pan-x'
        }}
        className="bg-slate-900/90 backdrop-blur-xl border-y border-white/10 z-10 shrink-0 scrollbar-none"
      >
        {/* Like Heart with Count */}
        <button
          onClick={handleLike}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl transition active:scale-90 shrink-0 snap-start ${
            isLiked 
              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 shadow-rose-950/40' 
              : 'bg-white/5 hover:bg-white/10 text-gray-300 border border-white/5'
          }`}
          title="Like Profile"
        >
          <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500 text-rose-500 animate-bounce' : ''}`} />
          <span className="text-xs font-bold font-mono">{likeCount}</span>
        </button>

        {/* Direct Message */}
        <button
          onClick={() => onOpenDM && onOpenDM(user)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-950/40 transition active:scale-95 shrink-0 snap-start"
          title="Send Direct Message"
        >
          <MessageSquare className="w-4 h-4" />
          <span>Message</span>
        </button>

        {/* Friend Request */}
        <button
          onClick={handleFriendReq}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl transition active:scale-95 border shrink-0 snap-start ${
            friendReqSent
              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
              : 'bg-white/5 hover:bg-white/10 text-gray-300 border-white/5'
          }`}
          title="Add Friend"
        >
          {friendReqSent ? <Check className="w-4 h-4 text-emerald-400" /> : <UserPlus className="w-4 h-4" />}
          <span className="text-xs font-semibold">{friendReqSent ? 'Sent' : 'Friend'}</span>
        </button>

        {/* Send Gift */}
        <button
          onClick={handleSendGift}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 transition active:scale-95 shadow shrink-0 snap-start"
          title="Send Virtual Gift"
        >
          <Gift className="w-4 h-4" />
          <span className="text-xs font-semibold">Gift</span>
        </button>
      </div>

      {/* Gift notification toast */}
      {giftSentMessage && (
        <div className="mx-4 mt-3 p-3 rounded-2xl bg-gradient-to-r from-amber-500/20 to-rose-500/20 border border-amber-400/40 text-amber-200 text-xs font-bold text-center animate-in zoom-in-95">
          {giftSentMessage}
        </div>
      )}

      {/* 3. FLUID USER PROFILE DETAILS (Auto-Height Flow) */}
      <div 
        style={{ height: 'auto', width: '100%' }}
        className="p-4 sm:p-6 space-y-4 max-w-xl mx-auto w-full h-auto min-h-fit"
      >
        {/* Header: Prominent @username & Display Name */}
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {user.name}
            </h1>
            <span className="text-xs font-mono px-3 py-1 rounded-full bg-white/10 border border-white/15 text-indigo-300">
              {user.role === 'owner' ? '👑 Founder' : user.role === 'admin' ? '🛡️ Admin' : 'Member'}
            </span>
          </div>
          <p className="text-sm font-mono font-bold text-indigo-400">
            {user.handle || `@${user.name.toLowerCase().replace(/\s+/g, '')}`}
          </p>
        </div>

        {/* 5-Second Favorite Music Preview Card (Plays softly when opened) */}
        <div className="p-3.5 rounded-3xl bg-gradient-to-r from-indigo-950/70 via-purple-950/50 to-slate-900/90 border border-indigo-500/30 backdrop-blur-xl flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={toggleMusicPlayback}
              className={`p-2.5 rounded-2xl transition active:scale-90 shrink-0 shadow-md ${
                isPlayingMusic 
                  ? 'bg-rose-500 text-white shadow-rose-500/30' 
                  : 'bg-indigo-600/40 hover:bg-indigo-600/60 text-indigo-200 border border-indigo-400/30'
              }`}
              title={isPlayingMusic ? "Pause Preview" : "Play 5-Second Favorite Music Preview"}
            >
              {isPlayingMusic ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-indigo-200" />}
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <Disc className={`w-3.5 h-3.5 text-indigo-400 ${isPlayingMusic ? 'animate-spin' : ''}`} />
                <span className="text-xs font-bold text-white truncate">
                  Favorite Track Preview
                </span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-full border border-emerald-500/20">
                  5s
                </span>
              </div>
              <p className="text-[11px] text-indigo-300/80 truncate">
                "Midnight Reverie" — Lo-Fi Chill Synth
              </p>
            </div>
          </div>

          {/* Soundwave Bars & Real-Time Animation */}
          <div className="flex items-center gap-1 h-5 shrink-0 px-1">
            {[4, 12, 8, 16, 10, 14, 7, 11].map((h, i) => (
              <div
                key={i}
                style={{
                  height: isPlayingMusic 
                    ? `${Math.max(4, h * (0.4 + 0.6 * Math.sin(Date.now() / 150 + i * 0.9)))}px`
                    : '4px'
                }}
                className={`w-1 rounded-full transition-all duration-150 ${
                  isPlayingMusic ? 'bg-gradient-to-t from-pink-500 to-indigo-400' : 'bg-white/20'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Attributes Row: Gender Icon (♀️/♂️), Age, Country Name, and Country Flag */}
        <div className="p-3.5 rounded-3xl bg-white/[0.05] border border-white/10 backdrop-blur-xl flex items-center justify-between flex-wrap gap-3 shadow-lg">
          {/* Gender */}
          <div className="flex items-center gap-2">
            <span className="text-base select-none">{getGenderIcon(user.gender)}</span>
            <span className="text-xs text-gray-300 font-medium">{user.gender || 'Female'}</span>
          </div>

          <div className="w-px h-4 bg-white/10" />

          {/* Age */}
          <div className="flex items-center gap-1.5 font-mono">
            <span className="text-xs text-gray-400">Age:</span>
            <strong className="text-sm font-bold text-white">{user.age || 24}</strong>
          </div>

          <div className="w-px h-4 bg-white/10" />

          {/* Automatic IP-Based Country & Flag (Locked so users cannot fake) */}
          <div className="flex items-center gap-2" title="Location detected and verified via IP address">
            <span className="text-lg select-none">{detectedLocation.flag}</span>
            <span className="text-xs font-bold text-white">{detectedLocation.country}</span>
            <div className="flex items-center gap-0.5 text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 font-mono">
              <Lock className="w-2.5 h-2.5" />
              <span>IP Verified</span>
            </div>
          </div>
        </div>

        {/* Bio Section with clean typography and glassmorphism accents */}
        <div className="p-4 rounded-3xl bg-white/[0.04] border border-white/10 backdrop-blur-xl space-y-2.5 shadow-md">
          <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block">
            About & Bio
          </span>
          <p className="text-xs text-gray-200 leading-relaxed font-normal">
            "{user.bio || 'Living life through aesthetics, game challenges, and creative connections.'}"
          </p>

          {/* Translation Snippet */}
          <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-indigo-300/90 font-mono">
            <span className="flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
              <span>Auto-translated to primary local language</span>
            </span>
            <span className="text-[10px] text-emerald-400">Gemini Live</span>
          </div>
        </div>

        {/* 4. SLIDABLE PHOTO GRID GALLERY (Touch-slidable portfolio carousel / grid) */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <span>Photo Portfolio Showcase</span>
              <span className="text-[10px] font-mono text-gray-400">({portfolio.length})</span>
            </span>
            <span className="text-[11px] text-gray-400">Tap photo to expand full-screen</span>
          </div>

          {/* Touch-slidable horizontal strip / responsive grid */}
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-2.5">
            {portfolio.map((url, idx) => (
              <div
                key={idx}
                onClick={() => setExpandedPhoto(url)}
                className="aspect-square rounded-2xl overflow-hidden border border-white/10 hover:border-white/30 cursor-pointer shadow-md hover:scale-[1.03] transition-all duration-200 active:scale-95 group relative"
              >
                <img
                  src={url}
                  alt={`Portfolio ${idx + 1}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* FULL-SCREEN HIGH-RES IMAGE VIEWER WITH ZOOM TRANSITIONS */}
      {expandedPhoto && (
        <div
          onClick={() => setExpandedPhoto(null)}
          className="fixed inset-0 z-60 bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 cursor-zoom-out animate-in fade-in duration-200 select-none"
        >
          <div className="relative max-w-lg w-full max-h-[85vh] rounded-3xl overflow-hidden border border-white/20 shadow-2xl animate-in zoom-in-95 duration-200">
            <button
              onClick={() => setExpandedPhoto(null)}
              className="absolute top-4 right-4 p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white transition z-10"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={expandedPhoto}
              alt="High-Res Expanded View"
              className="w-full h-auto max-h-[85vh] object-contain mx-auto"
            />
          </div>
        </div>
      )}

    </div>
  );
}
