import React, { useState, useEffect } from 'react';
import { Flame, ShieldAlert, EyeOff, Clock, Sparkles } from 'lucide-react';
import { ThemeConfig } from '../types';

interface ViewOnceViewerProps {
  mediaUrl: string;
  senderName: string;
  onBurn: () => void;
  theme: ThemeConfig;
}

export default function ViewOnceViewer({ mediaUrl, senderName, onBurn, theme }: ViewOnceViewerProps) {
  const [timeLeft, setTimeLeft] = useState<number>(5);
  const [isBurning, setIsBurning] = useState<boolean>(false);

  useEffect(() => {
    if (timeLeft <= 0) {
      triggerBurn();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          triggerBurn();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const triggerBurn = () => {
    setIsBurning(true);
    setTimeout(() => {
      onBurn();
    }, 900);
  };

  const circumference = 2 * Math.PI * 18;
  const strokeDashoffset = circumference - (timeLeft / 5) * circumference;

  return (
    <div className={`fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex flex-col justify-between p-4 select-none transition-opacity duration-500 ${isBurning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
      
      {/* Top Header */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Flame className="w-4 h-4 animate-bounce" />
          </div>
          <div>
            <span className="text-xs font-bold text-white block">View Once from {senderName}</span>
            <span className="text-[10px] text-amber-300/80">Self-destructs after viewing</span>
          </div>
        </div>

        {/* Circular Countdown Progress */}
        <div className="relative w-11 h-11 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 44 44">
            <circle
              cx="22"
              cy="22"
              r="18"
              stroke="rgba(255,255,255,0.15)"
              strokeWidth="3.5"
              fill="transparent"
            />
            <circle
              cx="22"
              cy="22"
              r="18"
              stroke="#F59E0B"
              strokeWidth="3.5"
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="transition-all duration-1000 ease-linear"
            />
          </svg>
          <span className="absolute font-bold text-sm text-white font-mono">{timeLeft}s</span>
        </div>
      </div>

      {/* Main Image Box */}
      <div className="flex-1 flex items-center justify-center my-4 overflow-hidden relative">
        <div className="relative max-w-sm w-full rounded-3xl overflow-hidden border border-white/20 shadow-2xl bg-black">
          <img
            src={mediaUrl}
            alt="View Once Secret"
            referrerPolicy="no-referrer"
            className={`w-full max-h-[60vh] object-cover transition-all duration-700 ${
              isBurning ? 'blur-xl scale-110 brightness-200' : 'blur-0 scale-100'
            }`}
          />

          {isBurning && (
            <div className="absolute inset-0 bg-gradient-to-t from-red-600/80 via-amber-500/60 to-transparent flex items-center justify-center">
              <div className="text-center">
                <Flame className="w-16 h-16 text-yellow-300 mx-auto animate-pulse" />
                <span className="text-lg font-black text-white tracking-widest uppercase">Incinerating...</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Info Bar & Burn Now button */}
      <div className="space-y-3 pb-4">
        <div className="flex items-center justify-center gap-2 text-xs text-white/50">
          <ShieldAlert className="w-4 h-4 text-amber-400" />
          <span>Screenshot protection active · Auto-expiring</span>
        </div>
        <button
          onClick={triggerBurn}
          className="w-full py-3.5 rounded-2xl bg-red-600/80 hover:bg-red-500 border border-red-500/40 text-white font-semibold text-xs tracking-wide uppercase flex items-center justify-center gap-2 active:scale-[0.98] transition"
        >
          <Flame className="w-4 h-4" />
          <span>Destroy & Burn Now</span>
        </button>
      </div>
    </div>
  );
}
