import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, Send, Edit3, Eye, Flame, Mic, Image as ImageIcon, 
  MoreVertical, Check, CheckCheck, Smile, Play, Pause, Ban, 
  UserCheck, ShieldAlert, Sparkles, Volume2, Gamepad2, Swords, Lock, X, EyeOff,
  Globe, Trash2, Sliders, Shield, Copy, Camera, Upload, Phone, Video, Palette, Wand2
} from 'lucide-react';
import { ActiveChatTarget, ChatMessage, ChatRoom, GameChallengeData, ThemeConfig, UserProfile } from '../types';
import ViewOnceViewer from './ViewOnceViewer';
import TelegramMediaPicker from './TelegramMediaPicker';
import PhotoEditorModal from './chat/PhotoEditorModal';
import DustDissolveEffect from './chat/DustDissolveEffect';
import AudioWaveformCanvas from './chat/AudioWaveformCanvas';
import CallModal from './chat/CallModal';
import { ChatSkeletonStream } from './common/SkeletonLoader';
import { bulkTranslateMessages, translateTextWithGemini } from '../services/geminiTranslation';
import { generateSmartReplies, polishTranscriptTone, PolishTone } from '../services/geminiSmartReplies';
import { hapticTap, hapticDoublePulse, hapticHeavyBump } from '../utils/haptics';
import FullBleedProfileView from './profile/FullBleedProfileView';

interface FullChatScreenProps {
  activeChat: ActiveChatTarget;
  onBack: () => void;
  currentUser: { name: string; role: 'owner' | 'admin' | 'member'; isHidden: boolean };
  onSendMessage: (
    text: string, 
    isViewOnce?: boolean, 
    isDoodle?: boolean, 
    mediaUrl?: string, 
    isAudio?: boolean,
    challengeData?: GameChallengeData,
    audioDuration?: string,
    audioWaveform?: number[]
  ) => void;
  onDeleteMessage?: (msgId: number, deleteForEveryone: boolean) => void;
  onAcceptRequest?: (userId: number) => void;
  onBlockUser?: (userId: number, name: string) => void;
  theme: ThemeConfig;
  onOpenDoodle: () => void;
  messages: ChatMessage[];
  onMarkViewOnceOpened: (msgId: number) => void;
  onAddReaction: (msgId: number, emoji: string) => void;
  onAcceptChallenge: (challenge: GameChallengeData) => void;
}

export default function FullChatScreen({
  activeChat,
  onBack,
  currentUser,
  onSendMessage,
  onDeleteMessage,
  onAcceptRequest,
  onBlockUser,
  theme,
  onOpenDoodle,
  messages,
  onMarkViewOnceOpened,
  onAddReaction,
  onAcceptChallenge
}: FullChatScreenProps) {
  const [inputText, setInputText] = useState<string>('');
  const [isViewOnceArmed, setIsViewOnceArmed] = useState<boolean>(false);
  const [activeViewOnceMedia, setActiveViewOnceMedia] = useState<{ url: string; msgId: number; sender: string } | null>(null);
  const [showTelegramGallery, setShowTelegramGallery] = useState<boolean>(false);
  const [showGameChallengeMenu, setShowGameChallengeMenu] = useState<boolean>(false);
  const [showActionsMenu, setShowActionsMenu] = useState<boolean>(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState<boolean>(false);
  const [recordSeconds, setRecordSeconds] = useState<number>(0);
  const [recordedWaveform, setRecordedWaveform] = useState<number[]>([]);
  const recordIntervalRef = useRef<number | null>(null);
  const [showPartnerProfile, setShowPartnerProfile] = useState<boolean>(false);

  // Photo Editor Modal state
  const [editingPhotoUrl, setEditingPhotoUrl] = useState<string | null>(null);

  // Gemini AI Translation States
  const [isTranslateOn, setIsTranslateOn] = useState<boolean>(() => {
    try {
      return localStorage.getItem(`echotalk_trans_${activeChat.data.name}`) === 'true';
    } catch {
      return false;
    }
  });
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [translatedMap, setTranslatedMap] = useState<Record<number, string>>({});

  // Typing status state
  const [isPartnerTyping, setIsPartnerTyping] = useState<boolean>(false);

  // Google Pixel-Style Long-Press Context Menu & Deletion
  const [pixelMenu, setPixelMenu] = useState<{
    msg: ChatMessage;
    x: number;
    y: number;
    isAbove: boolean;
  } | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const longPressTimerRef = useRef<number | null>(null);
  const touchStartCoords = useRef<{ x: number; y: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [dissolvingMsgIds, setDissolvingMsgIds] = useState<Set<number>>(new Set());

  // WebRTC Audio / Video Call State (Strict Mutual Acceptance Gate)
  const [activeCall, setActiveCall] = useState<{ type: 'audio' | 'video' } | null>(null);

  // Pulse-Animated Skeleton Loader State
  const [isLoadingMessages, setIsLoadingMessages] = useState<boolean>(true);

  // AI Contextual Smart Reply Chips
  const [smartReplies, setSmartReplies] = useState<string[]>([]);

  // Voice-to-Text Tone Polish States
  const [showTonePolishModal, setShowTonePolishModal] = useState<boolean>(false);
  const [tonePolishText, setTonePolishText] = useState<string>('');
  const [isPolishing, setIsPolishing] = useState<boolean>(false);

  // Per-DM Chat Accent Color Tints
  const CHAT_ACCENTS = [
    { id: 'indigo', name: 'Classic Indigo', class: 'bg-indigo-600 text-white shadow-md' },
    { id: 'sunset', name: 'Sunset Pink', class: 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-md' },
    { id: 'cyan', name: 'Electric Cyan', class: 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md' },
    { id: 'emerald', name: 'Emerald Glow', class: 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md' },
    { id: 'purple', name: 'Midnight Purple', class: 'bg-gradient-to-r from-purple-600 to-indigo-800 text-white shadow-md' }
  ];

  const [selectedAccent, setSelectedAccent] = useState<string>(() => {
    try {
      return localStorage.getItem(`echotalk_accent_${activeChat.data.name}`) || 'indigo';
    } catch {
      return 'indigo';
    }
  });
  const [showAccentPicker, setShowAccentPicker] = useState<boolean>(false);

  const activeAccentClass = CHAT_ACCENTS.find((a) => a.id === selectedAccent)?.class || '';

  const showToast = (text: string) => {
    setToastMessage(text);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleCustomFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        // Open the full-screen Telegram/Pixel-style image editor canvas
        setEditingPhotoUrl(dataUrl);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleMessagePointerDown = (msg: ChatMessage, e: React.PointerEvent) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    touchStartCoords.current = { x: e.clientX, y: e.clientY };

    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);

    const target = e.currentTarget as HTMLElement;

    // 300ms Google Pixel-style responsive long-press gesture
    longPressTimerRef.current = window.setTimeout(() => {
      const rect = target.getBoundingClientRect();
      const isAbove = rect.top > 220;
      const x = Math.max(16, Math.min(window.innerWidth - 270, rect.left));
      const y = isAbove ? rect.top - 8 : rect.bottom + 8;

      setPixelMenu({
        msg,
        x,
        y,
        isAbove
      });
      setShowDeleteConfirm(false);
      if (navigator.vibrate) navigator.vibrate(30);
    }, 300);
  };

  const handleMessagePointerUp = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handleMessagePointerMove = (e: React.PointerEvent) => {
    if (!touchStartCoords.current || !longPressTimerRef.current) return;
    const dist = Math.hypot(e.clientX - touchStartCoords.current.x, e.clientY - touchStartCoords.current.y);
    if (dist > 10) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handleMessageContextMenu = (msg: ChatMessage, e: React.MouseEvent) => {
    e.preventDefault();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const isAbove = rect.top > 220;
    const x = Math.max(16, Math.min(window.innerWidth - 270, e.clientX - 100));
    const y = isAbove ? rect.top - 8 : rect.bottom + 8;

    setPixelMenu({
      msg,
      x,
      y,
      isAbove
    });
    setShowDeleteConfirm(false);
  };

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const isRoom = activeChat.type === 'room';
  const chatData = activeChat.data as (ChatRoom & UserProfile);
  const isMessageRequest = !isRoom && !(chatData as UserProfile).isFriend;
  const isMutualFriend = !isRoom && Boolean((chatData as UserProfile).isFriend);
  const reqCount = !isRoom ? (chatData as UserProfile).reqCount || 0 : 0;
  const isCapped = isMessageRequest && reqCount >= 3;

  // Pulse skeleton loader effect on chat switch
  useEffect(() => {
    setIsLoadingMessages(true);
    const t = setTimeout(() => setIsLoadingMessages(false), 240);
    return () => clearTimeout(t);
  }, [activeChat]);

  // Contextual AI Smart Reply Chips
  useEffect(() => {
    const lastMsg = messages[messages.length - 1];
    if (lastMsg && lastMsg.sender !== currentUser.name && !lastMsg.isAudio && !lastMsg.isDoodle) {
      generateSmartReplies(lastMsg.text).then((chips) => {
        setSmartReplies(chips);
      });
    } else {
      setSmartReplies([]);
    }
  }, [messages, currentUser.name]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, dissolvingMsgIds, isLoadingMessages]);

  // Periodic simulated typing indicator when other party is active in the same DM
  useEffect(() => {
    if (isRoom) return;
    const typingTimer = setTimeout(() => {
      setIsPartnerTyping(true);
      const stopTimer = setTimeout(() => {
        setIsPartnerTyping(false);
      }, 3500);
      return () => clearTimeout(stopTimer);
    }, 1800);

    return () => clearTimeout(typingTimer);
  }, [activeChat, isRoom]);

  // Instant Whole-Page Translation when toggled ON
  useEffect(() => {
    if (!isTranslateOn) return;

    let isMounted = true;
    setIsTranslating(true);

    bulkTranslateMessages(messages, 'English').then((map) => {
      if (isMounted) {
        setTranslatedMap(map);
        setIsTranslating(false);
      }
    });

    return () => {
      isMounted = false;
    };
  }, [isTranslateOn, messages]);

  const toggleTranslation = () => {
    const nextState = !isTranslateOn;
    setIsTranslateOn(nextState);
    try {
      localStorage.setItem(`echotalk_trans_${activeChat.data.name}`, String(nextState));
    } catch {}
  };

  const handleSend = () => {
    if (!inputText.trim()) return;
    if (isCapped) return;

    onSendMessage(inputText.trim(), isViewOnceArmed, false);
    setInputText('');
    setIsViewOnceArmed(false);
  };

  // Called when user selects photos from Telegram gallery
  const handleSelectFromGallery = (photos: { url: string; isViewOnce: boolean }[]) => {
    setShowTelegramGallery(false);
    if (photos.length > 0) {
      // Open Telegram photo editor on the first photo
      setEditingPhotoUrl(photos[0].url);
    }
  };

  const handleSendFromEditor = (editedImgUrl: string, isViewOnce?: boolean) => {
    setEditingPhotoUrl(null);
    onSendMessage(
      isViewOnce ? '[ View Once Photo ]' : editedImgUrl,
      isViewOnce,
      false,
      editedImgUrl
    );
  };

  const handleStartRecording = () => {
    setIsRecordingVoice(true);
    setRecordSeconds(0);
    setRecordedWaveform([]);

    if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);

    recordIntervalRef.current = window.setInterval(() => {
      setRecordSeconds((s) => s + 1);
      setRecordedWaveform((prev) => {
        const nextAmp = Math.max(0.2, Math.min(1.0, 0.25 + Math.random() * 0.75));
        return [...prev, nextAmp];
      });
    }, 1000);
  };

  const handleCancelRecording = () => {
    if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
    recordIntervalRef.current = null;
    setIsRecordingVoice(false);
    setRecordSeconds(0);
    setRecordedWaveform([]);
  };

  const handleFinishAndSendVoiceNote = () => {
    if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
    recordIntervalRef.current = null;

    const finalSecs = Math.max(1, recordSeconds);
    const durationStr = `0:${finalSecs < 10 ? '0' : ''}${finalSecs}`;

    // Generate or use recorded waveform samples
    const samples = recordedWaveform.length >= 8
      ? recordedWaveform
      : Array.from({ length: 36 }, (_, i) => {
          const envelope = Math.sin((i / 36) * Math.PI);
          return Math.max(0.18, Math.min(1.0, envelope * (0.3 + Math.random() * 0.7) * 1.3));
        });

    onSendMessage(
      `Voice Note (${durationStr})`,
      isViewOnceArmed,
      false,
      undefined,
      true,
      undefined,
      durationStr,
      samples
    );

    setIsRecordingVoice(false);
    setRecordSeconds(0);
    setRecordedWaveform([]);
    setIsViewOnceArmed(false);
  };

  const handleSendChallenge = (game: 'chess' | 'ludo') => {
    setShowGameChallengeMenu(false);
    const challengeData: GameChallengeData = {
      game,
      status: 'pending',
      challenger: currentUser.name,
      opponent: chatData.name,
      challengerId: 999,
      opponentId: chatData.id,
      matchId: `match-${Date.now()}`
    };

    const gameTitle = game === 'chess' ? 'Chess Classic (1v1 Duel)' : 'Ludo Master (1v1 Race)';
    onSendMessage(`⚔️ Sent a 1v1 challenge for ${gameTitle}!`, false, false, undefined, false, challengeData);
  };

  // Trigger Telegram dust dissolve animation before deleting
  const triggerDustDelete = (msgId: number, deleteForEveryone: boolean) => {
    setDissolvingMsgIds((prev) => new Set(prev).add(msgId));
    setTimeout(() => {
      if (onDeleteMessage) {
        onDeleteMessage(msgId, deleteForEveryone);
      }
      setDissolvingMsgIds((prev) => {
        const next = new Set(prev);
        next.delete(msgId);
        return next;
      });
    }, 400); // 400ms dust animation duration
  };

  const handleTranslateSingleMessage = async (msg: ChatMessage) => {
    setPixelMenu(null);
    showToast('Translating with Gemini AI...');
    try {
      const translated = await translateTextWithGemini(msg.text, 'English');
      setTranslatedMap((prev) => ({
        ...prev,
        [msg.id]: translated
      }));
      showToast('Translated with Gemini AI');
    } catch {
      showToast('Translation error');
    }
  };

  return (
    <div 
      style={{
        display: 'flex',
        flexDirection: 'column',
        height: '100dvh',
        maxHeight: '100dvh',
        overflow: 'hidden'
      }}
      className={`fixed inset-0 z-50 flex flex-col h-[100dvh] max-h-[100dvh] overflow-hidden ${theme.bg} ${theme.text} select-none animate-in fade-in duration-150`}
    >
      
      {/* --- TOP BAR (iOS Frosted Glass) --- */}
      <header 
        style={{
          flex: '0 0 auto',
          paddingTop: 'max(8px, env(safe-area-inset-top))'
        }}
        className={`h-auto min-h-16 px-4 py-2 flex items-center justify-between border-b ${theme.border} ${theme.surface} z-20 shrink-0 shadow-sm`}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              theme.isDark ? 'hover:bg-white/10 text-white' : 'hover:bg-black/5 text-slate-800'
            }`}
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div
            onClick={() => !isRoom && setShowPartnerProfile(true)}
            className={`flex items-center gap-2.5 ${!isRoom ? 'cursor-pointer hover:opacity-90 transition' : ''}`}
            title={!isRoom ? "View profile & portfolio" : undefined}
          >
            <div className="relative">
              <div className={`w-10 h-10 rounded-2xl overflow-hidden flex items-center justify-center font-bold text-sm shadow border border-white/10 ${
                isRoom ? 'bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-950' : 'bg-gradient-to-tr from-indigo-500 to-purple-600 text-white'
              }`}>
                {!isRoom && (chatData as UserProfile).avatarUrl ? (
                  <img
                    src={(chatData as UserProfile).avatarUrl}
                    alt={chatData.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  chatData.name ? chatData.name[0] : '#'
                )}
              </div>
              {!isRoom && (
                <div className={`w-3 h-3 rounded-full absolute -bottom-0.5 -right-0.5 border-2 border-slate-950 ${
                  (chatData as UserProfile).online ? 'bg-emerald-400' : 'bg-gray-500'
                }`} />
              )}
            </div>

            <div>
              <h2 className={`text-sm font-bold tracking-tight flex items-center gap-1.5 truncate max-w-[150px] sm:max-w-xs ${theme.text}`}>
                {chatData.name}
                {isRoom && (chatData as ChatRoom).isSpecial && (
                  <span className="text-[10px] bg-amber-500/20 text-amber-400 px-1.5 py-0.2 rounded font-mono border border-amber-500/30">VIP</span>
                )}
              </h2>

              {/* Dynamic typing status or active state */}
              {!isRoom && isPartnerTyping ? (
                <span className="text-[10px] text-indigo-400 font-semibold flex items-center gap-1 animate-pulse">
                  <span>typing</span>
                  <span className="inline-flex gap-0.5">
                    <span className="w-1 h-1 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1 h-1 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1 h-1 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </span>
                </span>
              ) : (
                <span className="text-[10px] text-gray-400 flex items-center gap-1">
                  {isRoom 
                    ? `${(chatData as ChatRoom).memberCount || 42} active crew members` 
                    : (chatData as UserProfile).online ? 'Active now' : 'Offline'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Action Header Controls */}
        <div className="relative flex items-center gap-2">
          
          {/* 🌐 Gemini AI Translate Whole-Page Toggle Switch */}
          <button
            onClick={toggleTranslation}
            className={`px-3 py-1.5 rounded-2xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shadow-sm border ${
              isTranslateOn
                ? 'bg-indigo-600 text-white border-indigo-500 shadow-indigo-600/30'
                : 'bg-white/5 hover:bg-white/10 text-gray-400 border-white/5'
            }`}
            title="Toggle Gemini AI Whole-Page Chat Translation"
          >
            <Globe className={`w-3.5 h-3.5 ${isTranslating ? 'animate-spin text-amber-300' : 'text-indigo-400'}`} />
            <span className="hidden sm:inline font-mono">{isTranslateOn ? 'Translate ON' : 'Translate'}</span>
          </button>

          {/* Strict Mutual Acceptance Gate: Audio (📞) and Video (📹) calls */}
          {!isRoom && isMutualFriend && (
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  hapticTap(10);
                  setActiveCall({ type: 'audio' });
                }}
                className="p-2 rounded-2xl bg-white/5 hover:bg-emerald-500/20 text-emerald-400 transition active:scale-95"
                title="Start Audio Call (Mutual Friends Only)"
              >
                <Phone className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  hapticTap(10);
                  setActiveCall({ type: 'video' });
                }}
                className="p-2 rounded-2xl bg-white/5 hover:bg-indigo-500/20 text-indigo-400 transition active:scale-95"
                title="Start HD Video Call & Screen Share (Mutual Friends Only)"
              >
                <Video className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Quick Challenge Shortcut in Header */}
          {!isRoom && (
            <button
              onClick={() => setShowGameChallengeMenu(!showGameChallengeMenu)}
              className="p-2 rounded-2xl bg-white/5 hover:bg-white/15 text-indigo-400 transition"
              title="1v1 Game Challenge"
            >
              <Gamepad2 className="w-4 h-4" />
            </button>
          )}

          {/* Per-DM Chat Accent Color Button */}
          {!isRoom && (
            <button
              onClick={() => {
                hapticTap(10);
                setShowAccentPicker(!showAccentPicker);
              }}
              className="p-2 rounded-2xl bg-white/5 hover:bg-white/15 text-pink-400 transition active:scale-95"
              title="Customize DM Bubble Color Accent"
            >
              <Palette className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={() => setShowActionsMenu(!showActionsMenu)}
            className="w-9 h-9 rounded-full hover:bg-white/10 flex items-center justify-center text-gray-300 transition"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {/* Header Action Menu */}
          {showActionsMenu && (
            <div className="absolute right-0 top-11 w-48 rounded-2xl bg-slate-900 border border-white/15 p-1.5 shadow-2xl z-30 text-xs animate-in zoom-in-95">
              {!isRoom && (
                <button
                  onClick={() => {
                    setShowPartnerProfile(true);
                    setShowActionsMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-white/10 text-indigo-300 flex items-center gap-2 transition"
                >
                  <ImageIcon className="w-4 h-4" />
                  <span>View Full Profile</span>
                </button>
              )}
              {!isRoom && onBlockUser && (
                <button
                  onClick={() => {
                    onBlockUser(chatData.id, chatData.name);
                    setShowActionsMenu(false);
                    onBack();
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-red-500/20 text-red-400 flex items-center gap-2 transition"
                >
                  <Ban className="w-4 h-4" />
                  <span>Block {chatData.name}</span>
                </button>
              )}
              <button
                onClick={() => {
                  onSendMessage("Voice Note (Simulated)", false, false, undefined, true);
                  setShowActionsMenu(false);
                }}
                className="w-full text-left px-3 py-2 rounded-xl hover:bg-white/10 text-gray-300 flex items-center gap-2 transition"
              >
                <Mic className="w-4 h-4" />
                <span>Simulate Voice Note</span>
              </button>
            </div>
          )}
        </div>
      </header>

      {/* --- MESSAGE REQUEST CAPPING BANNER --- */}
      {isMessageRequest && (
        <div className="bg-amber-500/15 border-b border-amber-500/30 px-4 py-2.5 flex items-center justify-between text-xs text-amber-200">
          <div className="space-y-0.5">
            <span className="font-semibold block text-amber-300">
              Message Request ({reqCount}/3 messages)
            </span>
            <span className="text-[11px] text-amber-200/80">
              {isCapped
                ? 'Limit reached. Accept request to continue communicating.'
                : 'Limited to 3 messages prior to approval.'}
            </span>
          </div>

          {onAcceptRequest && (
            <div className="flex gap-2">
              <button
                onClick={() => onAcceptRequest(chatData.id)}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 transition shadow-md"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Accept</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* --- MESSAGES FEED (Auto-Expanding flex: 1 1 auto; min-height: 0;) --- */}
      <div 
        style={{
          flex: '1 1 auto',
          minHeight: 0,
          overflowY: 'auto',
          willChange: 'transform'
        }}
        className="overflow-y-auto p-4 space-y-3.5 scrollbar-thin"
      >
        {isLoadingMessages ? (
          <ChatSkeletonStream />
        ) : messages.length === 0 ? (
          <div className="text-center py-20 text-gray-500 space-y-2">
            <div className="w-12 h-12 rounded-full bg-white/5 mx-auto flex items-center justify-center text-gray-400">
              <Sparkles className="w-6 h-6 text-indigo-400 opacity-60" />
            </div>
            <p className="text-xs">No messages yet. Send a greeting, photo, or 1v1 game challenge!</p>
          </div>
        ) : (
          messages.map((m) => {
            const isMe = m.sender === currentUser.name;
            const status = m.status || 'seen';
            const isMediaOrDoodle = m.isDoodle || Boolean(m.mediaUrl) || (m.isViewOnce && !m.viewed);
            const isDissolving = dissolvingMsgIds.has(m.id);

            // Text displayed: either Gemini translation or original raw text
            const displayText = (isTranslateOn && translatedMap[m.id]) ? translatedMap[m.id] : m.text;
            const isTranslatedBubble = Boolean(isTranslateOn && translatedMap[m.id] && translatedMap[m.id] !== m.text);

            return (
              <div
                key={m.id}
                className={`flex flex-col group ${isMe ? 'items-end' : 'items-start'} transition-all duration-300 relative ${
                  isDissolving ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100'
                }`}
                style={{ willChange: 'transform, opacity' }}
              >
                {/* Dust Dissolve Particle Canvas Overlay */}
                {isDissolving && (
                  <DustDissolveEffect onComplete={() => {}} width={260} height={70} />
                )}

                <span className="text-[10px] text-gray-400 px-1 mb-1 font-medium flex items-center gap-1.5">
                  <span>{m.sender} · {m.timestamp}</span>
                  {isTranslatedBubble && (
                    <span className="text-emerald-400 flex items-center gap-0.5">
                      <Sparkles className="w-2.5 h-2.5" />
                      <span>Gemini</span>
                    </span>
                  )}
                </span>

                <div
                  onPointerDown={(e) => handleMessagePointerDown(m, e)}
                  onPointerUp={handleMessagePointerUp}
                  onPointerMove={handleMessagePointerMove}
                  onPointerCancel={handleMessagePointerUp}
                  onContextMenu={(e) => handleMessageContextMenu(m, e)}
                  className={`max-w-[85%] sm:max-w-[70%] relative transition-all cursor-pointer select-none ripple-target overflow-hidden ${
                    isMediaOrDoodle
                      ? 'rounded-[18px] bg-transparent p-0 border-0 shadow-md'
                      : `rounded-2xl p-3 text-sm ${isMe ? (activeAccentClass || theme.bubbleUser) : theme.bubbleOther}`
                  }`}
                >
                  {/* 1v1 GAME CHALLENGE CARD */}
                  {m.isChallenge && m.challengeData ? (
                    <div className="space-y-3 py-1">
                      <div className="flex items-center gap-2 border-b border-white/10 pb-2">
                        <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                          <Gamepad2 className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-white uppercase tracking-wide">
                            1v1 {m.challengeData.game === 'chess' ? 'Chess Classic' : 'Ludo Master'} Duel
                          </h4>
                          <span className="text-[10px] text-gray-300">
                            {m.challengeData.challenger} challenged {m.challengeData.opponent}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-xs bg-black/30 p-2.5 rounded-xl border border-white/5">
                        <span className="text-[11px] text-gray-300 font-mono">Status: Pending Duel</span>
                        <button
                          onClick={() => onAcceptChallenge(m.challengeData!)}
                          className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition"
                        >
                          <Swords className="w-3.5 h-3.5" />
                          <span>Accept & Play</span>
                        </button>
                      </div>
                    </div>
                  ) : m.isDoodle ? (
                    /* BORDERLESS DOODLE MESSAGE */
                    <div className="space-y-1">
                      <div className="rounded-[18px] overflow-hidden bg-slate-950/90 shadow-md">
                        <img
                          src={m.text}
                          alt="Doodle"
                          className="w-60 max-h-60 object-contain rounded-[18px]"
                        />
                      </div>
                      <span className="text-[10px] text-white/70 italic flex items-center gap-1 px-1">
                        <Edit3 className="w-3 h-3 text-pink-400" />
                        Instagram Doodle & Markup
                      </span>
                    </div>
                  ) : m.isViewOnce ? (
                    /* VIEW ONCE MESSAGE */
                    m.viewed ? (
                      <div className="flex items-center gap-2 text-xs font-medium text-gray-400 opacity-70 py-2 px-3 rounded-2xl bg-white/5">
                        <Eye className="w-4 h-4 text-gray-500" />
                        <span className="italic line-through">View Once Photo (Expired & Incinerated)</span>
                      </div>
                    ) : (
                      <div
                        onClick={() => {
                          const targetUrl = m.mediaUrl || m.text.startsWith('http') || m.text.startsWith('/src')
                            ? (m.mediaUrl || m.text)
                            : '/src/assets/images/view_once_aurora_1792618101621.jpg';
                          setActiveViewOnceMedia({ url: targetUrl, msgId: m.id, sender: m.sender });
                        }}
                        className="relative w-60 h-40 rounded-[18px] overflow-hidden cursor-pointer group/flame shadow-md"
                      >
                        <img
                          src={m.mediaUrl || m.text}
                          alt="Secret media"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover blur-md scale-110 opacity-70 rounded-[18px]"
                        />
                        <div className="absolute inset-0 bg-black/45 backdrop-blur-[2px] flex flex-col items-center justify-center gap-1.5 text-center p-2 group-hover/flame:bg-black/35 transition rounded-[18px]">
                          <div className="w-9 h-9 rounded-full bg-amber-500/30 border border-amber-400/60 flex items-center justify-center text-amber-300 shadow">
                            <Flame className="w-5 h-5 animate-pulse" />
                          </div>
                          <span className="text-xs font-bold text-amber-300">1 View-Once Photo</span>
                          <span className="text-[10px] text-white/80 bg-black/40 px-2.5 py-0.5 rounded-full border border-white/10">
                            Tap to Open (Self-Destructs)
                          </span>
                        </div>
                      </div>
                    )
                  ) : m.isAudio ? (
                    /* REAL-TIME VISUAL AUDIO WAVEFORM ANIMATION CANVAS */
                    <AudioWaveformCanvas
                      messageId={m.id}
                      duration={m.audioDuration || '0:05'}
                      initialWaveform={m.audioWaveform}
                      audioUrl={m.mediaUrl}
                      isMe={isMe}
                      theme={theme}
                    />
                  ) : m.mediaUrl ? (
                    /* BORDERLESS REGULAR MEDIA IMAGE */
                    <div className="space-y-1">
                      <div className="rounded-[18px] overflow-hidden shadow-md">
                        <img
                          src={m.mediaUrl}
                          alt="Shared media"
                          referrerPolicy="no-referrer"
                          className="w-64 max-h-72 rounded-[18px] object-cover"
                        />
                      </div>
                      {m.text && m.text !== m.mediaUrl && (
                        <p className="p-2 text-xs text-white/90 bg-black/40 backdrop-blur-md rounded-xl leading-relaxed">
                          {displayText}
                        </p>
                      )}
                    </div>
                  ) : (
                    /* STANDARD TEXT */
                    <p className="whitespace-pre-wrap break-words leading-relaxed">{displayText}</p>
                  )}

                  {/* Read Receipt */}
                  {isMe && !isRoom && (
                    <div className={`flex items-center justify-end gap-1 text-[10px] text-white/70 font-mono ${
                      isMediaOrDoodle ? 'mt-1 px-1 drop-shadow-md' : 'mt-1'
                    }`}>
                      <span>{m.timestamp}</span>
                      {status === 'seen' ? (
                        <div className="flex items-center gap-0.5 text-cyan-300 font-semibold" title="Seen by recipient">
                          <CheckCheck className="w-3.5 h-3.5 stroke-[2.5]" />
                          <span className="text-[9px]">Seen</span>
                        </div>
                      ) : status === 'delivered' ? (
                        <div className="flex items-center text-white/70" title="Delivered">
                          <CheckCheck className="w-3.5 h-3.5 stroke-[2]" />
                        </div>
                      ) : (
                        <div className="flex items-center text-white/50" title="Sent">
                          <Check className="w-3.5 h-3.5 stroke-[2]" />
                        </div>
                      )}
                    </div>
                  )}

                  {/* Reaction badge attached to corner of message bubble */}
                  {m.reactions && Object.entries(m.reactions).some(([_, count]) => (count || 0) > 0) && (
                    <div className={`absolute -bottom-2.5 ${isMe ? 'right-2' : 'left-2'} z-10 flex items-center gap-1 bg-slate-900/90 border border-white/20 px-2 py-0.5 rounded-full shadow-lg backdrop-blur-md animate-in zoom-in-75 duration-150`}>
                      {Object.entries(m.reactions)
                        .filter(([_, count]) => (count || 0) > 0)
                        .map(([emoji, count]) => (
                          <span key={emoji} className="text-xs flex items-center leading-none">
                            <span>{emoji}</span>
                            {(count || 0) > 1 && (
                              <span className="text-[10px] font-mono font-bold text-gray-300 ml-0.5">{count}</span>
                            )}
                          </span>
                        ))}
                    </div>
                  )}

                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* --- 1v1 GAME CHALLENGE SELECTION POPOVER --- */}
      {showGameChallengeMenu && (
        <div className="p-3 bg-slate-900/95 border-t border-white/15 flex items-center justify-between gap-2 z-20 animate-in slide-in-from-bottom-2">
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-white">Send 1v1 Game Challenge:</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleSendChallenge('chess')}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1 transition shadow active:scale-95"
            >
              <span>♔ Chess</span>
            </button>
            <button
              onClick={() => handleSendChallenge('ludo')}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 transition shadow active:scale-95"
            >
              <span>🎲 Ludo</span>
            </button>
            <button
              onClick={() => setShowGameChallengeMenu(false)}
              className="text-xs text-gray-400 hover:text-white px-2 py-1"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* --- AI CONTEXTUAL SMART REPLY CHIPS (Gemini AI) --- */}
      {smartReplies.length > 0 && !isRecordingVoice && !isCapped && (
        <div className="px-3 py-1.5 flex items-center gap-1.5 overflow-x-auto scrollbar-none border-t border-white/5 bg-slate-900/80 backdrop-blur-md shrink-0">
          <div className="flex items-center gap-1 text-[10px] text-indigo-400 font-mono font-bold shrink-0">
            <Sparkles className="w-3 h-3 text-indigo-400" />
            <span>AI Reply:</span>
          </div>
          {smartReplies.map((reply, i) => (
            <button
              key={i}
              onClick={() => {
                hapticTap(10);
                onSendMessage(reply, false, false);
                setSmartReplies([]);
              }}
              className="px-3 py-1 rounded-xl bg-white/10 hover:bg-indigo-600/30 hover:border-indigo-400/50 border border-white/10 text-xs font-medium text-gray-200 hover:text-white transition whitespace-nowrap active:scale-95 shadow-sm"
            >
              {reply}
            </button>
          ))}
        </div>
      )}

      {/* --- BOTTOM CHAT COMPOSER DOCK (Auto-Adjusting flex: 0 0 auto; height: auto;) --- */}
      <footer 
        style={{
          flex: '0 0 auto',
          height: 'auto',
          paddingBottom: 'max(12px, env(safe-area-inset-bottom))'
        }}
        className={`p-3 border-t ${theme.border} ${theme.surface} z-20 shrink-0`}
      >
        {isRecordingVoice ? (
          /* ACTIVE REAL-TIME VOICE RECORDING DRAWER */
          <div className="flex items-center gap-2.5 w-full bg-rose-500/15 border border-rose-500/30 py-2 px-3 rounded-2xl animate-in fade-in duration-200">
            {/* Cancel Recording */}
            <button
              onClick={handleCancelRecording}
              className="p-2.5 rounded-xl bg-white/10 hover:bg-rose-600/40 text-rose-300 hover:text-white transition active:scale-90 shrink-0"
              title="Discard voice recording"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            {/* Pulsing Recording Indicator & Timer */}
            <div className="flex items-center gap-1.5 shrink-0">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span className="text-xs font-mono font-bold text-rose-200">
                0:{recordSeconds < 10 ? '0' : ''}{recordSeconds}
              </span>
            </div>

            {/* Real-time Dynamic Recording Audio Waveform Bars */}
            <div className="flex-1 flex items-center justify-center gap-1 h-6 px-1 overflow-hidden">
              {[4, 9, 6, 12, 7, 14, 10, 16, 8, 13, 11, 15, 6, 10, 8, 12, 5, 9, 13, 7].map((h, i) => (
                <div
                  key={i}
                  style={{
                    height: `${Math.max(4, h * (0.5 + 0.5 * Math.sin(Date.now() / 180 + i * 0.8)))}px`
                  }}
                  className="w-1 bg-gradient-to-t from-rose-500 to-amber-400 rounded-full animate-pulse transition-all duration-100"
                />
              ))}
            </div>

            {/* Voice-to-Text Tone Polish Button */}
            <button
              onClick={() => {
                hapticDoublePulse();
                setTonePolishText(`Voice memo (${recordSeconds}s): Checking in on you and our game challenge!`);
                setShowTonePolishModal(true);
              }}
              className="px-2.5 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-400/40 text-indigo-200 transition active:scale-95 shrink-0 flex items-center gap-1 font-bold text-xs"
              title="Auto-Transcribe & Polish Tone via Gemini AI"
            >
              <Wand2 className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">Polish Tone</span>
            </button>

            {/* Finish & Send Voice Note */}
            <button
              onClick={handleFinishAndSendVoiceNote}
              className="p-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 active:scale-95 text-white transition shadow-md shrink-0 flex items-center gap-1.5 font-bold text-xs"
              title="Send recorded voice note"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Send</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            {/* Hidden File Input for Custom Device Photos */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleCustomFileUpload}
            />

            {/* Tapping Image/Media button in DMs opens full-screen photo editor canvas */}
            <button
              onClick={() => setEditingPhotoUrl('/src/assets/images/gallery_cyber_lounge_1792620681202.jpg')}
              className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/15 text-indigo-400 transition active:scale-90 shrink-0"
              title="Open Full-Screen Photo Editor Canvas (Crop, Blur Brush, Neon Doodle, Text)"
            >
              <ImageIcon className="w-5 h-5" />
            </button>

            {/* Camera / Direct Device Photo Upload to Editor */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/15 text-cyan-400 transition active:scale-90 shrink-0"
              title="Upload Photo to Editor (Blur, Crop, Draw)"
            >
              <Camera className="w-5 h-5" />
            </button>

            {/* Instagram Doodle Trigger */}
            <button
              onClick={onOpenDoodle}
              className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/15 text-pink-400 transition active:scale-90 shrink-0"
              title="Instagram-Style Doodle & Photo Markup"
            >
              <Edit3 className="w-5 h-5" />
            </button>

            {/* Flame View-Once Arming Toggle */}
            <button
              onClick={() => setIsViewOnceArmed(!isViewOnceArmed)}
              className={`p-2.5 rounded-2xl transition active:scale-90 shrink-0 ${
                isViewOnceArmed
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30'
                  : 'bg-white/5 hover:bg-white/15 text-gray-400'
              }`}
              title="Toggle View-Once Self Destructing"
            >
              <Flame className="w-5 h-5" />
            </button>

            {/* Text Input */}
            <input
              type="text"
              placeholder={isCapped ? "Message limit reached" : isViewOnceArmed ? "Send view-once message..." : "Type a message..."}
              value={inputText}
              disabled={isCapped}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              className={`flex-1 px-4 py-3 rounded-2xl ${theme.inputBg} border ${theme.border} text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500`}
            />

            {/* Voice Note Recording Trigger or Send */}
            {inputText.trim() ? (
              <button
                onClick={handleSend}
                className="p-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white transition shadow-md shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleStartRecording}
                className="p-3 rounded-2xl bg-white/10 hover:bg-white/20 transition active:scale-95 text-white shrink-0"
                title="Record Voice Note"
              >
                <Mic className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </footer>

      {/* --- TELEGRAM MEDIA PICKER OVERLAY --- */}
      {showTelegramGallery && (
        <TelegramMediaPicker
          onClose={() => setShowTelegramGallery(false)}
          onSendPhotos={handleSelectFromGallery}
          theme={theme}
        />
      )}

      {/* --- TELEGRAM PHOTO EDITOR WITH BLUR BRUSH --- */}
      {editingPhotoUrl && (
        <PhotoEditorModal
          imageSrc={editingPhotoUrl}
          onSend={handleSendFromEditor}
          onClose={() => setEditingPhotoUrl(null)}
          theme={theme}
        />
      )}

      {/* --- FULL-SCREEN PARTNER PROFILE VIEW --- */}
      {showPartnerProfile && !isRoom && (
        <div className="fixed inset-0 z-50 flex flex-col bg-slate-950 animate-in slide-in-from-right duration-300">
          <FullBleedProfileView
            user={chatData as UserProfile}
            isCurrentUser={false}
            onClose={() => setShowPartnerProfile(false)}
            onOpenDM={() => setShowPartnerProfile(false)}
            theme={theme}
          />
        </div>
      )}

      {/* --- VIEW-ONCE DESTROYER MODAL --- */}
      {activeViewOnceMedia && (
        <ViewOnceViewer
          mediaUrl={activeViewOnceMedia.url}
          senderName={activeViewOnceMedia.sender}
          onBurn={() => {
            onMarkViewOnceOpened(activeViewOnceMedia.msgId);
            setActiveViewOnceMedia(null);
          }}
          theme={theme}
        />
      )}

      {/* --- GOOGLE PIXEL-STYLE FLOATING GLASS CONTEXT MENU --- */}
      {pixelMenu && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => {
            setPixelMenu(null);
            setShowDeleteConfirm(false);
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              position: 'fixed',
              left: `${pixelMenu.x}px`,
              top: `${Math.max(70, Math.min(window.innerHeight - 270, pixelMenu.y))}px`,
              transform: 'translate3d(0, 0, 0)',
              willChange: 'transform, opacity'
            }}
            className="w-64 bg-slate-900/95 backdrop-blur-xl border border-white/20 rounded-3xl p-3 shadow-2xl z-50 animate-in zoom-in-95 duration-200"
          >
            {/* Quick Emoji Reactions Row */}
            <div className="flex items-center justify-between pb-2.5 mb-2 border-b border-white/10 px-1">
              {['❤️', '😂', '🔥', '👍', '😮', '😢'].map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => {
                    hapticDoublePulse();
                    onAddReaction(pixelMenu.msg.id, emoji);
                    setPixelMenu(null);
                  }}
                  className="text-lg p-1 hover:scale-130 active:scale-95 transition-transform duration-150"
                >
                  {emoji}
                </button>
              ))}
            </div>

            {/* Context Actions List */}
            {!showDeleteConfirm ? (
              <div className="space-y-1 text-xs">
                {/* Copy Text */}
                {pixelMenu.msg.text && !pixelMenu.msg.isDoodle && (
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(pixelMenu.msg.text);
                      showToast('Copied to clipboard');
                      setPixelMenu(null);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-2xl hover:bg-white/10 text-gray-200 font-medium transition active:scale-95"
                  >
                    <Copy className="w-4 h-4 text-indigo-400" />
                    <span>Copy Text</span>
                  </button>
                )}

                {/* Translate Message via Gemini API */}
                {pixelMenu.msg.text && !pixelMenu.msg.isDoodle && !pixelMenu.msg.isAudio && (
                  <button
                    onClick={() => handleTranslateSingleMessage(pixelMenu.msg)}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-2xl hover:bg-white/10 text-gray-200 font-medium transition active:scale-95"
                  >
                    <Globe className="w-4 h-4 text-emerald-400" />
                    <span>Translate Message</span>
                  </button>
                )}

                {/* Delete Message Option */}
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-2xl hover:bg-rose-500/20 text-rose-400 font-medium transition active:scale-95"
                >
                  <Trash2 className="w-4 h-4 text-rose-400" />
                  <span>Delete</span>
                </button>
              </div>
            ) : (
              <div className="space-y-1.5 text-xs animate-in fade-in duration-150">
                <div className="px-2 py-1 text-[11px] font-semibold text-gray-400">
                  Select delete scope:
                </div>
                <button
                  onClick={() => {
                    triggerDustDelete(pixelMenu.msg.id, false);
                    setPixelMenu(null);
                    setShowDeleteConfirm(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-2xl hover:bg-white/10 text-gray-300 transition active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5 text-gray-400" />
                  <span>Delete for Me</span>
                </button>
                <button
                  onClick={() => {
                    triggerDustDelete(pixelMenu.msg.id, true);
                    setPixelMenu(null);
                    setShowDeleteConfirm(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-2xl bg-rose-600/30 hover:bg-rose-600/40 text-rose-300 font-bold transition active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                  <span>Delete for Everyone</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- FLOATING TOAST NOTIFICATION --- */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900/90 border border-white/20 text-white text-xs px-4 py-2 rounded-full shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-2 duration-150 flex items-center gap-2 pointer-events-none">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* --- IN-DM AUDIO / VIDEO CALL MODAL (MUTUAL FRIEND PERMISSION GATED) --- */}
      {activeCall && !isRoom && (
        <CallModal
          partner={chatData as UserProfile}
          callType={activeCall.type}
          onEndCall={() => setActiveCall(null)}
          theme={theme}
        />
      )}

      {/* --- VOICE-TO-TEXT TONE POLISH MODAL VIA GEMINI AI --- */}
      {showTonePolishModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-slate-900 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wand2 className="w-5 h-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-white">Gemini Tone Polisher</h3>
              </div>
              <button
                onClick={() => setShowTonePolishModal(false)}
                className="p-1 rounded-full text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-gray-400">
              Transform your voice transcript into your desired tone before sending:
            </p>

            <div className="p-3 rounded-2xl bg-slate-950/60 border border-white/5 text-xs text-gray-200 italic">
              "{tonePolishText}"
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[
                { tone: 'casual', label: 'Casual 😎', desc: 'Chill & friendly' },
                { tone: 'formal', label: 'Formal 👔', desc: 'Polite & professional' },
                { tone: 'poetic', label: 'Poetic ✨', desc: 'Lyrical & expressive' },
                { tone: 'sarcastic', label: 'Sarcastic 😏', desc: 'Witty & playful' }
              ].map((item) => (
                <button
                  key={item.tone}
                  disabled={isPolishing}
                  onClick={async () => {
                    setIsPolishing(true);
                    hapticTap(10);
                    const polished = await polishTranscriptTone(tonePolishText, item.tone as any);
                    setInputText(polished);
                    setIsPolishing(false);
                    setShowTonePolishModal(false);
                    showToast(`Tone polished to ${item.tone}!`);
                  }}
                  className="flex flex-col items-start p-2.5 rounded-2xl bg-white/5 hover:bg-indigo-600/20 border border-white/10 hover:border-indigo-500/50 transition active:scale-95 text-left"
                >
                  <span className="text-xs font-bold text-white">{item.label}</span>
                  <span className="text-[10px] text-gray-400">{item.desc}</span>
                </button>
              ))}
            </div>

            {isPolishing && (
              <div className="flex items-center justify-center gap-2 text-xs text-indigo-400 py-2">
                <div className="w-3.5 h-3.5 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
                <span>Polishing with Gemini AI...</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- PER-DM CHAT BUBBLE ACCENT PICKER MODAL --- */}
      {showAccentPicker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-xs bg-slate-900 border border-white/20 rounded-3xl p-5 shadow-2xl flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-white">Chat Bubble Accent</h3>
              </div>
              <button
                onClick={() => setShowAccentPicker(false)}
                className="p-1 rounded-full text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-gray-400">
              Personalize this chat thread with a custom gradient tint:
            </p>

            <div className="space-y-2 pt-1">
              {CHAT_ACCENTS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    hapticTap(10);
                    setSelectedAccent(item.id);
                    try {
                      localStorage.setItem(`echotalk_accent_${activeChat.data.name}`, item.id);
                    } catch {}
                    setShowAccentPicker(false);
                    showToast(`Accent set to ${item.name}!`);
                  }}
                  className={`w-full flex items-center justify-between p-2.5 rounded-2xl border transition active:scale-98 ${
                    selectedAccent === item.id
                      ? 'border-white bg-white/10'
                      : 'border-white/5 bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className={`w-5 h-5 rounded-full ${item.class} shadow-sm`} />
                    <span className="text-xs font-semibold text-white">{item.name}</span>
                  </div>
                  {selectedAccent === item.id && (
                    <span className="text-xs font-bold text-indigo-400">Active</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
