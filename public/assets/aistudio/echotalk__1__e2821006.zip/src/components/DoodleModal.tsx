import React, { useRef, useState, useEffect } from 'react';
import { X, Send, RotateCcw, Trash2, Sparkles, Paintbrush, Eraser, Image as ImageIcon, Check } from 'lucide-react';
import { ThemeConfig } from '../types';
import { GALLERY_PHOTOS } from '../data/galleryPhotos';

interface DoodleModalProps {
  onClose: () => void;
  onSendDoodle: (dataUrl: string) => void;
  theme: ThemeConfig;
  initialPhotoUrl?: string;
}

const COLORS = [
  '#FFFFFF',
  '#FFE600',
  '#FF2A85',
  '#00E5FF',
  '#76FF03',
  '#FF6D00',
  '#D500F9',
  '#000000'
];

const STROKE_WIDTHS = [
  { label: 'Fine', size: 3 },
  { label: 'Medium', size: 6 },
  { label: 'Bold', size: 12 },
  { label: 'Highlighter', size: 24 }
];

export default function DoodleModal({ onClose, onSendDoodle, theme, initialPhotoUrl }: DoodleModalProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [currentColor, setCurrentColor] = useState<string>('#FFE600');
  const [brushSize, setBrushSize] = useState<number>(6);
  const [isEraser, setIsEraser] = useState<boolean>(false);
  const [neonGlow, setNeonGlow] = useState<boolean>(true);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [history, setHistory] = useState<ImageData[]>([]);
  const [activePhotoUrl, setActivePhotoUrl] = useState<string | null>(initialPhotoUrl || null);
  const [showPhotoPicker, setShowPhotoPicker] = useState<boolean>(false);

  useEffect(() => {
    initCanvas();
  }, [activePhotoUrl]);

  const initCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    if (activePhotoUrl) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        ctx.drawImage(img, 0, 0, rect.width, rect.height);
        saveState();
      };
      img.onerror = () => {
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, rect.width, rect.height);
        saveState();
      };
      img.src = activePhotoUrl;
    } else {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, rect.width, rect.height);
      saveState();
    }
  };

  const saveState = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    try {
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setHistory(prev => [...prev.slice(-15), imgData]);
    } catch {
      // Ignore if cross-origin tainted
    }
  };

  const handleUndo = () => {
    if (history.length <= 1) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const newHistory = history.slice(0, -1);
    const previousState = newHistory[newHistory.length - 1];
    ctx.putImageData(previousState, 0, 0);
    setHistory(newHistory);
  };

  const handleClear = () => {
    initCanvas();
  };

  const startDrawing = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture(e.pointerId);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = brushSize;

    if (isEraser) {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.shadowBlur = 0;
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = currentColor;
      if (neonGlow) {
        ctx.shadowBlur = 14;
        ctx.shadowColor = currentColor;
      } else {
        ctx.shadowBlur = 0;
      }
    }

    setIsDrawing(true);
  };

  const draw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      canvas.releasePointerCapture(e.pointerId);
    } catch {
      // Ignore if already released
    }
    setIsDrawing(false);
    saveState();
  };

  const handleSend = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    onSendDoodle(dataUrl);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-2xl flex flex-col justify-between select-none animate-in fade-in duration-200">
      {/* Top action controls */}
      <div className="h-16 px-4 flex items-center justify-between border-b border-white/10 bg-black/40">
        <button
          onClick={onClose}
          className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition active:scale-95"
          aria-label="Cancel doodle"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          {/* Photo Markup Button */}
          <button
            onClick={() => setShowPhotoPicker(!showPhotoPicker)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition ${
              activePhotoUrl ? 'bg-indigo-600 text-white shadow' : 'bg-white/10 text-white/70 hover:text-white'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>{activePhotoUrl ? 'Photo Active' : 'Markup Photo'}</span>
          </button>

          <button
            onClick={() => setNeonGlow(!neonGlow)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition ${
              neonGlow ? 'bg-amber-400 text-black shadow-lg shadow-amber-400/30' : 'bg-white/10 text-white/70'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Glow</span>
          </button>

          <button
            onClick={handleUndo}
            disabled={history.length <= 1}
            className="w-9 h-9 rounded-full bg-white/10 disabled:opacity-30 hover:bg-white/20 text-white flex items-center justify-center transition active:scale-95"
            title="Undo"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={handleClear}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-rose-500/20 hover:text-rose-400 text-white/80 flex items-center justify-center transition active:scale-95"
            title="Clear all"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={handleSend}
          className={`px-4 py-2 rounded-full ${theme.accent} text-white text-xs font-bold flex items-center gap-1.5 shadow-lg active:scale-95 transition`}
        >
          <span>Send</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Photo Markup Picker Popover */}
      {showPhotoPicker && (
        <div className="p-3 bg-slate-900 border-b border-white/15 flex items-center gap-3 overflow-x-auto z-10 animate-in slide-in-from-top-2">
          <span className="text-xs text-gray-300 shrink-0 font-medium">Select photo to markup:</span>
          <button
            onClick={() => {
              setActivePhotoUrl(null);
              setShowPhotoPicker(false);
            }}
            className="px-3 py-1.5 rounded-xl bg-white/10 text-xs text-white hover:bg-white/20 shrink-0"
          >
            Blank Canvas
          </button>
          {GALLERY_PHOTOS.map((p) => (
            <button
              key={p.id}
              onClick={() => {
                setActivePhotoUrl(p.url);
                setShowPhotoPicker(false);
              }}
              className="flex items-center gap-1.5 p-1 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 shrink-0"
            >
              <img src={p.url} alt={p.title} className="w-7 h-7 rounded-lg object-cover" />
              <span className="text-[11px] text-white pr-1.5">{p.title}</span>
            </button>
          ))}
        </div>
      )}

      {/* Main Canvas Area */}
      <div className="flex-1 w-full max-w-lg mx-auto p-3 flex items-center justify-center">
        <div className="w-full h-full max-h-[580px] rounded-3xl overflow-hidden border border-white/15 shadow-2xl relative bg-slate-900 touch-none">
          <canvas
            ref={canvasRef}
            onPointerDown={startDrawing}
            onPointerMove={draw}
            onPointerUp={stopDrawing}
            onPointerCancel={stopDrawing}
            className="w-full h-full cursor-crosshair"
          />
          <div className="absolute top-3 left-3 pointer-events-none text-[11px] text-white/50 font-medium flex items-center gap-1">
            <Paintbrush className="w-3 h-3 text-pink-400" />
            <span>Instagram Doodle & Photo Markup</span>
          </div>
        </div>
      </div>

      {/* Bottom Tool Palette */}
      <div className="p-4 bg-black/60 border-t border-white/10 space-y-3">
        {/* Stroke width selector */}
        <div className="flex items-center justify-center gap-3">
          {STROKE_WIDTHS.map((item) => (
            <button
              key={item.size}
              onClick={() => {
                setBrushSize(item.size);
                setIsEraser(false);
              }}
              className={`px-3 py-1 rounded-full text-xs transition ${
                brushSize === item.size && !isEraser
                  ? 'bg-white text-black font-bold'
                  : 'text-white/60 hover:text-white bg-white/5'
              }`}
            >
              {item.label}
            </button>
          ))}
          <button
            onClick={() => setIsEraser(!isEraser)}
            className={`px-3 py-1 rounded-full text-xs flex items-center gap-1 transition ${
              isEraser ? 'bg-rose-500 text-white font-bold' : 'text-white/60 hover:text-white bg-white/5'
            }`}
          >
            <Eraser className="w-3.5 h-3.5" />
            <span>Eraser</span>
          </button>
        </div>

        {/* Color Palette */}
        <div className="flex items-center justify-center gap-3 overflow-x-auto py-1">
          {COLORS.map((c) => (
            <button
              key={c}
              onClick={() => {
                setCurrentColor(c);
                setIsEraser(false);
              }}
              style={{ backgroundColor: c }}
              className={`w-8 h-8 rounded-full border-2 transition-transform ${
                currentColor === c && !isEraser
                  ? 'scale-125 border-white shadow-lg ring-2 ring-white/50'
                  : 'border-white/30 hover:scale-110'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
