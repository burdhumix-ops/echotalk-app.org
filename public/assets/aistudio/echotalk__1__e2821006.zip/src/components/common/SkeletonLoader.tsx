import React from 'react';

/**
 * Pulse-animated skeleton loaders for Discover user grid and Chat message bubbles
 * Improves perceived performance during initial state population with zero layout shift.
 */

export function DiscoverSkeletonGrid() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 w-full animate-pulse">
      {Array.from({ length: 6 }).map((_, i) => (
        <div
          key={i}
          className="rounded-3xl bg-slate-900/60 border border-white/5 overflow-hidden flex flex-col p-3 space-y-3"
        >
          {/* Avatar / Photo Skeleton */}
          <div className="w-full aspect-square rounded-2xl bg-white/10 relative overflow-hidden">
            <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/5 to-transparent" />
          </div>

          {/* Details Skeleton */}
          <div className="space-y-2">
            <div className="h-3.5 w-3/4 rounded-full bg-white/15" />
            <div className="flex items-center gap-2">
              <div className="h-2.5 w-1/3 rounded-full bg-white/10" />
              <div className="h-2.5 w-1/4 rounded-full bg-white/10" />
            </div>
            <div className="h-8 w-full rounded-2xl bg-white/10 mt-2" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function ChatSkeletonStream() {
  return (
    <div className="space-y-4 p-4 w-full animate-pulse">
      {/* Received Message Skeleton */}
      <div className="flex flex-col items-start space-y-1">
        <div className="h-2.5 w-20 rounded-full bg-white/10 mb-1" />
        <div className="max-w-[70%] w-52 h-14 rounded-2xl bg-slate-800/60 border border-white/5 p-3 flex flex-col justify-center space-y-2">
          <div className="h-2.5 w-5/6 rounded-full bg-white/15" />
          <div className="h-2.5 w-3/5 rounded-full bg-white/10" />
        </div>
      </div>

      {/* Sent Message Skeleton */}
      <div className="flex flex-col items-end space-y-1">
        <div className="h-2.5 w-16 rounded-full bg-white/10 mb-1" />
        <div className="max-w-[70%] w-64 h-16 rounded-2xl bg-indigo-600/30 border border-indigo-400/20 p-3 flex flex-col justify-center space-y-2">
          <div className="h-2.5 w-4/5 rounded-full bg-white/20" />
          <div className="h-2.5 w-1/2 rounded-full bg-white/15" />
        </div>
      </div>

      {/* Media Bubble Skeleton */}
      <div className="flex flex-col items-start space-y-1">
        <div className="h-2.5 w-24 rounded-full bg-white/10 mb-1" />
        <div className="w-56 h-36 rounded-2xl bg-slate-800/60 border border-white/5 relative overflow-hidden">
          <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/5 to-transparent" />
        </div>
      </div>

      {/* Short Sent Bubble */}
      <div className="flex flex-col items-end space-y-1">
        <div className="w-36 h-11 rounded-2xl bg-indigo-600/30 border border-indigo-400/20 p-2.5 flex items-center">
          <div className="h-2.5 w-4/5 rounded-full bg-white/20" />
        </div>
      </div>
    </div>
  );
}
