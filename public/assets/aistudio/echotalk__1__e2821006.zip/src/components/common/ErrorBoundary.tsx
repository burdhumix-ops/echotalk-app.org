import React, { Component, ErrorInfo, ReactNode } from 'react';
import { RefreshCw, ShieldAlert, Sparkles, AlertTriangle } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
  componentName?: string;
  silentAutoRecover?: boolean;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorCount: number;
  isRecovering: boolean;
  autoRecoverTimer: number | null;
}

export default class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorCount: 0,
    isRecovering: false,
    autoRecoverTimer: null
  };

  private lastErrorTime: number = 0;
  private autoRecoverTimeout: number | null = null;

  public static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    const now = Date.now();
    const timeSinceLast = now - this.lastErrorTime;
    this.lastErrorTime = now;

    console.warn(`[Self-Healing ErrorBoundary] Caught error in <${this.props.componentName || 'Component'}>:`, error, errorInfo);

    this.setState((prev) => {
      const nextCount = timeSinceLast < 2500 ? prev.errorCount + 1 : 1;
      return { errorCount: nextCount };
    });

    // Autonomous Self-Healing:
    // If silentAutoRecover is enabled and we haven't crashed in a rapid loop (> 2 times in 2.5s),
    // automatically reset state and re-render silently in the background!
    const shouldSilentRecover = this.props.silentAutoRecover !== false;

    if (shouldSilentRecover && this.state.errorCount < 2) {
      this.autoRecoverTimeout = window.setTimeout(() => {
        this.handleAutoRecover();
      }, 80);
    }
  }

  public componentWillUnmount() {
    if (this.autoRecoverTimeout) {
      window.clearTimeout(this.autoRecoverTimeout);
    }
    if (this.state.autoRecoverTimer) {
      window.clearInterval(this.state.autoRecoverTimer);
    }
  }

  private handleAutoRecover = () => {
    if (this.props.onReset) {
      try {
        this.props.onReset();
      } catch (e) {
        console.warn('[Self-Healing] onReset handler error:', e);
      }
    }

    this.setState({
      hasError: false,
      error: null,
      isRecovering: false
    });
  };

  private handleManualReset = () => {
    this.setState({ isRecovering: true });
    setTimeout(() => {
      this.handleAutoRecover();
    }, 150);
  };

  public render() {
    if (this.state.hasError) {
      // If we are quietly recovering, render null or child skeleton briefly
      if (this.state.isRecovering) {
        return (
          <div className="w-full h-32 flex items-center justify-center p-4">
            <div className="flex items-center gap-2 text-xs font-mono text-indigo-400 animate-pulse">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>Self-healing state...</span>
            </div>
          </div>
        );
      }

      // If persistent loop occurred, show an elegant frosted-glass auto-recovery card
      return (
        <div className="w-full p-4 my-2 rounded-3xl bg-slate-900/80 border border-white/10 backdrop-blur-xl text-center space-y-3 shadow-2xl animate-in fade-in duration-150">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 mx-auto flex items-center justify-center border border-amber-500/30">
            <ShieldAlert className="w-5 h-5" />
          </div>

          <div>
            <h4 className="text-xs font-bold text-white tracking-tight">
              {this.props.fallbackTitle || 'Component Auto-Recovery'}
            </h4>
            <p className="text-[11px] text-gray-400 mt-1 max-w-xs mx-auto">
              Recovered from an unexpected state anomaly. Tap to restore component view.
            </p>
          </div>

          <div className="pt-1 flex items-center justify-center gap-2">
            <button
              onClick={this.handleManualReset}
              className="px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-900/40 transition"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Self-Heal & Restore</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
