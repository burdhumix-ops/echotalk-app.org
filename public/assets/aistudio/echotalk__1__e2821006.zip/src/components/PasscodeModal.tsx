import React, { useState } from 'react';
import { X, ShieldAlert, KeyRound, Sparkles, Crown, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { ThemeConfig } from '../types';

interface PasscodeModalProps {
  onClose: () => void;
  adminPin: string;
  ownerPin: string;
  onSuccess: (role: 'owner' | 'admin') => void;
  theme: ThemeConfig;
}

export default function PasscodeModal({
  onClose,
  adminPin,
  ownerPin,
  onSuccess,
  theme
}: PasscodeModalProps) {
  const [pin, setPin] = useState<string>('');
  const [errorShake, setErrorShake] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [grantedRole, setGrantedRole] = useState<'owner' | 'admin' | null>(null);

  const handleDigit = (digit: string) => {
    if (grantedRole) return;
    if (pin.length < 4) {
      const newPin = pin + digit;
      setPin(newPin);
      if (newPin.length === 4) {
        verifyPin(newPin);
      }
    }
  };

  const handleDelete = () => {
    if (grantedRole) return;
    setPin(prev => prev.slice(0, -1));
    setErrorMessage('');
  };

  const verifyPin = (candidate: string) => {
    if (candidate === ownerPin) {
      setGrantedRole('owner');
      setTimeout(() => {
        onSuccess('owner');
        onClose();
      }, 1000);
    } else if (candidate === adminPin) {
      setGrantedRole('admin');
      setTimeout(() => {
        onSuccess('admin');
        onClose();
      }, 1000);
    } else {
      setErrorShake(true);
      setErrorMessage('Invalid 4-digit passcode');
      setTimeout(() => {
        setPin('');
        setErrorShake(false);
      }, 700);
    }
  };

  return (
    <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-2xl flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div
        className={`w-full max-w-xs rounded-3xl border ${theme.cardBorder} ${theme.card} p-6 shadow-2xl flex flex-col items-center relative text-center ${
          errorShake ? 'animate-bounce' : ''
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Icon */}
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-indigo-500/30 border border-white/10 flex items-center justify-center mb-3 text-amber-300 shadow-lg">
          {grantedRole === 'owner' ? (
            <Crown className="w-7 h-7 text-amber-400 animate-bounce" />
          ) : grantedRole === 'admin' ? (
            <ShieldCheck className="w-7 h-7 text-indigo-400 animate-bounce" />
          ) : (
            <KeyRound className="w-7 h-7 text-indigo-400" />
          )}
        </div>

        <h3 className="text-base font-black text-white tracking-tight">
          {grantedRole ? 'Authentication Granted' : 'Secret Access Terminal'}
        </h3>
        <p className="text-[11px] text-gray-400 mt-1 mb-4">
          {grantedRole
            ? `Granted full ${grantedRole.toUpperCase()} privileges.`
            : 'Enter 4-digit role passcode for backdoor elevated access'}
        </p>

        {/* 4 PIN Dots */}
        <div className="flex items-center justify-center gap-4 mb-4">
          {[0, 1, 2, 3].map((index) => {
            const isFilled = pin.length > index;
            return (
              <div
                key={index}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  grantedRole
                    ? 'bg-emerald-400 scale-110 shadow-lg shadow-emerald-500/50'
                    : isFilled
                    ? 'bg-white scale-110 shadow-md shadow-white/40'
                    : 'bg-white/20 border border-white/10'
                }`}
              />
            );
          })}
        </div>

        {errorMessage && (
          <span className="text-[11px] text-rose-400 font-medium mb-3">
            {errorMessage}
          </span>
        )}

        {grantedRole && (
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold mb-3">
            <CheckCircle2 className="w-4 h-4" />
            <span>Switching role to {grantedRole}...</span>
          </div>
        )}

        {/* iOS-Style Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 w-full max-w-[220px]">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              onClick={() => handleDigit(digit)}
              className="w-14 h-14 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 text-white font-bold text-lg flex items-center justify-center transition active:scale-95 border border-white/5 shadow"
            >
              {digit}
            </button>
          ))}
          <div />
          <button
            onClick={() => handleDigit('0')}
            className="w-14 h-14 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 text-white font-bold text-lg flex items-center justify-center transition active:scale-95 border border-white/5 shadow"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="w-14 h-14 rounded-full bg-white/5 hover:bg-white/15 active:bg-white/20 text-gray-400 hover:text-white font-semibold text-xs flex items-center justify-center transition active:scale-95"
          >
            Delete
          </button>
        </div>

        <div className="mt-4 pt-3 border-t border-white/10 w-full flex items-center justify-between text-[10px] text-gray-500 font-mono">
          <span>Hint: Admin (2024)</span>
          <span>Owner (9999)</span>
        </div>
      </div>
    </div>
  );
}
