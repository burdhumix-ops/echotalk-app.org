import React, { useState } from 'react';
import { X, Flame, Check, Upload, Image as ImageIcon, Sparkles, Eye, ShieldAlert } from 'lucide-react';
import { GalleryPhoto, ThemeConfig } from '../types';
import { GALLERY_PHOTOS } from '../data/galleryPhotos';

interface TelegramMediaPickerProps {
  onClose: () => void;
  onSendPhotos: (photos: { url: string; isViewOnce: boolean }[]) => void;
  theme: ThemeConfig;
  initialViewOnce?: boolean;
}

export default function TelegramMediaPicker({
  onClose,
  onSendPhotos,
  theme,
  initialViewOnce = false
}: TelegramMediaPickerProps) {
  const [selectedPhotoIds, setSelectedPhotoIds] = useState<string[]>([]);
  const [isViewOnce, setIsViewOnce] = useState<boolean>(initialViewOnce);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [customPhotos, setCustomPhotos] = useState<GalleryPhoto[]>([]);

  const allPhotos = [...customPhotos, ...GALLERY_PHOTOS];

  const categories = ['All', 'Landscapes', 'Night City', 'Lounge'];

  const filteredPhotos = activeCategory === 'All'
    ? allPhotos
    : allPhotos.filter(p => p.category === activeCategory);

  const toggleSelectPhoto = (id: string) => {
    setSelectedPhotoIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleCustomFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const newPhoto: GalleryPhoto = {
        id: `upload-${Date.now()}`,
        url: dataUrl,
        title: file.name,
        category: 'Custom'
      };
      setCustomPhotos(prev => [newPhoto, ...prev]);
      setSelectedPhotoIds(prev => [...prev, newPhoto.id]);
    };
    reader.readAsDataURL(file);
  };

  const handleSend = () => {
    if (selectedPhotoIds.length === 0) return;
    const selected = allPhotos
      .filter(p => selectedPhotoIds.includes(p.id))
      .map(p => ({ url: p.url, isViewOnce }));
    onSendPhotos(selected);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-2xl flex items-end sm:items-center justify-center p-0 sm:p-4 select-none animate-in fade-in duration-200">
      <div className={`w-full max-w-lg rounded-t-3xl sm:rounded-3xl border ${theme.cardBorder} bg-slate-950/95 frosted-glass p-4 sm:p-5 flex flex-col max-h-[90vh] shadow-2xl`}>
        
        {/* Telegram Sheet Grab Handle */}
        <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-3 sm:hidden" />

        {/* Top Control Bar */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-gray-300 transition"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-indigo-400" />
                <span>Gallery & Media</span>
              </h3>
              <span className="text-[10px] text-gray-400">
                {selectedPhotoIds.length > 0 ? `${selectedPhotoIds.length} photo(s) selected` : 'Select photos to send'}
              </span>
            </div>
          </div>

          {/* Flame Toggle for View-Once */}
          <button
            onClick={() => setIsViewOnce(!isViewOnce)}
            className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all ${
              isViewOnce
                ? 'bg-gradient-to-r from-amber-500 to-red-500 text-slate-950 shadow-lg shadow-amber-500/30 ring-2 ring-amber-400/50 scale-105'
                : 'bg-white/10 text-gray-300 hover:bg-white/20'
            }`}
            title="Toggle View-Once self-destruct mode"
          >
            <Flame className={`w-4 h-4 ${isViewOnce ? 'text-slate-950 fill-slate-950 animate-bounce' : 'text-amber-400'}`} />
            <span>View-Once {isViewOnce ? 'ON' : 'OFF'}</span>
          </button>
        </div>

        {/* View-Once Notice Banner */}
        {isViewOnce && (
          <div className="mt-2.5 p-2 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center gap-2 text-[11px] text-amber-200">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>
              <strong>View-Once Active:</strong> Recipient sees a blurred bubble that expires 5s after viewing.
            </span>
          </div>
        )}

        {/* Category Pills & Upload Button */}
        <div className="flex items-center gap-1.5 py-3 overflow-x-auto text-xs">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition ${
                activeCategory === cat
                  ? `${theme.accent} text-white shadow-md`
                  : 'bg-white/5 text-gray-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}

          <label className="px-3 py-1.5 rounded-xl font-medium whitespace-nowrap bg-white/10 hover:bg-white/20 text-white cursor-pointer flex items-center gap-1.5 transition ml-auto shrink-0">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Device</span>
            <input
              type="file"
              accept="image/*"
              onChange={handleCustomFileUpload}
              className="hidden"
            />
          </label>
        </div>

        {/* Photos Grid (Telegram Style) */}
        <div className="flex-1 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 gap-2.5 py-1 pr-0.5">
          {filteredPhotos.map((photo) => {
            const isSelected = selectedPhotoIds.includes(photo.id);
            const selectIndex = selectedPhotoIds.indexOf(photo.id) + 1;

            return (
              <div
                key={photo.id}
                onClick={() => toggleSelectPhoto(photo.id)}
                className={`group relative aspect-square rounded-2xl overflow-hidden cursor-pointer border-2 transition-all ${
                  isSelected
                    ? 'border-indigo-400 ring-2 ring-indigo-500/50 shadow-lg scale-[0.98]'
                    : 'border-white/10 hover:border-white/30'
                }`}
              >
                <img
                  src={photo.url}
                  alt={photo.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />

                {/* Scrim Overlay */}
                <div className={`absolute inset-0 transition-opacity ${
                  isSelected ? 'bg-indigo-950/30' : 'bg-black/10 group-hover:bg-black/0'
                }`} />

                {/* Telegram Circular Numbered Badge Checkmark */}
                <div className={`absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs transition-transform ${
                  isSelected
                    ? 'bg-indigo-500 text-white shadow-md scale-110'
                    : 'bg-black/50 border border-white/60 text-transparent hover:border-white'
                }`}>
                  {isSelected ? selectIndex : ''}
                </div>

                {/* Title badge at bottom */}
                <div className="absolute bottom-1.5 left-2 right-2 text-[10px] text-white/90 font-medium truncate drop-shadow">
                  {photo.title}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Action Footer */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3">
          <span className="text-xs text-gray-400">
            {selectedPhotoIds.length} photo{selectedPhotoIds.length !== 1 ? 's' : ''} chosen
          </span>

          <button
            onClick={handleSend}
            disabled={selectedPhotoIds.length === 0}
            className={`px-5 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-2 shadow-xl active:scale-95 transition disabled:opacity-40 disabled:cursor-not-allowed ${
              isViewOnce
                ? 'bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 font-black'
                : `${theme.accent} text-white`
            }`}
          >
            {isViewOnce ? <Flame className="w-4 h-4 fill-slate-950" /> : <Check className="w-4 h-4" />}
            <span>
              Send {selectedPhotoIds.length > 0 ? selectedPhotoIds.length : ''} {isViewOnce ? 'View-Once' : 'Media'}
            </span>
          </button>
        </div>

      </div>
    </div>
  );
}
