import { GalleryPhoto } from '../types';

export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'aurora-1',
    url: '/src/assets/images/view_once_aurora_1792618101621.jpg',
    title: 'Northern Lights Aurora',
    category: 'Landscapes'
  },
  {
    id: 'tokyo-1',
    url: '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg',
    title: 'Neon Tokyo Rain',
    category: 'Night City'
  },
  {
    id: 'desert-1',
    url: '/src/assets/images/gallery_desert_oasis_1792620681182.jpg',
    title: 'Golden Sand Oasis',
    category: 'Landscapes'
  },
  {
    id: 'lounge-1',
    url: '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
    title: 'Frosted Cyber Lounge',
    category: 'Lounge'
  },
  {
    id: 'chess-1',
    url: '/src/assets/images/game_chess_icon_1792618103123.jpg',
    title: 'Chess Grandmaster Arena',
    category: 'Arcade'
  },
  {
    id: 'ludo-1',
    url: '/src/assets/images/game_ludo_icon_1792618102891.jpg',
    title: 'Ludo Classic Board',
    category: 'Arcade'
  },
  {
    id: 'mafia-1',
    url: '/src/assets/images/game_mafia_icon_1792618103161.jpg',
    title: 'Mafia Roundtable Night',
    category: 'Arcade'
  }
];

export const PRESET_AVATARS = [
  {
    id: 'avatar-zavier',
    name: 'Tech Founder',
    url: '/src/assets/images/avatar_zavier_founder_1792623177719.jpg'
  },
  {
    id: 'avatar-chloe',
    name: 'Art Director',
    url: '/src/assets/images/avatar_chloe_dubois_1792623177921.jpg'
  },
  {
    id: 'avatar-lucas',
    name: 'Photographer',
    url: '/src/assets/images/avatar_lucas_silva_1792623191727.jpg'
  },
  {
    id: 'avatar-aurora',
    name: 'Aurora Neon',
    url: '/src/assets/images/view_once_aurora_1792618101621.jpg'
  },
  {
    id: 'avatar-cyber',
    name: 'Cyber Lounge',
    url: '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg'
  },
  {
    id: 'avatar-tokyo',
    name: 'Tokyo Rain',
    url: '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg'
  }
];

export const DEFAULT_PORTFOLIO_IMAGES = [
  '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
  '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg',
  '/src/assets/images/gallery_desert_oasis_1792620681182.jpg',
  '/src/assets/images/view_once_aurora_1792618101621.jpg',
  '/src/assets/images/game_chess_icon_1792618103123.jpg',
  '/src/assets/images/game_ludo_icon_1792618102891.jpg',
  '/src/assets/images/game_mafia_icon_1792618103161.jpg',
  '/src/assets/images/avatar_zavier_founder_1792623177719.jpg',
  '/src/assets/images/avatar_chloe_dubois_1792623177921.jpg',
  '/src/assets/images/avatar_lucas_silva_1792623191727.jpg'
];
