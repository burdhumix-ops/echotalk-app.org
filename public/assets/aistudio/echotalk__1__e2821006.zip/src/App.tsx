import React, { useState, useEffect } from 'react';
import { ActiveChatTarget, AdminVaultEntry, BlockedUser, ChatMessage, ChatRoom, GameChallengeData, OwnerConfig, ThemeKey, UserProfile } from './types';
import { THEMES } from './themes';
import TopBar from './components/TopBar';
import BottomNav from './components/BottomNav';
import FullChatScreen from './components/FullChatScreen';
import DoodleModal from './components/DoodleModal';
import AdminVaultModal from './components/AdminVaultModal';
import SettingsModal from './components/SettingsModal';
import SplashScreen from './components/SplashScreen';
import PasscodeModal from './components/PasscodeModal';
import OneOnOneMatchModal from './components/games/OneOnOneMatchModal';
import LoungeTab from './components/tabs/LoungeTab';
import DiscoverTab from './components/tabs/DiscoverTab';
import DMsTab from './components/tabs/DMsTab';
import GamesTab from './components/tabs/GamesTab';
import ProfileTab from './components/tabs/ProfileTab';
import FullBleedProfileView from './components/profile/FullBleedProfileView';
import ErrorBoundary from './components/common/ErrorBoundary';
import { autoRepairState } from './utils/stateAutoRepair';
import { initTouchRipple } from './utils/ripple';

const INITIAL_USERS: UserProfile[] = [
  {
    id: 1,
    name: 'Lucas Silva',
    handle: '@lucas_rio',
    country: 'Brazil',
    countryCode: 'BR',
    gender: 'Male',
    age: 26,
    online: true,
    isFriend: true,
    reqCount: 0,
    bio: 'Photographer & Chess enthusiast from Rio de Janeiro.',
    avatarSeed: 'Lucas',
    avatarBg: 'bg-emerald-600',
    avatarUrl: '/src/assets/images/avatar_lucas_silva_1792623191727.jpg',
    role: 'member',
    portfolio: [
      '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg',
      '/src/assets/images/gallery_desert_oasis_1792620681182.jpg',
      '/src/assets/images/view_once_aurora_1792618101621.jpg',
      '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
      '/src/assets/images/game_chess_icon_1792618103123.jpg',
      '/src/assets/images/avatar_lucas_silva_1792623191727.jpg'
    ]
  },
  {
    id: 2,
    name: 'Chloe Dubois',
    handle: '@chloedubois',
    country: 'France',
    countryCode: 'FR',
    gender: 'Female',
    age: 24,
    online: true,
    isFriend: true,
    reqCount: 0,
    bio: 'Art director living in Paris. Loves lo-fi vibes & Mafia.',
    avatarSeed: 'Chloe',
    avatarBg: 'bg-indigo-600',
    avatarUrl: '/src/assets/images/avatar_chloe_dubois_1792623177921.jpg',
    role: 'member',
    portfolio: [
      '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
      '/src/assets/images/avatar_chloe_dubois_1792623177921.jpg',
      '/src/assets/images/view_once_aurora_1792618101621.jpg',
      '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg',
      '/src/assets/images/game_mafia_icon_1792618103161.jpg'
    ]
  },
  {
    id: 3,
    name: 'Liam O’Connor',
    handle: '@liam_dublin',
    country: 'Ireland',
    countryCode: 'IE',
    gender: 'Male',
    age: 29,
    online: false,
    isFriend: true,
    reqCount: 0,
    bio: 'Sound designer & indie developer.',
    avatarSeed: 'Liam',
    avatarBg: 'bg-teal-600',
    avatarUrl: '/src/assets/images/gallery_desert_oasis_1792620681182.jpg',
    role: 'member',
    portfolio: [
      '/src/assets/images/gallery_desert_oasis_1792620681182.jpg',
      '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
      '/src/assets/images/game_ludo_icon_1792618102891.jpg'
    ]
  },
  {
    id: 4,
    name: 'Kenji Sato',
    handle: '@kenji_tokyo',
    country: 'Japan',
    countryCode: 'JP',
    gender: 'Male',
    age: 23,
    online: true,
    isFriend: false, // Pending message request!
    reqCount: 2, // 2 out of 3 messages used
    bio: 'Tokyo street photographer. Capturing aurora & city lights.',
    avatarSeed: 'Kenji',
    avatarBg: 'bg-purple-600',
    avatarUrl: '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg',
    role: 'member',
    portfolio: [
      '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg',
      '/src/assets/images/view_once_aurora_1792618101621.jpg',
      '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
      '/src/assets/images/game_chess_icon_1792618103123.jpg'
    ]
  },
  {
    id: 5,
    name: 'Elena Rostova',
    handle: '@elena_tallinn',
    country: 'Estonia',
    countryCode: 'EE',
    gender: 'Female',
    age: 27,
    online: true,
    isFriend: false, // Pending message request!
    reqCount: 1,
    bio: 'Cybersecurity researcher & digital artist.',
    avatarSeed: 'Elena',
    avatarBg: 'bg-rose-600',
    avatarUrl: '/src/assets/images/view_once_aurora_1792618101621.jpg',
    role: 'member',
    portfolio: [
      '/src/assets/images/view_once_aurora_1792618101621.jpg',
      '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
      '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg'
    ]
  },
  {
    id: 6,
    name: 'Maya Lin',
    handle: '@maya_sg',
    country: 'Singapore',
    countryCode: 'SG',
    gender: 'Non-binary',
    age: 31,
    online: true,
    isFriend: false,
    reqCount: 0,
    bio: 'Spatial UI architect and generative sound designer.',
    avatarSeed: 'Maya',
    avatarBg: 'bg-cyan-600',
    avatarUrl: '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
    role: 'member',
    portfolio: [
      '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
      '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg'
    ]
  },
  {
    id: 7,
    name: 'David Thorne',
    handle: '@david_sf',
    country: 'United States',
    countryCode: 'US',
    gender: 'Male',
    age: 38,
    online: false,
    isFriend: false,
    reqCount: 0,
    bio: 'Vintage synth collector & Grandmaster chess mentor.',
    avatarSeed: 'David',
    avatarBg: 'bg-slate-700',
    avatarUrl: '/src/assets/images/avatar_zavier_founder_1792623177719.jpg',
    role: 'member',
    portfolio: [
      '/src/assets/images/game_chess_icon_1792618103123.jpg',
      '/src/assets/images/gallery_desert_oasis_1792620681182.jpg'
    ]
  }
];

const INITIAL_ROOMS: ChatRoom[] = [
  {
    id: 1,
    name: 'Global Voice & Lo-Fi Lounge',
    topic: 'Worldwide live audio community lounge & lo-fi chillout session',
    isSpecial: true,
    locked: false,
    memberCount: 54,
    hostName: 'Chloe Dubois',
    messages: [
      {
        id: 1,
        sender: 'Chloe Dubois',
        text: 'Welcome to the global voice lounge everyone! Testing high-fidelity spatial audio.',
        timestamp: '1:45 PM'
      },
      {
        id: 2,
        sender: 'Lucas Silva',
        text: 'Audio sounds super crisp on the new iOS lounge card!',
        timestamp: '1:50 PM'
      }
    ]
  }
];

const INITIAL_DMS: Record<number, ChatMessage[]> = {
  1: [
    {
      id: 101,
      sender: 'Lucas Silva',
      text: 'Hey Zavier! Ready for our Chess rematch tonight?',
      timestamp: '1:10 PM',
      status: 'seen',
      seenAt: '1:12 PM'
    },
    {
      id: 102,
      sender: 'Zavier',
      text: 'Always ready. I set up the Grandmaster engine for you to test.',
      timestamp: '1:15 PM',
      status: 'seen',
      seenAt: '1:16 PM'
    },
    {
      id: 103,
      sender: 'Lucas Silva',
      text: '⚔️ Sent a 1v1 challenge for Chess Classic (1v1 Duel)!',
      timestamp: '1:20 PM',
      isChallenge: true,
      challengeData: {
        game: 'chess',
        status: 'pending',
        challenger: 'Lucas Silva',
        opponent: 'Zavier',
        matchId: 'match-101'
      }
    },
    {
      id: 104,
      sender: 'Lucas Silva',
      text: 'Voice Note (0:05)',
      timestamp: '1:24 PM',
      isAudio: true,
      audioDuration: '0:05',
      status: 'seen',
      seenAt: '1:25 PM'
    }
  ],
  2: [
    {
      id: 201,
      sender: 'Chloe Dubois',
      text: 'Hey Zavier! I loved the new frosted glass look on EchoTalk!',
      timestamp: '1:30 PM',
      status: 'seen',
      seenAt: '1:31 PM'
    },
    {
      id: 202,
      sender: 'Zavier',
      text: 'Thanks Chloe! We also just added Telegram-style media selection and 1v1 In-DM games.',
      timestamp: '1:32 PM',
      status: 'seen',
      seenAt: '1:33 PM'
    },
    {
      id: 203,
      sender: 'Chloe Dubois',
      text: 'Voice Note (0:06)',
      timestamp: '1:35 PM',
      isAudio: true,
      audioDuration: '0:06',
      status: 'seen',
      seenAt: '1:36 PM'
    }
  ],
  4: [
    {
      id: 401,
      sender: 'Kenji Sato',
      text: 'Hey Zavier, check out this secret photo I captured of the northern lights aurora!',
      timestamp: '2:14 PM',
      isViewOnce: false,
      status: 'seen'
    },
    {
      id: 402,
      sender: 'Kenji Sato',
      text: '/src/assets/images/view_once_aurora_1792618101621.jpg',
      mediaUrl: '/src/assets/images/view_once_aurora_1792618101621.jpg',
      isViewOnce: true,
      viewed: false,
      timestamp: '2:15 PM',
      status: 'seen'
    }
  ],
  5: [
    {
      id: 501,
      sender: 'Elena Rostova',
      text: 'Hi Zavier! Sending a message request to collaborate on the security protocol.',
      timestamp: '11:10 AM',
      isViewOnce: false,
      status: 'seen'
    }
  ]
};

const INITIAL_VAULT: AdminVaultEntry[] = [
  {
    id: 1,
    timestamp: '2:15 PM',
    sender: 'Kenji Sato',
    target: 'Zavier',
    mediaUrl: '/src/assets/images/view_once_aurora_1792618101621.jpg',
    mediaType: 'image',
    previewText: 'Northern lights aurora landscape photo (View-Once intercepted)',
    interceptionStatus: 'Stored & Decrypted'
  }
];

const INITIAL_BLOCKED: BlockedUser[] = [
  {
    id: 99,
    name: 'Spam Bot 3000',
    handle: '@spambot_3000',
    blockedAt: 'Yesterday'
  }
];

export default function App() {
  // Global App States
  const [currentUser, setCurrentUser] = useState<{
    name: string;
    handle?: string;
    role: 'owner' | 'admin' | 'member';
    isHidden: boolean;
    bio: string;
    avatarColor?: string;
    avatarUrl?: string;
    portfolio?: string[];
  }>({
    name: 'Zavier',
    handle: '@zavier',
    role: 'owner',
    isHidden: false,
    bio: 'EchoTalk Founder & Digital Architect',
    avatarColor: 'bg-indigo-600',
    avatarUrl: '/src/assets/images/avatar_zavier_founder_1792623177719.jpg',
    portfolio: [
      '/src/assets/images/avatar_zavier_founder_1792623177719.jpg',
      '/src/assets/images/gallery_cyber_lounge_1792620681202.jpg',
      '/src/assets/images/gallery_neon_tokyo_1792620680799.jpg',
      '/src/assets/images/gallery_desert_oasis_1792620681182.jpg',
      '/src/assets/images/view_once_aurora_1792618101621.jpg',
      '/src/assets/images/game_chess_icon_1792618103123.jpg',
      '/src/assets/images/game_ludo_icon_1792618102891.jpg',
      '/src/assets/images/game_mafia_icon_1792618103161.jpg',
      '/src/assets/images/avatar_chloe_dubois_1792623177921.jpg',
      '/src/assets/images/avatar_lucas_silva_1792623191727.jpg'
    ]
  });

  const [activeTab, setActiveTab] = useState<string>('Discover'); // Discover, Lounge, DMs, Arcade, Profile
  const [activeTheme, setActiveTheme] = useState<ThemeKey>('ios-glass');
  const [selectedUserProfile, setSelectedUserProfile] = useState<UserProfile | null>(null);
  const [activeChat, setActiveChat] = useState<ActiveChatTarget | null>(null);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showDoodle, setShowDoodle] = useState<boolean>(false);
  const [showAdminVault, setShowAdminVault] = useState<boolean>(false);
  const [isPhoneFrame, setIsPhoneFrame] = useState<boolean>(false);
  const [activeChallengeMatch, setActiveChallengeMatch] = useState<GameChallengeData | null>(null);

  // Auth & Backdoor States
  const [isLoggedOut, setIsLoggedOut] = useState<boolean>(false);
  const [showPasscodeModal, setShowPasscodeModal] = useState<boolean>(false);

  // Dynamic Owner Customization & PIN Configuration
  const [ownerConfig, setOwnerConfig] = useState<OwnerConfig>({
    adminPin: '2024',
    ownerPin: '9999',
    tabLabels: {
      Discover: 'Discover',
      Lounge: 'Lounge',
      Rooms: 'Lounge',
      DMs: 'DMs',
      Arcade: 'Arcade',
      Games: 'Arcade',
      Profile: 'Profile'
    },
    enableArcade: true,
    enableViewOnceVault: true,
    enableGhostMode: true,
    allowDirectDMsWithoutRequest: false
  });

  // Data States
  const [users, setUsers] = useState<UserProfile[]>(INITIAL_USERS);
  const [rooms, setRooms] = useState<ChatRoom[]>(INITIAL_ROOMS);
  const [dms, setDms] = useState<Record<number, ChatMessage[]>>(INITIAL_DMS);
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>(INITIAL_BLOCKED);
  const [adminViewOnceVault, setAdminViewOnceVault] = useState<AdminVaultEntry[]>(INITIAL_VAULT);

  const theme = THEMES[activeTheme];

  const getFormattedTime = () => {
    const d = new Date();
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Autonomous State Integrity Auto-Repair & Touch Ripple on app load
  useEffect(() => {
    autoRepairState();
    initTouchRipple();
  }, []);

  // Open a DM and mark unread messages as seen
  const handleOpenDM = (user: UserProfile) => {
    setActiveChat({ type: 'dm', data: user });

    // Mark any incoming unread messages as seen
    setDms((prev) => {
      const thread = prev[user.id];
      if (!thread) return prev;
      const updated = thread.map((m) =>
        m.sender !== currentUser.name ? { ...m, status: 'seen' as const } : m
      );
      return { ...prev, [user.id]: updated };
    });
  };

  // Handler: Send Message
  const handleSendMessage = (
    text: string,
    isViewOnce = false,
    isDoodle = false,
    mediaUrl?: string,
    isAudio = false,
    challengeData?: GameChallengeData,
    audioDuration?: string,
    audioWaveform?: number[]
  ) => {
    if (!activeChat) return;

    const timeStr = getFormattedTime();
    const newMsgId = Date.now();

    if (activeChat.type === 'room') {
      const roomId = activeChat.data.id;
      const newMsg: ChatMessage = {
        id: newMsgId,
        sender: currentUser.name,
        text,
        timestamp: timeStr,
        isViewOnce,
        isDoodle,
        mediaUrl: mediaUrl || (isViewOnce ? text : undefined),
        isAudio,
        audioDuration: audioDuration || (isAudio ? '0:05' : undefined),
        audioWaveform
      };

      setRooms((prev) =>
        prev.map((r) => {
          if (r.id === roomId && !r.locked) {
            return { ...r, messages: [...r.messages, newMsg] };
          }
          return r;
        })
      );
    } else if (activeChat.type === 'dm') {
      const recipientId = activeChat.data.id;
      const recipientUser = users.find((u) => u.id === recipientId);

      // Increment request count if not friends
      if (recipientUser && !recipientUser.isFriend) {
        if (recipientUser.reqCount >= 3) {
          return;
        }
        setUsers((prev) =>
          prev.map((u) => (u.id === recipientId ? { ...u, reqCount: u.reqCount + 1 } : u))
        );
      }

      // Initial state is 'sent'
      const newMsg: ChatMessage = {
        id: newMsgId,
        sender: currentUser.name,
        text,
        timestamp: timeStr,
        status: 'sent',
        isViewOnce,
        viewed: false,
        isDoodle,
        mediaUrl: mediaUrl || (isViewOnce ? text : undefined),
        isAudio,
        audioDuration: audioDuration || (isAudio ? '0:05' : undefined),
        audioWaveform,
        isChallenge: Boolean(challengeData),
        challengeData
      };

      setDms((prev) => ({
        ...prev,
        [recipientId]: [...(prev[recipientId] || []), newMsg]
      }));

      // Simulate network delivery after 600ms
      setTimeout(() => {
        setDms((prev) => {
          const thread = prev[recipientId] || [];
          return {
            ...prev,
            [recipientId]: thread.map((m) =>
              m.id === newMsgId && m.status === 'sent' ? { ...m, status: 'delivered' } : m
            )
          };
        });
      }, 600);

      // Simulate recipient reading message after 1600ms
      setTimeout(() => {
        setDms((prev) => {
          const thread = prev[recipientId] || [];
          return {
            ...prev,
            [recipientId]: thread.map((m) =>
              m.id === newMsgId ? { ...m, status: 'seen', seenAt: getFormattedTime() } : m
            )
          };
        });
      }, 1600);

      // Background Admin Logger for View-Once Media
      if (isViewOnce) {
        const vaultLog: AdminVaultEntry = {
          id: Date.now(),
          timestamp: timeStr,
          sender: currentUser.name,
          target: activeChat.data.name,
          mediaUrl: mediaUrl || text,
          mediaType: isDoodle ? 'doodle' : 'image',
          previewText: isDoodle ? 'Instagram Doodle Canvas (View-Once)' : 'Encrypted View-Once Photo Payload',
          interceptionStatus: 'Stored & Decrypted'
        };
        setAdminViewOnceVault((prev) => [vaultLog, ...prev]);
      }
    }
  };

  // Handler: Add Reaction
  const handleAddReaction = (msgId: number, emoji: string) => {
    if (!activeChat) return;

    if (activeChat.type === 'room') {
      setRooms((prev) =>
        prev.map((r) => {
          if (r.id === activeChat.data.id) {
            const updatedMsgs = r.messages.map((m) => {
              if (m.id === msgId) {
                const currentCount = m.reactions?.[emoji] || 0;
                return {
                  ...m,
                  reactions: { ...(m.reactions || {}), [emoji]: currentCount + 1 }
                };
              }
              return m;
            });
            return { ...r, messages: updatedMsgs };
          }
          return r;
        })
      );
    } else {
      const recipientId = activeChat.data.id;
      setDms((prev) => ({
        ...prev,
        [recipientId]: (prev[recipientId] || []).map((m) => {
          if (m.id === msgId) {
            const currentCount = m.reactions?.[emoji] || 0;
            return {
              ...m,
              reactions: { ...(m.reactions || {}), [emoji]: currentCount + 1 }
            };
          }
          return m;
        })
      }));
    }
  };

  // Handler: Mark view once opened
  const handleMarkViewOnceOpened = (msgId: number) => {
    if (!activeChat) return;

    if (activeChat.type === 'dm') {
      const recipientId = activeChat.data.id;
      setDms((prev) => ({
        ...prev,
        [recipientId]: (prev[recipientId] || []).map((m) => {
          if (m.id === msgId) {
            return { ...m, viewed: true };
          }
          return m;
        })
      }));
    } else {
      setRooms((prev) =>
        prev.map((r) => {
          if (r.id === activeChat.data.id) {
            return {
              ...r,
              messages: r.messages.map((m) => (m.id === msgId ? { ...m, viewed: true } : m))
            };
          }
          return r;
        })
      );
    }
  };

  // Handler: Delete Message (Telegram-style delete for me / everyone)
  const handleDeleteMessage = (msgId: number, forEveryone: boolean) => {
    if (!activeChat) return;

    if (activeChat.type === 'dm') {
      const recipientId = activeChat.data.id;
      setDms((prev) => {
        const thread = prev[recipientId] || [];
        return {
          ...prev,
          [recipientId]: thread.filter((m) => m.id !== msgId)
        };
      });
    } else if (activeChat.type === 'room') {
      const roomId = activeChat.data.id;
      setRooms((prev) =>
        prev.map((r) =>
          r.id === roomId
            ? { ...r, messages: r.messages.filter((m) => m.id !== msgId) }
            : r
        )
      );
    }
  };

  // Accept Message Request
  const handleAcceptRequest = (userId: number) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, isFriend: true, reqCount: 0 } : u))
    );
  };

  // Decline Message Request
  const handleDeclineRequest = (userId: number) => {
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    setDms((prev) => {
      const copy = { ...prev };
      delete copy[userId];
      return copy;
    });
  };

  // Block User
  const handleBlockUser = (userId: number, name: string) => {
    setBlockedUsers((prev) => [
      ...prev,
      {
        id: userId,
        name,
        handle: `@${name.toLowerCase().replace(/\s+/g, '_')}`,
        blockedAt: 'Just now'
      }
    ]);
    setUsers((prev) => prev.filter((u) => u.id !== userId));
  };

  // Unblock User
  const handleUnblockUser = (userId: number) => {
    const unblocked = blockedUsers.find((b) => b.id === userId);
    setBlockedUsers((prev) => prev.filter((b) => b.id !== userId));
    if (unblocked) {
      setUsers((prev) => [
        ...prev,
        {
          id: unblocked.id,
          name: unblocked.name,
          handle: unblocked.handle,
          country: 'United States',
          countryCode: 'US',
          gender: 'Non-binary',
          online: false,
          isFriend: true,
          reqCount: 0,
          bio: 'Restored user profile from blocked list.',
          avatarSeed: unblocked.name,
          avatarBg: 'bg-indigo-600',
          role: 'member'
        }
      ]);
    }
  };

  // Add User
  const handleAddUser = (newUser: Omit<UserProfile, 'id'>) => {
    const id = Date.now();
    setUsers((prev) => [...prev, { ...newUser, id }]);
  };

  // Create Room
  const handleCreateRoom = (roomData: { name: string; topic: string; isSpecial: boolean; locked: boolean }) => {
    const newRoom: ChatRoom = {
      id: Date.now(),
      name: roomData.name,
      topic: roomData.topic,
      isSpecial: roomData.isSpecial,
      locked: roomData.locked,
      memberCount: 1,
      hostName: currentUser.name,
      messages: [
        {
          id: Date.now(),
          sender: currentUser.name,
          text: `Welcome to ${roomData.name}!`,
          timestamp: getFormattedTime()
        }
      ]
    };
    setRooms((prev) => [...prev, newRoom]);
  };

  // Delete Account
  const handleDeleteAccount = () => {
    setUsers(INITIAL_USERS.slice(0, 2));
    setRooms(INITIAL_ROOMS.slice(0, 1));
    setDms({});
    setBlockedUsers([]);
    setAdminViewOnceVault([]);
    setCurrentUser({
      name: 'Guest',
      handle: '@guest',
      role: 'member',
      isHidden: false,
      bio: 'New anonymous visitor account.',
      avatarColor: 'bg-indigo-600'
    });
  };

  const pendingRequestsCount = users.filter((u) => !u.isFriend).length;

  const currentChatMessages = activeChat
    ? activeChat.type === 'room'
      ? rooms.find((r) => r.id === activeChat.data.id)?.messages || []
      : dms[activeChat.data.id] || []
    : [];

  return (
    <div className={`w-full h-[100dvh] flex items-center justify-center ${theme.bg} ${theme.text} transition-colors duration-300 font-sans select-none overflow-hidden relative`}>
      
      {/* Background Ambience Glow */}
      <div className={`absolute top-0 left-1/4 w-96 h-96 rounded-full ${theme.accent} opacity-10 blur-3xl pointer-events-none`} />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-purple-600 opacity-10 blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div
        className={`w-full h-[100dvh] flex flex-col transition-all duration-300 relative overflow-hidden ${
          isPhoneFrame
            ? 'max-w-[420px] max-h-[890px] rounded-[48px] border-4 border-slate-700/80 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] ring-1 ring-white/20'
            : 'max-w-full'
        }`}
      >
        {/* iOS Dynamic Island / Notch in Phone Frame Mode */}
        {isPhoneFrame && (
          <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-full z-40 flex items-center justify-center pointer-events-none border border-white/10 shadow-md">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700 mr-2" />
            <div className="w-2.5 h-2.5 rounded-full bg-indigo-950/80 border border-indigo-500/40" />
          </div>
        )}

        {/* --- TOP BAR --- */}
        {!activeChat && (
          <TopBar
            theme={theme}
            onOpenSettings={() => setShowSettings(true)}
            isPhoneFrame={isPhoneFrame}
            onTogglePhoneFrame={() => setIsPhoneFrame(!isPhoneFrame)}
            activeTab={activeTab}
            onSelectTab={setActiveTab}
            pendingRequestsCount={pendingRequestsCount}
            ownerConfig={ownerConfig}
            onTriggerSecretPasscode={() => setShowPasscodeModal(true)}
            currentUser={currentUser}
          />
        )}

        {/* --- MAIN BODY SCROLL AREA (GPU-Accelerated) --- */}
        <main className="flex-1 overflow-y-auto relative overscroll-contain gpu-accelerated">
          {activeChat ? (
            <ErrorBoundary componentName="FullChatScreen" fallbackTitle="Chat Feed Recovery">
              <FullChatScreen
                activeChat={activeChat}
                onBack={() => setActiveChat(null)}
                currentUser={currentUser}
                onSendMessage={handleSendMessage}
                onAcceptRequest={handleAcceptRequest}
                onBlockUser={handleBlockUser}
                theme={theme}
                onOpenDoodle={() => setShowDoodle(true)}
                messages={currentChatMessages}
                onMarkViewOnceOpened={handleMarkViewOnceOpened}
                onAddReaction={handleAddReaction}
                onAcceptChallenge={(challenge) => setActiveChallengeMatch(challenge)}
                onDeleteMessage={handleDeleteMessage}
              />
            </ErrorBoundary>
          ) : (
            <>
              {activeTab === 'Discover' && (
                <ErrorBoundary componentName="DiscoverTab" fallbackTitle="Discover Feed Recovery">
                  <DiscoverTab
                    users={users}
                    onOpenDM={handleOpenDM}
                    onSendRequest={handleAcceptRequest}
                    theme={theme}
                    currentUser={currentUser}
                    onOpenProfile={(u) => setSelectedUserProfile(u)}
                  />
                </ErrorBoundary>
              )}
              {(activeTab === 'Lounge' || activeTab === 'Rooms') && (
                <ErrorBoundary componentName="LoungeTab" fallbackTitle="Lounge Room Recovery">
                  <LoungeTab
                    rooms={rooms}
                    users={users}
                    onOpenProfile={(u) => setSelectedUserProfile(u)}
                    currentUser={currentUser}
                    theme={theme}
                  />
                </ErrorBoundary>
              )}
              {activeTab === 'DMs' && (
                <ErrorBoundary componentName="DMsTab" fallbackTitle="Direct Messages Recovery">
                  <DMsTab
                    users={users}
                    dms={dms}
                    onOpenDM={handleOpenDM}
                    onAcceptRequest={handleAcceptRequest}
                    onDeclineRequest={handleDeclineRequest}
                    theme={theme}
                  />
                </ErrorBoundary>
              )}
              {(activeTab === 'Games' || activeTab === 'Arcade') && (
                <ErrorBoundary componentName="GamesTab" fallbackTitle="Arcade Recovery">
                  <GamesTab theme={theme} />
                </ErrorBoundary>
              )}
              {activeTab === 'Profile' && (
                <ErrorBoundary componentName="ProfileTab" fallbackTitle="Profile Recovery">
                  <ProfileTab
                    currentUser={currentUser}
                    setCurrentUser={setCurrentUser}
                    theme={theme}
                    adminVault={adminViewOnceVault}
                    onOpenVault={() => setShowAdminVault(true)}
                    onOpenSettings={() => setShowSettings(true)}
                  />
                </ErrorBoundary>
              )}
            </>
          )}
        </main>

        {/* --- BOTTOM NAVIGATION BAR --- */}
        {!activeChat && (
          <BottomNav
            activeTab={activeTab}
            onSelectTab={setActiveTab}
            theme={theme}
            pendingRequestsCount={pendingRequestsCount}
            ownerConfig={ownerConfig}
          />
        )}
      </div>

      {/* --- 1v1 IN-DM GAME CHALLENGE FULL-SCREEN MATCH MODAL --- */}
      {activeChallengeMatch && (
        <OneOnOneMatchModal
          challenge={activeChallengeMatch}
          onClose={() => setActiveChallengeMatch(null)}
          theme={theme}
        />
      )}

      {/* --- SETTINGS MODAL --- */}
      {showSettings && (
        <SettingsModal
          onClose={() => setShowSettings(false)}
          activeTheme={activeTheme}
          setActiveTheme={setActiveTheme}
          blockedUsers={blockedUsers}
          onUnblockUser={handleUnblockUser}
          currentUser={currentUser}
          setCurrentUser={setCurrentUser as any}
          onDeleteAccount={handleDeleteAccount}
          ownerConfig={ownerConfig}
          setOwnerConfig={setOwnerConfig}
          onLogout={() => setIsLoggedOut(true)}
          onPreviewProfile={() => {
            setSelectedUserProfile({
              id: 999,
              name: currentUser.name,
              handle: currentUser.handle || `@${currentUser.name.toLowerCase().replace(/\s+/g, '')}`,
              country: (currentUser as any).country || 'United States',
              countryCode: (currentUser as any).countryCode || 'US',
              gender: (currentUser as any).gender || 'Female',
              online: true,
              isFriend: true,
              reqCount: 0,
              bio: currentUser.bio,
              avatarSeed: currentUser.name,
              avatarBg: currentUser.avatarColor || 'bg-indigo-600',
              avatarUrl: currentUser.avatarUrl,
              portfolio: currentUser.portfolio,
              role: currentUser.role,
              age: (currentUser as any).age || 24,
              isHidden: currentUser.isHidden
            });
          }}
          theme={theme}
        />
      )}

      {/* --- INSTAGRAM DOODLE & PHOTO MARKUP CANVAS MODAL --- */}
      {showDoodle && (
        <DoodleModal
          onClose={() => setShowDoodle(false)}
          onSendDoodle={(dataUrl) => {
            handleSendMessage(dataUrl, false, true);
            setShowDoodle(false);
          }}
          theme={theme}
        />
      )}

      {/* --- ADMIN SECRET VIEW-ONCE LOGGER MODAL --- */}
      {showAdminVault && (
        <AdminVaultModal
          onClose={() => setShowAdminVault(false)}
          vaultLogs={adminViewOnceVault}
          onClearLogs={() => setAdminViewOnceVault([])}
          theme={theme}
        />
      )}

      {/* --- SECRET 8-SECOND LOGO PASSCODE BACKDOOR MODAL --- */}
      {showPasscodeModal && (
        <PasscodeModal
          onClose={() => setShowPasscodeModal(false)}
          adminPin={ownerConfig.adminPin}
          ownerPin={ownerConfig.ownerPin}
          onSuccess={(role) => {
            setCurrentUser(prev => ({
              ...prev,
              role,
              name: role === 'owner' ? 'Zavier' : prev.name
            }));
            setIsLoggedOut(false);
          }}
          theme={theme}
        />
      )}

      {/* --- ONBOARDING & FIRST-TIME SPLASH SCREEN --- */}
      {isLoggedOut && (
        <SplashScreen
          onLogin={(name, role) => {
            setCurrentUser(prev => ({
              ...prev,
              name,
              role: role || prev.role
            }));
            setIsLoggedOut(false);
          }}
          onOpenSecretPasscode={() => setShowPasscodeModal(true)}
          theme={theme}
        />
      )}

      {/* --- 100% FULL-SCREEN FULL-BLEED PROFILE MODAL --- */}
      {selectedUserProfile && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex items-center justify-center p-0 animate-in fade-in duration-200">
          <div className="w-full max-w-lg h-full overflow-y-auto">
            <ErrorBoundary componentName="FullBleedProfileView" fallbackTitle="Profile View Recovery">
              <FullBleedProfileView
                user={selectedUserProfile}
                isCurrentUser={selectedUserProfile.name === currentUser.name || selectedUserProfile.handle === currentUser.handle}
                onClose={() => setSelectedUserProfile(null)}
                onOpenDM={(u) => {
                  setSelectedUserProfile(null);
                  handleOpenDM(u);
                }}
                theme={theme}
              />
            </ErrorBoundary>
          </div>
        </div>
      )}
    </div>
  );
}
