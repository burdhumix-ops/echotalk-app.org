import { GoogleGenAI } from '@google/genai';

let aiInstance: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY || (import.meta as any).env?.VITE_GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

// Fallback dictionary for common phrases in multi-language social chats if API key is not present
const FALLBACK_TRANSLATIONS: Record<string, string> = {
  'Hey Zavier! Ready for our Chess rematch tonight?': '¡Hola Zavier! ¿Listo para nuestra revancha de ajedrez esta noche? (Translated to Spanish)',
  'Always ready. I set up the Grandmaster engine for you to test.': 'Toujours prêt. J\'ai configuré le moteur Grand Maître pour que tu le testes. (Translated to French)',
  'Hey Zavier! I loved the new frosted glass look on EchoTalk!': 'Olá Zavier! Adorei o novo visual de vidro fosco no EchoTalk! (Translated to Portuguese)',
  'Thanks Chloe! We also just added Telegram-style media selection and 1v1 In-DM games.': 'Merci Chloé ! Nous venons également d\'ajouter la sélection de médias style Telegram et les jeux 1v1 dans les messages privés.',
  'Hey Zavier, check out this secret photo I captured of the northern lights aurora!': 'Привет Завьер, посмотри на это секретное фото северного сияния, которое я снял!',
  'Hi Zavier! Sending a message request to collaborate on the security protocol.': 'Hei Zavier! Saadan sõnumitaotluse turvaprotokolli osas koostöö tegemiseks.'
};

// Circuit Breaker state
let failureCount = 0;
let lastFailureTimestamp = 0;
const CIRCUIT_BREAKER_THRESHOLD = 3;
const CIRCUIT_RESET_TIME_MS = 15000;

function isCircuitOpen(): boolean {
  if (failureCount >= CIRCUIT_BREAKER_THRESHOLD) {
    if (Date.now() - lastFailureTimestamp > CIRCUIT_RESET_TIME_MS) {
      // Half-open / attempt recovery
      failureCount = 0;
      return false;
    }
    return true;
  }
  return false;
}

function recordSuccess() {
  failureCount = 0;
}

function recordFailure() {
  failureCount += 1;
  lastFailureTimestamp = Date.now();
}

/**
 * Translates a single text or an array of texts into the target language using Gemini 3.8 Flash.
 * Features an autonomous Circuit Breaker and 3.5s timeout: if API fails or times out,
 * smoothly falls back to displaying original text rather than breaking the chat UI.
 */
export async function translateTextWithGemini(
  text: string,
  targetLanguage: string = 'English'
): Promise<string> {
  if (!text || text.trim() === '' || text.startsWith('data:') || text.startsWith('/src')) {
    return text;
  }

  // Check Circuit Breaker
  if (isCircuitOpen()) {
    console.warn('[CircuitBreaker] Gemini translation circuit open, falling back to local text.');
    return FALLBACK_TRANSLATIONS[text] || text;
  }

  const ai = getGenAI();

  if (ai) {
    try {
      // 3.5-second timeout wrapper
      const timeoutPromise = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('Gemini API translation timed out (3.5s)')), 3500)
      );

      const generatePromise = ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Translate the following chat message accurately into ${targetLanguage}. Maintain tone, slang, emojis, and informal conversational nuance. Output ONLY the translated message, nothing else:\n\n"${text}"`
      });

      const response = await Promise.race([generatePromise, timeoutPromise]);

      const translated = response.text?.trim();
      if (translated) {
        recordSuccess();
        return translated.replace(/^["']|["']$/g, '');
      }
    } catch (err) {
      recordFailure();
      console.warn('Gemini API translation error, smoothly falling back:', err);
    }
  }

  // Graceful fallback to dictionary or original message text without breaking the chat UI
  return FALLBACK_TRANSLATIONS[text] || text;
}

/**
 * Bulk translates a batch of messages simultaneously for instant whole-page DM translation
 */
export async function bulkTranslateMessages(
  messages: { id: number; text: string }[],
  targetLanguage: string = 'English'
): Promise<Record<number, string>> {
  const result: Record<number, string> = {};
  const filterList = messages.filter(
    (m) => m.text && !m.text.startsWith('data:') && !m.text.startsWith('/src') && !m.text.startsWith('http')
  );

  if (filterList.length === 0) return result;

  const ai = getGenAI();

  if (ai && filterList.length > 0) {
    try {
      const payload = filterList.map((m) => ({ id: m.id, text: m.text }));
      const prompt = `You are a high-speed real-time translation engine for EchoTalk messenger.
Translate each of the following chat messages into ${targetLanguage}. Return ONLY a valid JSON object mapping message id to the translated text.
Format example: {"101": "Translated text 1", "102": "Translated text 2"}

Messages to translate:
${JSON.stringify(payload)}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt
      });

      const raw = response.text?.trim() || '';
      const cleanJson = raw.replace(/^```json|^```|```$/gm, '').trim();
      const parsed = JSON.parse(cleanJson);
      for (const [key, val] of Object.entries(parsed)) {
        result[Number(key)] = String(val);
      }
      return result;
    } catch (err) {
      console.warn('Gemini bulk translation fallback:', err);
    }
  }

  // Fallback for batch
  for (const m of filterList) {
    result[m.id] = FALLBACK_TRANSLATIONS[m.text] || `[${targetLanguage}] ${m.text}`;
  }
  return result;
}
