import { GoogleGenAI } from '@google/genai';

let aiInstance: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY || (import.meta as any).env?.VITE_GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

export type PolishTone = 'Casual' | 'Formal' | 'Poetic' | 'Sarcastic';

/**
 * Generate 3 contextual 2-word quick reply chips based on the latest message
 */
export async function generateSmartReplies(latestMessage: string): Promise<string[]> {
  if (!latestMessage) return ['Sounds good', 'On it', 'Talk soon'];

  const ai = getGenAI();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `You are generating 3 short, 2-word conversational smart reply chips for a chat app in response to this message: "${latestMessage}".
Return ONLY a valid JSON array with exactly 3 strings, each string being 1-2 words. Example: ["Sounds great!", "On my way", "Can't wait!"]`
      });

      const raw = response.text?.trim() || '';
      const cleanJson = raw.replace(/^```json|^```|```$/gm, '').trim();
      const parsed = JSON.parse(cleanJson);
      if (Array.isArray(parsed) && parsed.length >= 2) {
        return parsed.slice(0, 3);
      }
    } catch (e) {
      console.warn('Smart replies fallback:', e);
    }
  }

  // Deterministic contextual fallbacks based on text keywords
  const lower = latestMessage.toLowerCase();
  if (lower.includes('?') || lower.includes('ready') || lower.includes('game')) {
    return ["I'm ready!", "Let's play", "In a bit"];
  }
  if (lower.includes('photo') || lower.includes('look') || lower.includes('check')) {
    return ['Looks awesome!', 'Love it', 'Super cool'];
  }
  return ['Sounds great!', 'Got it', 'Talk soon'];
}

/**
 * Polish voice-to-text transcriptions into desired tone
 */
export async function polishTranscriptTone(
  transcript: string,
  tone: PolishTone
): Promise<string> {
  if (!transcript) return transcript;

  const ai = getGenAI();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Rephrase this transcribed message with a ${tone} tone. Keep it natural, under 2 sentences, preserving original intent:\n\n"${transcript}"`
      });
      const result = response.text?.trim();
      if (result) {
        return result.replace(/^["']|["']$/g, '');
      }
    } catch (e) {
      console.warn('Tone polish fallback:', e);
    }
  }

  // Fallbacks by tone
  switch (tone) {
    case 'Formal':
      return `Kindly noted: ${transcript}. Looking forward to connecting.`;
    case 'Poetic':
      return `Like autumn leaves upon the wind: ${transcript}.`;
    case 'Sarcastic':
      return `Oh absolutely, naturally: ${transcript} 😉`;
    default:
      return `${transcript} 🙌`;
  }
}
