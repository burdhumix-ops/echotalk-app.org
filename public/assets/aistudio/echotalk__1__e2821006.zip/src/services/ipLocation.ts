import { getCountryFlag } from '../utils/profileUtils';

export interface DetectedLocation {
  country: string;
  countryCode: string;
  flag: string;
  city?: string;
  ip?: string;
}

let cachedLocation: DetectedLocation | null = null;

export async function detectUserLocation(): Promise<DetectedLocation> {
  if (cachedLocation) {
    return cachedLocation;
  }

  // Check localStorage first
  try {
    const stored = localStorage.getItem('echotalk_detected_location');
    if (stored) {
      cachedLocation = JSON.parse(stored);
      return cachedLocation!;
    }
  } catch (e) {
    // ignore
  }

  // Attempt lightweight IP lookup with graceful timeouts
  const controllers = [
    {
      url: 'https://ipapi.co/json/',
      parse: (d: any): DetectedLocation => ({
        country: d.country_name || 'United States',
        countryCode: d.country_code || 'US',
        flag: getCountryFlag(d.country_code || 'US'),
        city: d.city,
        ip: d.ip
      })
    },
    {
      url: 'https://ip-api.com/json/?fields=status,country,countryCode,city,query',
      parse: (d: any): DetectedLocation => ({
        country: d.country || 'United States',
        countryCode: d.countryCode || 'US',
        flag: getCountryFlag(d.countryCode || 'US'),
        city: d.city,
        ip: d.query
      })
    }
  ];

  for (const provider of controllers) {
    try {
      const abortController = new AbortController();
      const timeoutId = setTimeout(() => abortController.abort(), 2500);
      const res = await fetch(provider.url, { signal: abortController.signal });
      clearTimeout(timeoutId);
      if (res.ok) {
        const data = await res.json();
        const parsed = provider.parse(data);
        if (parsed.country && parsed.countryCode) {
          cachedLocation = parsed;
          try {
            localStorage.setItem('echotalk_detected_location', JSON.stringify(parsed));
          } catch (e) {}
          return parsed;
        }
      }
    } catch (e) {
      // Continue to next provider
    }
  }

  // Default fallback based on local Intl / timezone detection if network fails or adblocker active
  try {
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    if (timeZone.includes('Tokyo') || timeZone.includes('Japan')) {
      cachedLocation = { country: 'Japan', countryCode: 'JP', flag: '🇯🇵' };
    } else if (timeZone.includes('London') || timeZone.includes('Europe/London')) {
      cachedLocation = { country: 'United Kingdom', countryCode: 'GB', flag: '🇬🇧' };
    } else if (timeZone.includes('Paris') || timeZone.includes('Europe/Paris')) {
      cachedLocation = { country: 'France', countryCode: 'FR', flag: '🇫🇷' };
    } else if (timeZone.includes('Sao_Paulo') || timeZone.includes('Brazil')) {
      cachedLocation = { country: 'Brazil', countryCode: 'BR', flag: '🇧🇷' };
    } else if (timeZone.includes('Karachi') || timeZone.includes('Pakistan')) {
      cachedLocation = { country: 'Pakistan', countryCode: 'PK', flag: '🇵🇰' };
    } else {
      cachedLocation = { country: 'United States', countryCode: 'US', flag: '🇺🇸' };
    }
  } catch (e) {
    cachedLocation = { country: 'United States', countryCode: 'US', flag: '🇺🇸' };
  }

  return cachedLocation;
}
