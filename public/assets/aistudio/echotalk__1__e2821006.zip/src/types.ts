export type ThemeKey = 
  | 'classic'            // Classic (Default Light): #F8F9FA, Material 3 white card, dark charcoal text, sapphire accent #2563EB
  | 'ios-glass'           // iOS Glassmorphism (Dark Translucent): #0B0F17, frosted blur, neon indigo #6366F1
  | 'warm-sand'           // Warm Sand & Cream (Fresh Soft): #FDFBF7, soft skin-tone card #F5EBE0, coffee typography #3D2C2E
  | 'midnight-emerald'    // Midnight Emerald (Rich Dark): #0D1B1E, teal card #162A2D, gold/mint #10B981
  | 'obsidian'            // Obsidian Pure Dark (OLED Black): #000000, graphite card #121212, neon violet #8B5CF6
  | 'midnight'            // Alias for backwards compatibility
  | 'emerald';

export interface ThemeConfig {
  id: ThemeKey;
  name: string;
  bg: string;
  surface: string;
  card: string;
  cardBorder: string;
  text: string;
  textMuted: string;
  accent: string;
  accentText: string;
  accentHover: string;
  accentSoft: string;
  accentGlow: string;
  border: string;
  inputBg: string;
  bubbleUser: string;
  bubbleOther: string;
  isDark: boolean;
  navBg?: string;
  activeIndicator?: string;
}

export interface UserProfile {
  id: number;
  name: string;
  handle: string;
  country: string;
  countryCode: string;
  gender: 'Male' | 'Female' | 'Non-binary';
  online: boolean;
  isFriend: boolean;
  reqCount: number; // 0..3 (capped at 3)
  bio: string;
  avatarSeed: string;
  avatarBg: string;
  role: 'owner' | 'admin' | 'member';
  lastSeen?: string;
  isHidden?: boolean;
  avatarUrl?: string;
  portfolio?: string[];
  age?: number;
  likeCount?: number;
  isLiked?: boolean;
  isFriendReqSent?: boolean;
}

export interface GameChallengeData {
  game: 'chess' | 'ludo';
  status: 'pending' | 'accepted' | 'declined';
  challenger: string;
  opponent: string;
  challengerId?: number;
  opponentId?: number;
  matchId: string;
}

export interface ChatMessage {
  id: number;
  sender: string;
  senderId?: number;
  text: string;
  timestamp: string;
  status?: 'sent' | 'delivered' | 'seen';
  seenAt?: string;
  isViewOnce?: boolean;
  viewed?: boolean;
  isDoodle?: boolean;
  mediaUrl?: string;
  mediaType?: 'image' | 'audio' | 'doodle';
  reactions?: Record<string, number>;
  isAudio?: boolean;
  audioDuration?: string;
  audioWaveform?: number[];
  isChallenge?: boolean;
  challengeData?: GameChallengeData;
  translatedText?: string;
  isTranslating?: boolean;
  isDeletedForEveryone?: boolean;
  deletedForUserIds?: string[];
  isDissolving?: boolean;
}

export interface ChatRoom {
  id: number;
  name: string;
  topic: string;
  isSpecial: boolean;
  locked: boolean;
  messages: ChatMessage[];
  memberCount: number;
  hostName: string;
  isVoiceRoom?: boolean;
  activeSpeakers?: number;
  passcode?: string;
  icon?: string;
}

export interface AdminVaultEntry {
  id: number;
  timestamp: string;
  sender: string;
  target: string;
  mediaUrl: string;
  mediaType: 'image' | 'doodle' | 'text';
  previewText: string;
  interceptionStatus: 'Stored & Decrypted' | 'Intercepted in Transit';
}

export interface BlockedUser {
  id: number;
  name: string;
  handle: string;
  blockedAt: string;
}

export interface ActiveChatTarget {
  type: 'room' | 'dm';
  data: ChatRoom | UserProfile;
}

export interface GalleryPhoto {
  id: string;
  url: string;
  title: string;
  category: string;
}

export interface GameDetailInfo {
  id: 'chess' | 'checkers' | 'ludo' | 'mafia';
  title: string;
  category: string;
  players: string;
  description: string;
  rules: string[];
  modes: string[];
  image: string;
  badge: string;
}

export interface OwnerConfig {
  adminPin: string;
  ownerPin: string;
  tabLabels: {
    Discover: string;
    Lounge: string;
    DMs: string;
    Arcade: string;
    Profile: string;
    Crew?: string;
    Rooms?: string;
    Games?: string;
  };
  enableArcade: boolean;
  enableViewOnceVault: boolean;
  enableGhostMode: boolean;
  allowDirectDMsWithoutRequest: boolean;
}
