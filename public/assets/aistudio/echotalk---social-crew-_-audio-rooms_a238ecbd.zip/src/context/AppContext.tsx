import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  User,
  Room,
  DM,
  AppNotification,
  ActivityLogItem,
  RoomMessage,
  ThemeId,
  AdminViewOnceVaultItem,
  TabType,
  DMRequestStatus,
  GameId,
  GameChallenge,
} from '../types';
import { audioManager } from '../utils/audio';

export interface ActiveGameSession {
  gameId: GameId;
  opponentName?: string;
  mode: 'ai' | 'pass-and-play' | 'multiplayer';
}

interface AppContextType {
  // Navigation
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;

  // Modern Color Themes
  theme: ThemeId;
  setTheme: (theme: ThemeId) => void;

  // Active Current User & Admin State
  currentUser: User;
  setCurrentUser: (user: User) => void;
  isAdmin: boolean;
  setIsAdmin: (val: boolean) => void;
  isUserAdminOrOwner: boolean;

  // Admin-Only Secret View-Once Image Vault
  adminViewOnceVault: AdminViewOnceVaultItem[];
  deleteVaultItem: (vaultId: string) => void;
  clearAdminVault: () => void;

  // Users / Crew (AppLogic)
  users: User[];
  addUser: (name: string, gender: string, country: string, avatar?: string, bio?: string) => void;
  updateUserStatus: (name: string, online: boolean) => void;
  updateOnlineStatus: (userName: string, status: boolean) => void;
  filterCrew: (filters: { country?: string; gender?: string }) => User[];
  sortCrewOnlineFirst: (crewList: User[]) => User[];
  getOnlineUsers: () => User[];

  // Rooms (AppLogic)
  rooms: Room[];
  currentRoomName: string;
  setCurrentRoomName: (name: string) => void;
  currentRoom: Room | undefined;
  createRoom: (name: string, options?: { isSpecialRoom?: boolean; description?: string }) => { success: boolean; error?: string };
  sendMessage: (roomName: string, userName: string, message: string, voiceNote?: string, voiceDuration?: number) => { success: boolean; error?: string };
  kickUser: (roomName: string, userName: string) => void;
  lockRoom: (roomName: string) => { success: boolean; error?: string };
  unlockRoom: (roomName: string) => { success: boolean; error?: string };
  openRoom: (roomName: string) => void;
  closeRoom: (roomName: string) => void;
  cleanupMessages: (roomName: string) => void;
  startMessageCleanupTimer: (roomName: string, durationInSeconds: number) => void;
  cancelMessageCleanupTimer: (roomName: string) => void;

  // DMs / Private Messages (AppLogic)
  dmList: DM[];
  activeDmPartner: string;
  setActiveDmPartner: (userName: string) => void;
  sendDM: (
    from: string,
    to: string,
    message: string,
    options?: {
      image?: string;
      isDoodle?: boolean;
      viewOnce?: boolean;
      gameChallenge?: GameChallenge;
    }
  ) => { success: boolean; error?: string };
  sendVoiceNote: (from: string, to: string, voiceFile: string, duration?: number) => void;
  openViewOnceDM: (dmId: string) => void;
  getDMHistory: (user1: string, user2: string) => DM[];

  // DM Request System (3-Message Limit & Accept/Decline)
  contactStatuses: Record<string, DMRequestStatus>;
  getContactStatus: (contactName: string) => DMRequestStatus;
  getSenderConsecutiveCount: (sender: string, receiver: string) => number;
  acceptDMRequest: (senderName: string) => void;
  declineDMRequest: (senderName: string) => void;

  // Mini-Games Arcade Hub (Chess, Ludo, Checkers, Mafia)
  activeGame: ActiveGameSession | null;
  launchGame: (gameId: GameId, opponentName?: string, mode?: 'ai' | 'pass-and-play' | 'multiplayer') => void;
  closeActiveGame: () => void;
  sendGameChallenge: (gameId: GameId, targetUser: string) => void;
  acceptGameChallenge: (challenge: GameChallenge) => void;

  // Utilities & Notifications
  notifications: AppNotification[];
  notifyUser: (userName: string, message: string, type?: 'info' | 'admin' | 'dm' | 'room') => void;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;

  // Activity Logs (Reflecting all Dart print statements)
  activityLogs: ActivityLogItem[];
  clearLogs: () => void;

  // Simulation helpers
  simulateIncomingDM: (from: string, text: string) => void;
  simulateIncomingRoomMessage: (roomName: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Initial crew seed data
const INITIAL_USERS: User[] = [
  {
    id: 'u-1',
    name: 'Alex Rivera',
    gender: 'Non-Binary',
    country: 'United States',
    online: true,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    bio: 'Product Designer & Sound Enthusiast · San Francisco',
    role: 'owner',
    joinedAt: 'May 2026',
  },
  {
    id: 'u-2',
    name: 'Kenji Sato',
    gender: 'Male',
    country: 'Japan',
    online: true,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    bio: 'Audio engineer & synthesizer collector · Tokyo',
    role: 'member',
    joinedAt: 'April 2026',
  },
  {
    id: 'u-3',
    name: 'Amara Okafor',
    gender: 'Female',
    country: 'Nigeria',
    online: true,
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=150&auto=format&fit=crop&q=80',
    bio: 'Creative director, podcast producer & voice artist · Lagos',
    role: 'member',
    joinedAt: 'March 2026',
  },
  {
    id: 'u-4',
    name: 'Matteo Rossi',
    gender: 'Male',
    country: 'Italy',
    online: false,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    bio: 'Music producer & jazz pianist · Milan',
    role: 'member',
    joinedAt: 'June 2026',
  },
  {
    id: 'u-5',
    name: 'Priya Sharma',
    gender: 'Female',
    country: 'India',
    online: true,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    bio: 'Distributed systems dev & community host · Bengaluru',
    role: 'member',
    joinedAt: 'February 2026',
  },
  {
    id: 'u-6',
    name: 'Lucas Silva',
    gender: 'Male',
    country: 'Brazil',
    online: false,
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    bio: 'Mobile dev & samba percussionist · São Paulo',
    role: 'member',
    joinedAt: 'January 2026',
  },
  {
    id: 'u-7',
    name: 'Chloe Dubois',
    gender: 'Female',
    country: 'France',
    online: true,
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    bio: 'Independent journalist & ambient beat maker · Paris',
    role: 'member',
    joinedAt: 'July 2026',
  },
  {
    id: 'u-8',
    name: 'Liam O’Connor',
    gender: 'Male',
    country: 'Ireland',
    online: false,
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    bio: 'Voiceover specialist & indie game audio designer · Dublin',
    role: 'member',
    joinedAt: 'August 2026',
  },
  {
    id: 'u-9',
    name: 'Elena Rostova',
    gender: 'Female',
    country: 'Germany',
    online: true,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    bio: 'Spatial audio DSP engineer & modular artist · Berlin',
    role: 'member',
    joinedAt: 'September 2026',
  },
  {
    id: 'u-10',
    name: 'Devon Vance',
    gender: 'Male',
    country: 'Canada',
    online: false,
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    bio: 'Electronic beatmaker & mastering specialist · Montreal',
    role: 'member',
    joinedAt: 'September 2026',
  },
];

// Initial rooms seed data
const INITIAL_ROOMS: Room[] = [
  {
    id: 'r-1',
    name: 'Echo Lounge',
    description: 'General open floor for casual live voice drop-ins and daily crew check-ins.',
    isSpecialRoom: false,
    locked: false,
    isOpen: true,
    messages: [
      'Alex Rivera: Welcome everyone to EchoTalk! Let us know what you are creating today.',
      'Kenji Sato: Hey Alex! Just finalized the modular rack setup in Tokyo. Sounds unreal.',
      'Amara Okafor: Love the audio quality in here! Checking in before recording episode 14.',
      'Priya Sharma: Audio sync is so crisp! Happy to be here with the global crew.',
    ],
    richMessages: [
      {
        id: 'rm-1',
        roomName: 'Echo Lounge',
        userName: 'Alex Rivera',
        message: 'Welcome everyone to EchoTalk! Let us know what you are creating today.',
        timestamp: '11:42 AM',
      },
      {
        id: 'rm-2',
        roomName: 'Echo Lounge',
        userName: 'Kenji Sato',
        message: 'Hey Alex! Just finalized the modular rack setup in Tokyo. Sounds unreal.',
        timestamp: '11:45 AM',
      },
      {
        id: 'rm-3',
        roomName: 'Echo Lounge',
        userName: 'Amara Okafor',
        message: 'Love the audio quality in here! Checking in before recording episode 14.',
        timestamp: '11:50 AM',
      },
      {
        id: 'rm-4',
        roomName: 'Echo Lounge',
        userName: 'Priya Sharma',
        message: 'Audio sync is so crisp! Happy to be here with the global crew.',
        timestamp: '11:58 AM',
      },
    ],
    participants: ['Alex Rivera', 'Kenji Sato', 'Amara Okafor', 'Priya Sharma', 'Chloe Dubois'],
    cleanupTimerSeconds: undefined,
    cleanupTimerExpiresAt: null,
  },
  {
    id: 'r-2',
    name: 'Special 2-Day Lounge',
    description: 'Exclusive 48-Hour pop-up room. Only this special room can be locked by administrators.',
    isSpecialRoom: true, // Only 1 special room can be locked!
    locked: false,
    isOpen: true,
    messages: [
      'Alex Rivera: [System] The Special 2-Day Lounge is live. Only administrators can lock/unlock this room.',
      'Kenji Sato: Has anyone tested the 48-hour auto cleanup countdown yet?',
      'Amara Okafor: Yes! The timer auto-purges messages once the 2-day session expires.',
    ],
    richMessages: [
      {
        id: 'rm-201',
        roomName: 'Special 2-Day Lounge',
        userName: 'Alex Rivera',
        message: 'The Special 2-Day Lounge is live. Only administrators can lock/unlock this room.',
        timestamp: '10:00 AM',
        isSystem: true,
      },
      {
        id: 'rm-202',
        roomName: 'Special 2-Day Lounge',
        userName: 'Kenji Sato',
        message: 'Has anyone tested the 48-hour auto cleanup countdown yet?',
        timestamp: '10:15 AM',
      },
      {
        id: 'rm-203',
        roomName: 'Special 2-Day Lounge',
        userName: 'Amara Okafor',
        message: 'Yes! The timer auto-purges messages once the 2-day session expires.',
        timestamp: '10:30 AM',
      },
    ],
    participants: ['Alex Rivera', 'Kenji Sato', 'Amara Okafor'],
    cleanupTimerSeconds: 172800, // 48 hours = 2 days
    cleanupTimerExpiresAt: Date.now() + 172800 * 1000,
  },
  {
    id: 'r-3',
    name: 'Creators & Sound Lab',
    description: 'Voice note sharing, production feedback, and microphone testing.',
    isSpecialRoom: false,
    locked: false,
    isOpen: true,
    messages: [
      'Chloe Dubois: Just posted a 12s voice snippet testing the cardioid pattern.',
      'Matteo Rossi: Sounded super warm Chloe, great low-end roll-off.',
    ],
    richMessages: [
      {
        id: 'rm-301',
        roomName: 'Creators & Sound Lab',
        userName: 'Chloe Dubois',
        message: 'Just posted a voice snippet testing the cardioid pattern.',
        voiceNote: 'voice-sample-1',
        voiceDuration: 6,
        timestamp: '09:20 AM',
      },
      {
        id: 'rm-302',
        roomName: 'Creators & Sound Lab',
        userName: 'Matteo Rossi',
        message: 'Sounded super warm Chloe, great low-end roll-off.',
        timestamp: '09:35 AM',
      },
    ],
    participants: ['Chloe Dubois', 'Matteo Rossi', 'Liam O’Connor'],
    cleanupTimerSeconds: undefined,
    cleanupTimerExpiresAt: null,
  },
];

// Initial DMs seed data
const INITIAL_DMS: DM[] = [
  {
    id: 'dm-1',
    from: 'Kenji Sato',
    to: 'Alex Rivera',
    message: 'Hey Alex, do you have a second to review the room locking permissions?',
    timestamp: '11:15 AM',
  },
  {
    id: 'dm-2',
    from: 'Alex Rivera',
    to: 'Kenji Sato',
    message: 'Sure thing Kenji! In EchoTalk, only the special room is lockable by admins.',
    timestamp: '11:18 AM',
  },
  {
    id: 'dm-3',
    from: 'Kenji Sato',
    to: 'Alex Rivera',
    message: '[Voice Note]',
    voiceNote: 'voice-sample-kenji',
    voiceDuration: 5,
    timestamp: '11:20 AM',
  },
  {
    id: 'dm-3b',
    from: 'Kenji Sato',
    to: 'Alex Rivera',
    message: '[Doodle Artwork]',
    image: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200"><rect width="300" height="200" fill="%23090d16"/><path d="M40 100 Q 75 40, 110 100 T 180 100 T 250 100" fill="none" stroke="%23818cf8" stroke-width="6" stroke-linecap="round"/><circle cx="150" cy="65" r="16" fill="%2338bdf8"/><text x="150" y="160" fill="%2334d399" font-family="sans-serif" font-size="14" font-weight="bold" text-anchor="middle">Modular Synth Patch #4</text></svg>',
    isDoodle: true,
    viewOnce: false,
    timestamp: '11:22 AM',
  },
  {
    id: 'dm-3c',
    from: 'Kenji Sato',
    to: 'Alex Rivera',
    message: '[View Once Photo]',
    image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=600&auto=format&fit=crop&q=80',
    isDoodle: false,
    viewOnce: true,
    opened: false,
    timestamp: '11:24 AM',
  },
  {
    id: 'dm-4',
    from: 'Amara Okafor',
    to: 'Alex Rivera',
    message: 'Sending you the guest lineup for the Special 2-Day Lounge audio session!',
    timestamp: '10:45 AM',
  },
  {
    id: 'dm-5',
    from: 'Alex Rivera',
    to: 'Amara Okafor',
    message: 'Awesome, looking forward to hearing everyone on the mic.',
    timestamp: '10:50 AM',
  },
  {
    id: 'dm-6',
    from: 'Amara Okafor',
    to: 'Alex Rivera',
    message: '[Voice Note]',
    voiceNote: 'voice-sample-amara',
    voiceDuration: 7,
    timestamp: '10:52 AM',
  },
  {
    id: 'dm-req-1',
    from: 'Elena Rostova',
    to: 'Alex Rivera',
    message: 'Hi Alex, saw your work on spatial audio. Would love to collaborate with the EchoTalk crew!',
    timestamp: '09:15 AM',
  },
  {
    id: 'dm-req-2',
    from: 'Elena Rostova',
    to: 'Alex Rivera',
    message: 'Here is a quick question about your stereo imaging setup in Echo Lounge.',
    timestamp: '09:20 AM',
  },
  {
    id: 'dm-req-3',
    from: 'Devon Vance',
    to: 'Alex Rivera',
    message: 'Hey Alex! Are you taking on new music producer clients right now?',
    timestamp: '08:45 AM',
  },
];

// Seed records for Admin-Only Secret View-Once Image Vault
const INITIAL_VAULT_ITEMS: AdminViewOnceVaultItem[] = [
  {
    id: 'vault-seed-1',
    originalDmId: 'dm-3c',
    senderName: 'Kenji Sato',
    recipientName: 'Alex Rivera',
    image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=600&auto=format&fit=crop&q=80',
    isDoodle: false,
    capturedAt: '11:24 AM',
    openedByRecipient: false,
    caption: 'Studio analog synthesizer patch bay test',
  },
  {
    id: 'vault-seed-2',
    senderName: 'Amara Okafor',
    recipientName: 'Alex Rivera',
    image: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200"><rect width="300" height="200" fill="%23090d16"/><circle cx="150" cy="100" r="70" fill="none" stroke="%23ec4899" stroke-width="8"/><path d="M100 100 L200 100 M150 50 L150 150" stroke="%2306b6d4" stroke-width="6" stroke-linecap="round"/><text x="150" y="185" fill="%23ffffff" font-family="sans-serif" font-size="12" text-anchor="middle">Stage Layout Sketch</text></svg>',
    isDoodle: true,
    capturedAt: '10:48 AM',
    openedByRecipient: true,
    openedAt: '10:51 AM',
    caption: 'Confidential stage layout sketch',
  },
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation tab
  const [activeTab, setActiveTab] = useState<TabType>('Crew');

  // Modern Theme Engine (midnight, cyberpunk, emerald, sunset, tokyo, light)
  const [theme, setThemeState] = useState<ThemeId>('midnight');

  // Contact status map for DM Requests: 'accepted' | 'pending' | 'declined'
  const [contactStatuses, setContactStatuses] = useState<Record<string, DMRequestStatus>>({
    'Elena Rostova': 'pending',
    'Devon Vance': 'pending',
    'Kenji Sato': 'accepted',
    'Amara Okafor': 'accepted',
    'Matteo Rossi': 'accepted',
    'Priya Sharma': 'accepted',
    'Lucas Silva': 'accepted',
    'Chloe Dubois': 'accepted',
    'Liam O’Connor': 'accepted',
  });

  // Active game session
  const [activeGame, setActiveGame] = useState<ActiveGameSession | null>(null);

  // Admin-Only Secret View-Once Image Vault
  const [adminViewOnceVault, setAdminViewOnceVault] = useState<AdminViewOnceVaultItem[]>(INITIAL_VAULT_ITEMS);

  // Users state
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[0]);
  const [isAdmin, setIsAdmin] = useState<boolean>(true);

  // Rooms state
  const [rooms, setRooms] = useState<Room[]>(INITIAL_ROOMS);
  const [currentRoomName, setCurrentRoomName] = useState<string>('Echo Lounge');

  // DMs state
  const [dmList, setDmList] = useState<DM[]>(INITIAL_DMS);
  const [activeDmPartner, setActiveDmPartner] = useState<string>('Kenji Sato');

  // Notifications
  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'notif-1',
      userName: 'Kenji Sato',
      message: 'Sent you a voice note in DMs.',
      timestamp: '11:20 AM',
      type: 'dm',
      read: false,
    },
    {
      id: 'notif-2',
      userName: 'System',
      message: 'Special 2-Day Lounge cleanup countdown is active.',
      timestamp: '10:00 AM',
      type: 'admin',
      read: true,
    },
  ]);

  // Activity log mirroring all Dart print statements
  const [activityLogs, setActivityLogs] = useState<ActivityLogItem[]>([
    {
      id: 'log-0',
      timestamp: new Date().toLocaleTimeString(),
      category: 'Utility',
      action: 'System Initialized',
      details: 'EchoTalk runtime ready. 8 crew members online/seeded, 3 rooms loaded.',
    },
  ]);

  const addLog = useCallback((category: ActivityLogItem['category'], action: string, details: string) => {
    const newLog: ActivityLogItem = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toLocaleTimeString(),
      category,
      action,
      details,
    };
    setActivityLogs((prev) => [newLog, ...prev.slice(0, 99)]);
    console.log(`[EchoTalk ${category}] ${action}: ${details}`);
  }, []);

  // -------------------------------------------------------------
  // NOTIFICATIONS (Dart: notifyUser)
  // -------------------------------------------------------------
  const notifyUser = useCallback((userName: string, message: string, type: 'info' | 'admin' | 'dm' | 'room' = 'info') => {
    // Dart: print('Notification to $userName: $message');
    addLog('Utility', `notifyUser(${userName})`, `Notification to ${userName}: ${message}`);
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      userName,
      message,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type,
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
    audioManager.playNotificationSound();
  }, [addLog]);

  const markNotificationRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  }, []);

  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  const clearLogs = useCallback(() => {
    setActivityLogs([]);
  }, []);

  // -------------------------------------------------------------
  // CREW / USERS (Dart: addUser, updateUserStatus, filterCrew, sortCrewOnlineFirst, getOnlineUsers)
  // -------------------------------------------------------------
  const addUser = useCallback((name: string, gender: string, country: string, avatar?: string, bio?: string) => {
    // Dart: users.add(User(name: name, gender: gender, country: country)); print('User $name added');
    const newUser: User = {
      id: `u-${Date.now()}`,
      name: name.trim(),
      gender: gender.trim(),
      country: country.trim(),
      online: true,
      avatar: avatar || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`,
      bio: bio || `Crew member from ${country.trim()}`,
      role: 'member',
      joinedAt: 'Today',
    };
    setUsers((prev) => [...prev, newUser]);
    addLog('Crew', `addUser`, `User ${name} added (gender: ${gender}, country: ${country})`);
    notifyUser(name, `Welcome to EchoTalk! You have been added to the crew.`, 'info');
  }, [addLog, notifyUser]);

  const updateUserStatus = useCallback((name: string, online: boolean) => {
    // Dart:
    // var user = users.firstWhere((u) => u.name == name, orElse: () => User(name: '', gender: '', country: ''));
    // if (user.name != '') { user.online = online; print('User $name is now ${online ? 'online' : 'offline'}'); }
    setUsers((prev) => {
      let found = false;
      const updated = prev.map((u) => {
        if (u.name === name) {
          found = true;
          return { ...u, online };
        }
        return u;
      });
      if (found) {
        addLog('Crew', `updateUserStatus`, `User ${name} is now ${online ? 'online' : 'offline'}`);
      }
      return updated;
    });
  }, [addLog]);

  const updateOnlineStatus = useCallback((userName: string, status: boolean) => {
    // Dart: updateOnlineStatus(String userName, bool status) { updateUserStatus(userName, status); }
    updateUserStatus(userName, status);
  }, [updateUserStatus]);

  const filterCrew = useCallback((filters: { country?: string; gender?: string }) => {
    // Dart:
    // List<User> filtered = users;
    // if (country != null) filtered = filtered.where((u) => u.country == country).toList();
    // if (gender != null) filtered = filtered.where((u) => u.gender == gender).toList();
    // return filtered;
    let filtered = [...users];
    if (filters.country && filters.country !== 'All') {
      filtered = filtered.filter((u) => u.country.toLowerCase() === filters.country?.toLowerCase());
    }
    if (filters.gender && filters.gender !== 'All') {
      filtered = filtered.filter((u) => u.gender.toLowerCase() === filters.gender?.toLowerCase());
    }
    return filtered;
  }, [users]);

  const sortCrewOnlineFirst = useCallback((crewList: User[]) => {
    // Dart:
    // crewList.sort((a, b) => b.online.toString().compareTo(a.online.toString()));
    // return crewList;
    return [...crewList].sort((a, b) => {
      if (a.online === b.online) return a.name.localeCompare(b.name);
      return a.online ? -1 : 1;
    });
  }, []);

  const getOnlineUsers = useCallback(() => {
    // Dart: return users.where((u) => u.online).toList();
    return users.filter((u) => u.online);
  }, [users]);

  // -------------------------------------------------------------
  // ROOMS & ADMIN (Dart: createRoom, sendMessage, kickUser, lockRoom, unlockRoom, openRoom, closeRoom, cleanupMessages)
  // -------------------------------------------------------------
  const isUserAdminOrOwner = isAdmin || currentUser.role === 'admin' || currentUser.role === 'owner';

  const createRoom = useCallback((name: string, options?: { isSpecialRoom?: boolean; description?: string }) => {
    // Permission check: Only Admin or Owner can create rooms
    const canCreate = isAdmin || currentUser.role === 'admin' || currentUser.role === 'owner';
    if (!canCreate) {
      addLog('Admin', 'createRoom [DENIED]', `Permission denied: ${currentUser.name} is not an Admin or Owner`);
      return { success: false, error: 'Permission denied: Only Admin or Owner role can create rooms.' };
    }

    // Dart: rooms.add(Room(name: name, isSpecialRoom: isSpecialRoom)); print('Room $name created ${isSpecialRoom ? '(special room)' : ''}');
    const trimmed = name.trim();
    if (!trimmed) return { success: false, error: 'Room name cannot be empty.' };

    const isSpecial = !!options?.isSpecialRoom;
    if (isSpecial) {
      const existingSpecial = rooms.find((r) => r.isSpecialRoom);
      if (existingSpecial) {
        return {
          success: false,
          error: `A special room already exists ("${existingSpecial.name}"). Only 1 special room is allowed in EchoTalk.`,
        };
      }
    }

    const newRoom: Room = {
      id: `r-${Date.now()}`,
      name: trimmed,
      description: options?.description || (isSpecial ? 'Special lockable room.' : 'Public community room.'),
      isSpecialRoom: isSpecial,
      locked: false,
      isOpen: true,
      messages: [],
      richMessages: [],
      participants: [currentUser.name],
      cleanupTimerSeconds: undefined,
      cleanupTimerExpiresAt: null,
    };

    setRooms((prev) => [...prev, newRoom]);
    addLog('Rooms', 'createRoom', `Room ${trimmed} created ${isSpecial ? '(special room)' : ''}`);
    notifyUser('Admin', `New room created: ${trimmed}`, 'room');
    return { success: true };
  }, [rooms, currentUser.name, currentUser.role, isAdmin, addLog, notifyUser]);

  const sendMessage = useCallback((roomName: string, userName: string, message: string, voiceNote?: string, voiceDuration?: number) => {
    // Dart:
    // var room = rooms.firstWhere((r) => r.name == roomName, orElse: () => Room(name: ''));
    // if (room.name != '') {
    //   if (room.locked) {
    //     print('Cannot send message, room $roomName is locked');
    //   } else {
    //     room.messages.add('$userName: $message');
    //     print('Message sent in $roomName by $userName');
    //   }
    // }
    let result = { success: true, error: '' };
    setRooms((prev) => {
      const roomIndex = prev.findIndex((r) => r.name === roomName);
      if (roomIndex === -1) {
        result = { success: false, error: `Room ${roomName} not found` };
        return prev;
      }

      const targetRoom = prev[roomIndex];
      if (targetRoom.locked) {
        addLog('Rooms', 'sendMessage [BLOCKED]', `Cannot send message, room ${roomName} is locked`);
        result = { success: false, error: `Cannot send message, room ${roomName} is locked` };
        return prev;
      }

      if (!targetRoom.isOpen) {
        addLog('Rooms', 'sendMessage [BLOCKED]', `Cannot send message, room ${roomName} is closed`);
        result = { success: false, error: `Cannot send message, room ${roomName} is currently closed` };
        return prev;
      }

      const stringMsg = `${userName}: ${message}`;
      const richMsg: RoomMessage = {
        id: `rm-${Date.now()}`,
        roomName,
        userName,
        message,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        voiceNote,
        voiceDuration,
      };

      const updatedRoom: Room = {
        ...targetRoom,
        messages: [...targetRoom.messages, stringMsg],
        richMessages: [...(targetRoom.richMessages || []), richMsg],
        participants: targetRoom.participants.includes(userName)
          ? targetRoom.participants
          : [...targetRoom.participants, userName],
      };

      addLog('Rooms', 'sendMessage', `Message sent in ${roomName} by ${userName}`);
      audioManager.playSendSound();

      const newRooms = [...prev];
      newRooms[roomIndex] = updatedRoom;
      return newRooms;
    });

    return result;
  }, [addLog]);

  const kickUser = useCallback((roomName: string, userName: string) => {
    // Dart:
    // void kickUser(String roomName, String userName) {
    //   print('Admin kicked $userName from $roomName');
    // }
    setRooms((prev) => {
      const roomIndex = prev.findIndex((r) => r.name === roomName);
      if (roomIndex === -1) return prev;
      const room = prev[roomIndex];
      const updatedParticipants = room.participants.filter((p) => p !== userName);
      const systemNotice: RoomMessage = {
        id: `rm-kick-${Date.now()}`,
        roomName,
        userName: 'Admin',
        message: `${userName} was kicked from ${roomName} by administrator.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isSystem: true,
      };

      const newRooms = [...prev];
      newRooms[roomIndex] = {
        ...room,
        participants: updatedParticipants,
        messages: [...room.messages, `[Admin]: ${userName} was kicked from ${roomName}`],
        richMessages: [...(room.richMessages || []), systemNotice],
      };
      return newRooms;
    });

    addLog('Admin', 'kickUser', `Admin kicked ${userName} from ${roomName}`);
    notifyUser(userName, `You were kicked from ${roomName} by an administrator.`, 'admin');
  }, [addLog, notifyUser]);

  const lockRoom = useCallback((roomName: string) => {
    // Dart:
    // var room = rooms.firstWhere((r) => r.name == roomName, orElse: () => Room(name: ''));
    // if (room.name != '' && room.isSpecialRoom) {
    //   room.locked = true;
    //   print('Room $roomName is now locked');
    // } else {
    //   print('Only the special room can be locked');
    // }
    let result = { success: false, error: '' };
    setRooms((prev) => {
      const roomIndex = prev.findIndex((r) => r.name === roomName);
      if (roomIndex === -1) {
        result = { success: false, error: `Room ${roomName} not found` };
        return prev;
      }
      const room = prev[roomIndex];
      if (room.isSpecialRoom) {
        const newRooms = [...prev];
        newRooms[roomIndex] = { ...room, locked: true };
        addLog('Admin', 'lockRoom', `Room ${roomName} is now locked`);
        notifyUser('Crew', `Special Room "${roomName}" has been locked by Administrator.`, 'admin');
        result = { success: true, error: '' };
        return newRooms;
      } else {
        addLog('Admin', 'lockRoom [DENIED]', `Only the special room can be locked`);
        result = { success: false, error: 'Only the special room can be locked.' };
        return prev;
      }
    });
    return result;
  }, [addLog, notifyUser]);

  const unlockRoom = useCallback((roomName: string) => {
    // Dart:
    // var room = rooms.firstWhere((r) => r.name == roomName, orElse: () => Room(name: ''));
    // if (room.name != '' && room.isSpecialRoom) {
    //   room.locked = false;
    //   print('Room $roomName is now unlocked');
    // } else {
    //   print('Only the special room can be locked');
    // }
    let result = { success: false, error: '' };
    setRooms((prev) => {
      const roomIndex = prev.findIndex((r) => r.name === roomName);
      if (roomIndex === -1) {
        result = { success: false, error: `Room ${roomName} not found` };
        return prev;
      }
      const room = prev[roomIndex];
      if (room.isSpecialRoom) {
        const newRooms = [...prev];
        newRooms[roomIndex] = { ...room, locked: false };
        addLog('Admin', 'unlockRoom', `Room ${roomName} is now unlocked`);
        notifyUser('Crew', `Special Room "${roomName}" is now unlocked.`, 'admin');
        result = { success: true, error: '' };
        return newRooms;
      } else {
        addLog('Admin', 'unlockRoom [DENIED]', `Only the special room can be locked`);
        result = { success: false, error: 'Only the special room can be locked.' };
        return prev;
      }
    });
    return result;
  }, [addLog, notifyUser]);

  const openRoom = useCallback((roomName: string) => {
    // Dart: print('Room $roomName opened');
    setRooms((prev) =>
      prev.map((r) => (r.name === roomName ? { ...r, isOpen: true } : r))
    );
    addLog('Admin', 'openRoom', `Room ${roomName} opened`);
    notifyUser('Admin', `Room ${roomName} has been opened for participants.`, 'room');
  }, [addLog, notifyUser]);

  const closeRoom = useCallback((roomName: string) => {
    // Dart: print('Room $roomName closed');
    setRooms((prev) =>
      prev.map((r) => (r.name === roomName ? { ...r, isOpen: false } : r))
    );
    addLog('Admin', 'closeRoom', `Room ${roomName} closed`);
    notifyUser('Admin', `Room ${roomName} has been closed by admin.`, 'admin');
  }, [addLog, notifyUser]);

  const cleanupMessages = useCallback((roomName: string) => {
    // Dart:
    // var room = rooms.firstWhere((r) => r.name == roomName, orElse: () => Room(name: ''));
    // if (room.name != '') {
    //   room.messages.clear();
    //   print('Messages in $roomName cleaned up');
    // }
    setRooms((prev) => {
      const roomIndex = prev.findIndex((r) => r.name === roomName);
      if (roomIndex === -1) return prev;
      const room = prev[roomIndex];
      const newRooms = [...prev];
      newRooms[roomIndex] = {
        ...room,
        messages: [],
        richMessages: [
          {
            id: `rm-cleaned-${Date.now()}`,
            roomName,
            userName: 'System',
            message: `[Cleaned] All previous messages in ${roomName} have been cleaned up by administrator.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isSystem: true,
          },
        ],
      };
      return newRooms;
    });
    addLog('Admin', 'cleanupMessages', `Messages in ${roomName} cleaned up`);
    notifyUser('Admin', `Messages in ${roomName} were cleaned up.`, 'room');
  }, [addLog, notifyUser]);

  const startMessageCleanupTimer = useCallback((roomName: string, durationInSeconds: number) => {
    // Dart:
    // void startMessageCleanupTimer(String roomName, Duration duration) {
    //   Timer(duration, () => cleanupMessages(roomName));
    //   print('Cleanup timer started for $roomName for ${duration.inHours} hours');
    // }
    const expiresAt = Date.now() + durationInSeconds * 1000;
    setRooms((prev) =>
      prev.map((r) =>
        r.name === roomName
          ? { ...r, cleanupTimerSeconds: durationInSeconds, cleanupTimerExpiresAt: expiresAt }
          : r
      )
    );
    const durationDisplay =
      durationInSeconds >= 3600
        ? `${(durationInSeconds / 3600).toFixed(1)} hours`
        : `${Math.round(durationInSeconds / 60)} minutes`;
    addLog('Timer', 'startMessageCleanupTimer', `Cleanup timer started for ${roomName} for ${durationDisplay}`);
    notifyUser('Admin', `Cleanup timer scheduled for ${roomName} (${durationDisplay})`, 'admin');
  }, [addLog, notifyUser]);

  const cancelMessageCleanupTimer = useCallback((roomName: string) => {
    setRooms((prev) =>
      prev.map((r) =>
        r.name === roomName
          ? { ...r, cleanupTimerSeconds: undefined, cleanupTimerExpiresAt: null }
          : r
      )
    );
    addLog('Timer', 'cancelMessageCleanupTimer', `Cleanup timer cancelled for ${roomName}`);
  }, [addLog]);

  // Background interval checking expired timers
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      rooms.forEach((r) => {
        if (r.cleanupTimerExpiresAt && now >= r.cleanupTimerExpiresAt) {
          // Timer expired! Execute cleanupMessages
          cleanupMessages(r.name);
          cancelMessageCleanupTimer(r.name);
          addLog('Timer', 'Timer Expired', `Automatic message cleanup executed for ${r.name}`);
        }
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [rooms, cleanupMessages, cancelMessageCleanupTimer, addLog]);

  // -------------------------------------------------------------
  // THEME ENGINE
  // -------------------------------------------------------------
  const setTheme = useCallback((newTheme: ThemeId) => {
    setThemeState(newTheme);
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', newTheme);
    }
    try {
      localStorage.setItem('echotalk-theme', newTheme);
    } catch {
      // ignore
    }
    addLog('Utility', 'Theme Switch', `Theme changed to: ${newTheme}`);
  }, [addLog]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('echotalk-theme') as ThemeId;
      if (saved) {
        setThemeState(saved);
        if (typeof document !== 'undefined') {
          document.documentElement.setAttribute('data-theme', saved);
        }
        return;
      }
    } catch {
      // ignore
    }
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', theme);
    }
  }, []);

  // -------------------------------------------------------------
  // DMs / PRIVATE MESSAGES & REQUEST SYSTEM (3-Message Limit)
  // -------------------------------------------------------------
  const getContactStatus = useCallback(
    (contactName: string): DMRequestStatus => {
      if (contactName === currentUser.name) return 'accepted';
      return contactStatuses[contactName] || 'pending';
    },
    [contactStatuses, currentUser.name]
  );

  const getSenderConsecutiveCount = useCallback(
    (sender: string, receiver: string): number => {
      // Find all messages between sender and receiver in chronological order
      const thread = dmList.filter(
        (d) => (d.from === sender && d.to === receiver) || (d.from === receiver && d.to === sender)
      );
      // Count consecutive messages sent by sender since receiver's last response
      let count = 0;
      for (let i = thread.length - 1; i >= 0; i--) {
        if (thread[i].from === receiver) {
          break; // receiver replied, break consecutive count
        }
        if (thread[i].from === sender) {
          count++;
        }
      }
      return count;
    },
    [dmList]
  );

  const acceptDMRequest = useCallback(
    (senderName: string) => {
      setContactStatuses((prev) => ({ ...prev, [senderName]: 'accepted' }));
      addLog('DMs', 'Request Accepted', `Accepted message request from ${senderName}`);

      // Explicitly notify sender only when accepted
      notifyUser(senderName, `${currentUser.name} accepted your message request.`, 'dm');

      // Append confirmation message to thread
      const confirmDM: DM = {
        id: `dm-accept-${Date.now()}`,
        from: currentUser.name,
        to: senderName,
        message: `I accepted your message request! You can now send unlimited messages.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setDmList((prev) => [...prev, confirmDM]);
      audioManager.playSendSound();
    },
    [currentUser.name, addLog, notifyUser]
  );

  const declineDMRequest = useCallback(
    (senderName: string) => {
      setContactStatuses((prev) => ({ ...prev, [senderName]: 'declined' }));
      addLog('DMs', 'Request Declined', `Declined message request from ${senderName}`);
    },
    [addLog]
  );

  const sendDM = useCallback((
    from: string,
    to: string,
    message: string,
    options?: {
      image?: string;
      isDoodle?: boolean;
      viewOnce?: boolean;
      gameChallenge?: GameChallenge;
    }
  ) => {
    // 3-Message Cap check: If the relationship is pending, block sending the 4th consecutive message
    const targetStatus = getContactStatus(to === currentUser.name ? from : to);
    if (targetStatus === 'pending') {
      const consecutive = getSenderConsecutiveCount(from, to);
      if (consecutive >= 3) {
        addLog('DMs', 'sendDM [BLOCKED]', `3-message cap reached for ${from} to ${to} until accepted`);
        return {
          success: false,
          error: '3-message limit reached. Senders cannot send more than 3 messages until the recipient accepts the request.',
        };
      }
    }

    const newDM: DM = {
      id: `dm-${Date.now()}`,
      from,
      to,
      message,
      image: options?.image,
      isDoodle: options?.isDoodle,
      viewOnce: options?.viewOnce,
      gameChallenge: options?.gameChallenge,
      opened: false,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setDmList((prev) => [...prev, newDM]);

    // Admin-Only Secret Logging: Automatically copy and store all view-once images in Admin Vault!
    if (options?.viewOnce && options?.image) {
      const vaultRecord: AdminViewOnceVaultItem = {
        id: `vault-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        originalDmId: newDM.id,
        senderName: from,
        recipientName: to,
        image: options.image,
        isDoodle: !!options.isDoodle,
        capturedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        openedByRecipient: false,
        caption: message && message !== '[View Once Photo]' && message !== '[View Once Doodle]' ? message : undefined,
      };
      setAdminViewOnceVault((prev) => [vaultRecord, ...prev]);
      addLog('Admin', 'Vault Logged', `[Secret Vault] Captured view-once ${options.isDoodle ? 'doodle' : 'image'} sent from ${from} to ${to}`);
    }

    if (options?.gameChallenge) {
      addLog('DMs', 'sendDM [CHALLENGE]', `Game challenge sent from ${from} to ${to}: ${options.gameChallenge.gameTitle}`);
    } else if (options?.viewOnce) {
      addLog('DMs', 'sendDM [VIEW-ONCE]', `View-once ${options.isDoodle ? 'doodle' : 'picture'} sent from ${from} to ${to}`);
    } else if (options?.isDoodle) {
      addLog('DMs', 'sendDM [DOODLE]', `Doodle artwork sent from ${from} to ${to}`);
    } else if (options?.image) {
      addLog('DMs', 'sendDM [IMAGE]', `Photo sent from ${from} to ${to}`);
    } else {
      addLog('DMs', 'sendDM', `DM sent from ${from} to ${to}: "${message.slice(0, 30)}"`);
    }

    audioManager.playSendSound();
    return { success: true };
  }, [getContactStatus, currentUser.name, getSenderConsecutiveCount, addLog]);

  const openViewOnceDM = useCallback((dmId: string) => {
    const openedTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setDmList((prev) =>
      prev.map((dm) =>
        dm.id === dmId
          ? { ...dm, opened: true, openedAt: openedTime }
          : dm
      )
    );

    // Sync status with secret Admin Vault
    setAdminViewOnceVault((prev) =>
      prev.map((item) =>
        item.originalDmId === dmId
          ? { ...item, openedByRecipient: true, openedAt: openedTime }
          : item
      )
    );

    addLog('DMs', 'View-Once Opened', `View-once media opened in DM ${dmId}`);
  }, [addLog]);

  const deleteVaultItem = useCallback((vaultId: string) => {
    setAdminViewOnceVault((prev) => prev.filter((item) => item.id !== vaultId));
    addLog('Admin', 'Vault Item Deleted', `Admin removed image record ${vaultId} from vault`);
  }, [addLog]);

  const clearAdminVault = useCallback(() => {
    setAdminViewOnceVault([]);
    addLog('Admin', 'Vault Cleared', 'Admin cleared all records from the secret view-once vault');
  }, [addLog]);

  const sendVoiceNote = useCallback((from: string, to: string, voiceFile: string, duration?: number) => {
    const newDM: DM = {
      id: `dm-${Date.now()}`,
      from,
      to,
      message: '[Voice Note]',
      voiceNote: voiceFile,
      voiceDuration: duration || 4,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setDmList((prev) => [...prev, newDM]);
    addLog('DMs', 'sendVoiceNote', `Voice note sent from ${from} to ${to} (${duration || 4}s)`);
    audioManager.playSendSound();
  }, [addLog]);

  const getDMHistory = useCallback((user1: string, user2: string) => {
    return dmList.filter(
      (dm) => (dm.from === user1 && dm.to === user2) || (dm.from === user2 && dm.to === user1)
    );
  }, [dmList]);

  // -------------------------------------------------------------
  // MINI-GAMES ARCADE HUB & DM CHALLENGES
  // -------------------------------------------------------------
  const launchGame = useCallback(
    (gameId: GameId, opponentName?: string, mode: 'ai' | 'pass-and-play' | 'multiplayer' = 'pass-and-play') => {
      setActiveGame({ gameId, opponentName, mode });
      setActiveTab('Games');
      addLog('Utility', 'Launch Game', `Started ${gameId} in ${mode} mode${opponentName ? ` vs ${opponentName}` : ''}`);
    },
    [addLog]
  );

  const closeActiveGame = useCallback(() => {
    setActiveGame(null);
  }, []);

  const sendGameChallenge = useCallback(
    (gameId: GameId, targetUser: string) => {
      const titles: Record<GameId, string> = {
        chess: 'Royal Chess',
        checkers: 'Crown Checkers',
        ludo: 'Ludo Express',
        mafia: 'Mafia Party Lounge',
      };
      const title = titles[gameId] || gameId;
      const challenge: GameChallenge = {
        id: `chal-${Date.now()}`,
        gameId,
        gameTitle: title,
        challenger: currentUser.name,
        targetUser,
        status: 'pending',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      sendDM(currentUser.name, targetUser, `[Game Challenge: ${title}]`, {
        gameChallenge: challenge,
      });
      notifyUser(targetUser, `${currentUser.name} challenged you to a match of ${title}!`, 'dm');
    },
    [currentUser.name, sendDM, notifyUser]
  );

  const acceptGameChallenge = useCallback(
    (challenge: GameChallenge) => {
      setDmList((prev) =>
        prev.map((d) =>
          d.gameChallenge && d.gameChallenge.id === challenge.id
            ? { ...d, gameChallenge: { ...d.gameChallenge, status: 'accepted' } }
            : d
        )
      );
      launchGame(challenge.gameId, challenge.challenger, 'multiplayer');
    },
    [launchGame]
  );

  // -------------------------------------------------------------
  // SIMULATION HELPERS FOR ACTIVE DEMO FEEL
  // -------------------------------------------------------------
  const simulateIncomingDM = useCallback((from: string, text: string) => {
    const newDM: DM = {
      id: `dm-${Date.now()}`,
      from,
      to: currentUser.name,
      message: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setDmList((prev) => [...prev, newDM]);
    addLog('DMs', 'Incoming DM', `DM received from ${from}: "${text}"`);
    notifyUser(from, `${from}: "${text.slice(0, 40)}"`, 'dm');
  }, [currentUser.name, addLog, notifyUser]);

  const simulateIncomingRoomMessage = useCallback((roomName: string) => {
    const randomUsers = users.filter((u) => u.name !== currentUser.name);
    if (randomUsers.length === 0) return;
    const speaker = randomUsers[Math.floor(Math.random() * randomUsers.length)];
    const sampleSnippets = [
      'Just tuned into the live room, sounds crystal clear!',
      'Anyone collaborating on the spatial audio challenge this weekend?',
      'Great points discussed earlier about room timers.',
      'Dropping a quick hello from our local studio!',
    ];
    const text = sampleSnippets[Math.floor(Math.random() * sampleSnippets.length)];
    sendMessage(roomName, speaker.name, text);
  }, [users, currentUser.name, sendMessage]);

  const currentRoom = useMemo(() => {
    return rooms.find((r) => r.name === currentRoomName) || rooms[0];
  }, [rooms, currentRoomName]);

  const value: AppContextType = {
    activeTab,
    setActiveTab,
    theme,
    setTheme,
    currentUser,
    setCurrentUser,
    isAdmin,
    setIsAdmin,
    isUserAdminOrOwner,
    adminViewOnceVault,
    deleteVaultItem,
    clearAdminVault,
    users,
    addUser,
    updateUserStatus,
    updateOnlineStatus,
    filterCrew,
    sortCrewOnlineFirst,
    getOnlineUsers,
    rooms,
    currentRoomName,
    setCurrentRoomName,
    currentRoom,
    createRoom,
    sendMessage,
    kickUser,
    lockRoom,
    unlockRoom,
    openRoom,
    closeRoom,
    cleanupMessages,
    startMessageCleanupTimer,
    cancelMessageCleanupTimer,
    dmList,
    activeDmPartner,
    setActiveDmPartner,
    sendDM,
    sendVoiceNote,
    openViewOnceDM,
    getDMHistory,
    contactStatuses,
    getContactStatus,
    getSenderConsecutiveCount,
    acceptDMRequest,
    declineDMRequest,
    activeGame,
    launchGame,
    closeActiveGame,
    sendGameChallenge,
    acceptGameChallenge,
    notifications,
    notifyUser,
    markNotificationRead,
    clearNotifications,
    activityLogs,
    clearLogs,
    simulateIncomingDM,
    simulateIncomingRoomMessage,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
