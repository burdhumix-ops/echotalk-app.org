import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Send,
  Mic,
  Square,
  Sparkles,
  Search,
  MessageSquare,
  ArrowLeft,
  ChevronRight,
  Paintbrush,
  Image as ImageIcon,
  Swords,
  Check,
  X,
  AlertTriangle,
  Gamepad2,
  Clock,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AudioWaveform } from '../components/AudioWaveform';
import { UserAvatar } from '../components/UserAvatar';
import { DoodleCanvasModal } from '../components/DoodleCanvasModal';
import { ViewOnceModal } from '../components/ViewOnceModal';
import { VoiceRecorder } from '../utils/audio';
import { DM, User, GameId, GameChallenge } from '../types';

export const DMsScreen: React.FC = () => {
  const {
    currentUser,
    users,
    activeDmPartner,
    setActiveDmPartner,
    sendDM,
    sendVoiceNote,
    openViewOnceDM,
    getDMHistory,
    simulateIncomingDM,
    contactStatuses,
    getContactStatus,
    getSenderConsecutiveCount,
    acceptDMRequest,
    declineDMRequest,
    sendGameChallenge,
    acceptGameChallenge,
    launchGame,
  } = useApp();

  // Navigation & Tabs
  const [selectedPartnerName, setSelectedPartnerName] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<'messages' | 'requests'>('messages');
  const [messageText, setMessageText] = useState('');
  const [userSearch, setUserSearch] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordDuration, setRecordDuration] = useState(0);
  const [sendError, setSendError] = useState<string | null>(null);

  // Modals & Panels
  const [isDoodleModalOpen, setIsDoodleModalOpen] = useState(false);
  const [isPhotoPickerOpen, setIsPhotoPickerOpen] = useState(false);
  const [isSendViewOnce, setIsSendViewOnce] = useState(false);
  const [isGameChallengePickerOpen, setIsGameChallengePickerOpen] = useState(false);

  // Ephemeral media viewer
  const [viewingMedia, setViewingMedia] = useState<{
    id: string;
    src: string;
    senderName: string;
    isDoodle?: boolean;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const recorderRef = useRef<VoiceRecorder | null>(null);
  const recordIntervalRef = useRef<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Filter contacts (excluding current user)
  const conversationPartners = useMemo(() => {
    return users.filter((u) => u.name !== currentUser.name);
  }, [users, currentUser.name]);

  // Separate established conversations from unaccepted message requests
  const acceptedPartners = useMemo(() => {
    return conversationPartners.filter((u) => getContactStatus(u.name) === 'accepted');
  }, [conversationPartners, getContactStatus]);

  const requestPartners = useMemo(() => {
    return conversationPartners.filter((u) => getContactStatus(u.name) === 'pending');
  }, [conversationPartners, getContactStatus]);

  const displayedPartners = useMemo(() => {
    const list = activeSection === 'messages' ? acceptedPartners : requestPartners;
    if (!userSearch.trim()) return list;
    const q = userSearch.toLowerCase();
    return list.filter(
      (u) => u.name.toLowerCase().includes(q) || u.country.toLowerCase().includes(q)
    );
  }, [activeSection, acceptedPartners, requestPartners, userSearch]);

  const activePartnerUser: User | undefined = useMemo(() => {
    return users.find((u) => u.name === selectedPartnerName);
  }, [users, selectedPartnerName]);

  const partnerStatus = useMemo(() => {
    if (!activePartnerUser) return 'accepted';
    return getContactStatus(activePartnerUser.name);
  }, [activePartnerUser, getContactStatus]);

  // Count consecutive messages sent by partner or current user
  const partnerConsecutiveCount = useMemo(() => {
    if (!activePartnerUser) return 0;
    return getSenderConsecutiveCount(activePartnerUser.name, currentUser.name);
  }, [activePartnerUser, currentUser.name, getSenderConsecutiveCount]);

  const myConsecutiveCount = useMemo(() => {
    if (!activePartnerUser) return 0;
    return getSenderConsecutiveCount(currentUser.name, activePartnerUser.name);
  }, [activePartnerUser, currentUser.name, getSenderConsecutiveCount]);

  // Full history between current user and active partner
  const history: DM[] = useMemo(() => {
    if (!activePartnerUser) return [];
    return getDMHistory(currentUser.name, activePartnerUser.name);
  }, [getDMHistory, currentUser.name, activePartnerUser]);

  // Auto scroll
  useEffect(() => {
    if (activePartnerUser) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [history, activePartnerUser]);

  const handleOpenConversation = (partnerName: string) => {
    setActiveDmPartner(partnerName);
    setSelectedPartnerName(partnerName);
    setIsPhotoPickerOpen(false);
    setIsSendViewOnce(false);
    setIsGameChallengePickerOpen(false);
    setSendError(null);
  };

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !activePartnerUser) return;
    setSendError(null);

    const result = sendDM(currentUser.name, activePartnerUser.name, messageText.trim());
    if (!result.success) {
      setSendError(result.error || 'Failed to send message');
    } else {
      setMessageText('');
    }
  };

  const handleToggleRecord = async () => {
    if (!activePartnerUser) return;
    setSendError(null);

    if (isRecording) {
      if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
      if (recorderRef.current) {
        const result = await recorderRef.current.stop();
        if (result) {
          sendVoiceNote(currentUser.name, activePartnerUser.name, result.audioUrl, result.duration);
        }
      }
      setIsRecording(false);
      setRecordDuration(0);
    } else {
      const rec = new VoiceRecorder();
      recorderRef.current = rec;
      const started = await rec.start();
      if (started) {
        setIsRecording(true);
        setRecordDuration(0);
        recordIntervalRef.current = window.setInterval(() => {
          setRecordDuration((prev) => prev + 1);
        }, 1000);
      } else {
        sendVoiceNote(
          currentUser.name,
          activePartnerUser.name,
          `voice-note-${Date.now()}`,
          4
        );
      }
    }
  };

  const handleSendDoodle = (dataUrl: string, isViewOnce: boolean) => {
    if (!activePartnerUser) return;
    sendDM(
      currentUser.name,
      activePartnerUser.name,
      isViewOnce ? '[View Once Doodle]' : '[Doodle Artwork]',
      {
        image: dataUrl,
        isDoodle: true,
        viewOnce: isViewOnce,
      }
    );
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activePartnerUser) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        sendDM(
          currentUser.name,
          activePartnerUser.name,
          isSendViewOnce ? '[View Once Photo]' : '[Photo]',
          {
            image: reader.result,
            isDoodle: false,
            viewOnce: isSendViewOnce,
          }
        );
        setIsPhotoPickerOpen(false);
        setIsSendViewOnce(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSendPresetPhoto = (presetName: string, presetUrl: string) => {
    if (!activePartnerUser) return;
    sendDM(
      currentUser.name,
      activePartnerUser.name,
      isSendViewOnce ? `[View Once: ${presetName}]` : `[Photo: ${presetName}]`,
      {
        image: presetUrl,
        isDoodle: false,
        viewOnce: isSendViewOnce,
      }
    );
    setIsPhotoPickerOpen(false);
    setIsSendViewOnce(false);
  };

  const handleTriggerGameChallenge = (gameId: GameId) => {
    if (!activePartnerUser) return;
    sendGameChallenge(gameId, activePartnerUser.name);
    setIsGameChallengePickerOpen(false);
  };

  const handleSimulateReply = () => {
    if (!activePartnerUser) return;
    const replies = [
      `Hey ${currentUser.name}, transmission received! Audio and visuals are coming through great.`,
      `Love the vibe! Let's jump into a match in the Arcade Hub.`,
      `Got your message from ${activePartnerUser.country}. Let's test the special room soon!`,
    ];
    const pick = replies[Math.floor(Math.random() * replies.length)];
    simulateIncomingDM(activePartnerUser.name, pick);
  };

  const PRESET_PHOTOS = [
    { name: 'Analog Synth', url: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=500&auto=format&fit=crop&q=80' },
    { name: 'Studio Mic', url: 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=500&auto=format&fit=crop&q=80' },
    { name: 'Waveform Console', url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80' },
  ];

  const GAME_OPTIONS: Array<{ id: GameId; title: string; icon: string; desc: string }> = [
    { id: 'chess', title: 'Grandmaster Chess', icon: '♟️', desc: '8x8 classic legal move chess' },
    { id: 'checkers', title: 'Crown Checkers', icon: '👑', desc: 'Diagonal jumps & king piece crowns' },
    { id: 'ludo', title: 'Ludo Arena', icon: '🎲', desc: 'Dice race track to the center' },
    { id: 'mafia', title: 'Mafia Party Lounge', icon: '🕵️', desc: 'Party game with secret roles' },
  ];

  // =========================================================================
  // 1. 100% FULL-SCREEN DM CHAT VIEW
  // =========================================================================
  if (selectedPartnerName && activePartnerUser) {
    const isPending = partnerStatus === 'pending';
    const isInputBlocked = isPending && myConsecutiveCount >= 3;

    return (
      <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col h-dvh max-h-dvh w-screen overflow-hidden text-slate-100">
        {/* Top Header Bar */}
        <header className="shrink-0 h-16 px-3 sm:px-6 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-xl flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            {/* Back Button */}
            <button
              type="button"
              onClick={() => {
                setSelectedPartnerName(null);
                setIsPhotoPickerOpen(false);
                setIsGameChallengePickerOpen(false);
                setSendError(null);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 transition-all active:scale-95 shrink-0 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Back</span>
            </button>

            {/* Partner Avatar & Details */}
            <div className="flex items-center gap-2.5 min-w-0">
              <UserAvatar
                src={activePartnerUser.avatar}
                name={activePartnerUser.name}
                size="sm"
                online={activePartnerUser.online}
                showOnlineIndicator
              />
              <div className="min-w-0">
                <h1 className="text-xs sm:text-sm font-bold text-white truncate leading-none">
                  {activePartnerUser.name}
                </h1>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-1">
                  <span>{activePartnerUser.country}</span>
                  <span aria-hidden="true">·</span>
                  <span className={activePartnerUser.online ? 'text-emerald-400' : 'text-slate-500'}>
                    {activePartnerUser.online ? 'Online' : 'Offline'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Top Right Actions: Play Game Challenge & Simulate Reply */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Play Game Challenge Trigger */}
            <button
              type="button"
              onClick={() => setIsGameChallengePickerOpen(!isGameChallengePickerOpen)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-300 hover:text-white bg-amber-950/50 hover:bg-amber-900/60 border border-amber-800/50 rounded-xl transition-all active:scale-95 cursor-pointer"
              title="Challenge to a mini-game"
            >
              <Swords className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">⚔️ Play Game</span>
            </button>

            {/* Simulate Reply */}
            <button
              type="button"
              onClick={handleSimulateReply}
              className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-medium text-indigo-300 hover:text-white bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-800/50 rounded-xl transition-all active:scale-95 cursor-pointer"
              title="Simulate incoming reply"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">Simulate Reply</span>
            </button>
          </div>
        </header>

        {/* Message Request Review Banner (When status is pending) */}
        {isPending && (
          <div className="shrink-0 p-3 sm:p-4 bg-gradient-to-r from-indigo-950/90 via-slate-900/95 to-slate-950 border-b border-indigo-500/30 backdrop-blur-xl animate-in slide-in-from-top-2 duration-200">
            <div className="max-w-3xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 flex items-center justify-center shrink-0 mt-0.5">
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <span>Message Request from {activePartnerUser.name}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {partnerConsecutiveCount} of 3 messages sent
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Unknown senders are capped at 3 messages until you accept. Accepting notifies the sender and unblocks full messaging.
                  </p>
                </div>
              </div>

              {/* Explicit Accept / Decline Buttons */}
              <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                <button
                  type="button"
                  onClick={() => declineDMRequest(activePartnerUser.name)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-700 transition-all active:scale-95 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Decline</span>
                </button>
                <button
                  type="button"
                  onClick={() => acceptDMRequest(activePartnerUser.name)}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition-all active:scale-95 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Accept Request</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Game Challenge Selector Modal / Drawer */}
        {isGameChallengePickerOpen && (
          <div className="shrink-0 p-4 bg-slate-900/95 border-b border-slate-800 backdrop-blur-xl animate-in slide-in-from-top-2 duration-200">
            <div className="max-w-3xl mx-auto space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Gamepad2 className="w-4 h-4 text-amber-400" />
                  Challenge {activePartnerUser.name} to a Mini-Game
                </span>
                <button
                  type="button"
                  onClick={() => setIsGameChallengePickerOpen(false)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Close
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {GAME_OPTIONS.map((game) => (
                  <button
                    key={game.id}
                    type="button"
                    onClick={() => handleTriggerGameChallenge(game.id)}
                    className="p-3 bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/60 rounded-2xl text-left transition-all active:scale-95 flex flex-col justify-between cursor-pointer group shadow-sm"
                  >
                    <div>
                      <span className="text-2xl mb-1 block group-hover:scale-110 transition-transform">
                        {game.icon}
                      </span>
                      <span className="text-xs font-bold text-white block leading-tight">
                        {game.title}
                      </span>
                    </div>
                    <span className="text-[10px] text-amber-400 font-semibold mt-2">Send Invite ⚔️</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Pinned Scrollable Message Stream */}
        <div className="flex-1 min-h-0 overflow-y-auto px-4 md:px-8 py-6">
          <div className="max-w-3xl mx-auto space-y-4">
            {history.length === 0 ? (
              <div className="py-24 flex flex-col items-center justify-center text-center text-slate-500">
                <MessageSquare className="w-10 h-10 text-slate-600 mb-2 stroke-[1.5]" />
                <p className="text-sm font-medium text-slate-400">
                  Direct message thread with {activePartnerUser.name}
                </p>
                <p className="text-xs text-slate-500 mt-1 max-w-sm">
                  Send a text, record a voice note, draw a doodle, send a view-once photo, or challenge them to Chess/Checkers!
                </p>
              </div>
            ) : (
              history.map((dm) => {
                const isMe = dm.from === currentUser.name;

                return (
                  <div
                    key={dm.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <div className="flex items-center gap-2 mb-1 px-1 text-[11px]">
                      <span className="font-semibold text-slate-400">{isMe ? 'You' : dm.from}</span>
                      <span className="text-slate-600 font-mono">{dm.timestamp}</span>
                    </div>

                    {/* 1. Game Challenge Card */}
                    {dm.gameChallenge ? (
                      <div className="max-w-xs sm:max-w-sm p-4 rounded-3xl bg-gradient-to-br from-amber-950/60 via-slate-900 to-slate-950 border border-amber-500/40 shadow-xl backdrop-blur-md space-y-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-xl shrink-0">
                            {dm.gameChallenge.gameId === 'chess'
                              ? '♟️'
                              : dm.gameChallenge.gameId === 'checkers'
                              ? '👑'
                              : dm.gameChallenge.gameId === 'ludo'
                              ? '🎲'
                              : '🕵️'}
                          </div>
                          <div className="min-w-0">
                            <span className="text-xs font-bold text-white block truncate">
                              {dm.gameChallenge.gameTitle} Match
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              Challenged by {dm.gameChallenge.challenger}
                            </span>
                          </div>
                        </div>

                        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                          <span className="text-[10px] font-mono text-amber-400 uppercase font-semibold">
                            {dm.gameChallenge.status === 'accepted' ? 'Match In Progress' : 'Pending Challenge'}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              if (dm.gameChallenge) {
                                acceptGameChallenge(dm.gameChallenge);
                              }
                            }}
                            className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-md transition-all active:scale-95 cursor-pointer"
                          >
                            ⚔️ Play Now
                          </button>
                        </div>
                      </div>
                    ) : dm.voiceNote ? (
                      /* 2. Voice Note */
                      <div className="max-w-xs sm:max-w-sm">
                        <AudioWaveform
                          audioUrl={dm.voiceNote.startsWith('blob:') ? dm.voiceNote : undefined}
                          seed={dm.voiceNote}
                          duration={dm.voiceDuration || 4}
                          isSentByMe={isMe}
                          senderName={dm.from}
                        />
                      </div>
                    ) : dm.viewOnce ? (
                      /* 3. View-Once Media Capsule */
                      <div className="max-w-xs sm:max-w-sm">
                        {dm.opened ? (
                          <div
                            className={`flex items-center gap-2.5 px-4 py-2.5 rounded-2xl text-xs font-mono border ${
                              isMe
                                ? 'bg-indigo-950/40 border-indigo-800/40 text-indigo-300'
                                : 'bg-slate-900 border-slate-800 text-slate-400'
                            }`}
                          >
                            <div className="w-5 h-5 rounded-full border border-slate-700 flex items-center justify-center text-[10px] text-slate-500">
                              ✓
                            </div>
                            <div className="min-w-0">
                              <span className="font-semibold text-slate-300">
                                {dm.isDoodle ? 'Doodle' : 'Photo'} Opened
                              </span>
                              <span className="text-[10px] text-slate-500 block">
                                Disappeared · Viewed {dm.openedAt || ''}
                              </span>
                            </div>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              if (dm.image) {
                                setViewingMedia({
                                  id: dm.id,
                                  src: dm.image,
                                  senderName: dm.from,
                                  isDoodle: dm.isDoodle,
                                });
                              }
                            }}
                            className={`flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-medium border shadow-md transition-all active:scale-95 text-left group ${
                              isMe
                                ? 'bg-indigo-950/80 border-indigo-500/50 text-indigo-200 hover:bg-indigo-900/80'
                                : 'bg-slate-900 border-amber-500/50 text-amber-200 hover:bg-slate-850'
                            }`}
                          >
                            <div className="w-7 h-7 rounded-full bg-amber-400 text-slate-950 font-mono font-bold flex items-center justify-center text-xs shrink-0">
                              1
                            </div>
                            <div className="min-w-0">
                              <span className="font-semibold text-white block">
                                {dm.isDoodle ? 'View Once Doodle' : 'View Once Photo'}
                              </span>
                              <span className="text-[10px] text-slate-400 group-hover:text-slate-300 block">
                                Tap to view · Disappears after 1 viewing
                              </span>
                            </div>
                          </button>
                        )}
                      </div>
                    ) : dm.image ? (
                      /* 4. Regular Photo or Doodle */
                      <div
                        className={`p-2 rounded-2xl max-w-xs sm:max-w-sm border ${
                          isMe
                            ? 'bg-indigo-600/20 border-indigo-500/40'
                            : 'bg-slate-900 border-slate-800'
                        }`}
                      >
                        <img
                          src={dm.image}
                          alt={dm.isDoodle ? 'Doodle artwork' : 'Direct photo'}
                          className="w-full max-h-72 rounded-xl object-contain bg-slate-950"
                        />
                        {dm.message && dm.message !== '[Photo]' && dm.message !== '[Doodle Artwork]' && (
                          <p className="text-xs text-slate-200 mt-2 px-1">{dm.message}</p>
                        )}
                        <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mt-1.5 px-1">
                          <span>{dm.isDoodle ? '🎨 Doodle' : '📷 Photo'}</span>
                          <span>{dm.timestamp}</span>
                        </div>
                      </div>
                    ) : (
                      /* 5. Standard Text Bubble */
                      <div
                        className={`p-3.5 rounded-2xl text-xs leading-relaxed max-w-sm sm:max-w-md ${
                          isMe
                            ? 'bg-indigo-600 text-white rounded-tr-xs shadow-xs'
                            : 'bg-slate-900 text-slate-200 rounded-tl-xs border border-slate-800'
                        }`}
                      >
                        {dm.message}
                      </div>
                    )}
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Live Audio Recording Banner */}
        {isRecording && (
          <div className="shrink-0 px-4 py-2 bg-rose-950/80 border-t border-rose-800/60 flex items-center justify-between text-xs text-rose-300 animate-pulse">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span>Recording voice note... ({recordDuration}s)</span>
            </div>
            <button
              type="button"
              onClick={handleToggleRecord}
              className="font-medium hover:underline text-rose-200"
            >
              Finish & Send
            </button>
          </div>
        )}

        {/* Send Error Notice */}
        {sendError && (
          <div className="shrink-0 px-4 py-2.5 bg-rose-950/90 border-t border-rose-800 text-xs text-rose-200 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{sendError}</span>
            </div>
            <button
              type="button"
              onClick={() => setSendError(null)}
              className="text-xs text-rose-300 hover:text-white"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Picture Selection / View-Once Drawer */}
        {isPhotoPickerOpen && (
          <div className="shrink-0 p-4 bg-slate-900/95 border-t border-slate-800 text-xs animate-in slide-in-from-bottom-2 duration-150">
            <div className="max-w-3xl mx-auto space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white flex items-center gap-1.5">
                  <ImageIcon className="w-4 h-4 text-indigo-400" />
                  Send Photo
                </span>
                <button
                  type="button"
                  onClick={() => setIsSendViewOnce(!isSendViewOnce)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-semibold border transition-all ${
                    isSendViewOnce
                      ? 'bg-amber-400 text-slate-950 border-amber-300 font-bold shadow-xs'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="w-4 h-4 rounded-full bg-amber-400/30 text-amber-950 flex items-center justify-center font-mono text-[10px] font-bold">
                    1
                  </span>
                  <span>{isSendViewOnce ? 'View Once: Enabled' : 'View Once: Off'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 rounded-xl text-center flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer"
                >
                  <ImageIcon className="w-5 h-5 text-indigo-400" />
                  <span className="text-[11px] font-medium text-slate-300">Upload Image</span>
                </button>

                {PRESET_PHOTOS.map((preset) => (
                  <button
                    key={preset.name}
                    type="button"
                    onClick={() => handleSendPresetPhoto(preset.name, preset.url)}
                    className="group relative h-16 rounded-xl overflow-hidden border border-slate-800 text-left transition-all hover:border-indigo-500 cursor-pointer"
                  >
                    <img
                      src={preset.url}
                      alt={preset.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-1.5">
                      <span className="text-[10px] font-semibold text-white leading-tight">
                        {preset.name}
                      </span>
                    </div>
                  </button>
                ))}
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          </div>
        )}

        {/* Pinned Message Composer Bar */}
        <div className="shrink-0 p-3 sm:p-4 border-t border-slate-800/80 bg-slate-950/95 backdrop-blur-xl">
          <div className="max-w-3xl mx-auto">
            {isInputBlocked ? (
              <div className="p-3 rounded-2xl bg-slate-900 border border-amber-500/40 text-center text-xs text-amber-300 font-medium flex items-center justify-center gap-2">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  3-message limit reached. Awaiting acceptance from {activePartnerUser.name} before sending more messages.
                </span>
              </div>
            ) : (
              <form onSubmit={handleSendText} className="flex items-center gap-2">
                {/* Voice Note Button */}
                <button
                  type="button"
                  onClick={handleToggleRecord}
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 transition-all active:scale-95 cursor-pointer ${
                    isRecording
                      ? 'bg-rose-600 hover:bg-rose-500 text-white animate-bounce'
                      : 'bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white'
                  }`}
                  title={isRecording ? 'Finish & send voice note' : 'Record voice note'}
                >
                  {isRecording ? <Square className="w-4 h-4 fill-current" /> : <Mic className="w-4 h-4" />}
                </button>

                {/* Doodle Maker Button */}
                <button
                  type="button"
                  onClick={() => setIsDoodleModalOpen(true)}
                  className="w-11 h-11 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-indigo-400 hover:text-indigo-300 flex items-center justify-center shrink-0 transition-all active:scale-95 cursor-pointer"
                  title="Open Doodle Canvas"
                >
                  <Paintbrush className="w-4 h-4" />
                </button>

                {/* Photo / View-Once Button */}
                <button
                  type="button"
                  onClick={() => setIsPhotoPickerOpen(!isPhotoPickerOpen)}
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 transition-all active:scale-95 border cursor-pointer ${
                    isPhotoPickerOpen
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-slate-900 hover:bg-slate-850 border-slate-800 text-slate-300 hover:text-white'
                  }`}
                  title="Send photo or view-once image"
                >
                  <ImageIcon className="w-4 h-4" />
                </button>

                {/* Message Input */}
                <input
                  type="text"
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder={`Message ${activePartnerUser.name}...`}
                  className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-2xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />

                {/* Send Button */}
                <button
                  type="submit"
                  disabled={!messageText.trim()}
                  className="w-11 h-11 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:pointer-events-none text-white flex items-center justify-center shrink-0 transition-all active:scale-95 cursor-pointer shadow-sm"
                  aria-label="Send direct message"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* In-App Doodle Canvas Modal */}
        <DoodleCanvasModal
          isOpen={isDoodleModalOpen}
          onClose={() => setIsDoodleModalOpen(false)}
          onSendDoodle={handleSendDoodle}
          recipientName={activePartnerUser.name}
        />

        {/* Ephemeral View-Once Modal */}
        {viewingMedia && (
          <ViewOnceModal
            isOpen={true}
            onClose={() => setViewingMedia(null)}
            imageSrc={viewingMedia.src}
            senderName={viewingMedia.senderName}
            isDoodle={viewingMedia.isDoodle}
            onViewed={() => {
              openViewOnceDM(viewingMedia.id);
            }}
          />
        )}
      </div>
    );
  }

  // =========================================================================
  // 2. CONTACTS LIST PAGE & MESSAGE REQUESTS TAB
  // =========================================================================
  return (
    <div className="w-full max-w-4xl mx-auto px-4 md:px-6 py-6 pb-28 md:pb-16 animate-in fade-in duration-200">
      {/* Header and Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">Direct Messages</h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span className="font-mono text-indigo-400 tabular-nums">
              {acceptedPartners.length} Active Chats
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-amber-400 tabular-nums">
              {requestPartners.length} Message Requests
            </span>
            <span aria-hidden="true">·</span>
            <span>Arcade Challenges</span>
          </div>
        </div>
      </div>

      {/* Segmented iOS Toggle: Messages vs Requests */}
      <div className="p-1 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-1 mb-5 max-w-md shadow-inner">
        <button
          type="button"
          onClick={() => setActiveSection('messages')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSection === 'messages'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Chats ({acceptedPartners.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveSection('requests')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeSection === 'requests'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Requests</span>
          {requestPartners.length > 0 && (
            <span
              className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono font-black ${
                activeSection === 'requests' ? 'bg-white text-indigo-700' : 'bg-amber-400 text-slate-950'
              }`}
            >
              {requestPartners.length}
            </span>
          )}
        </button>
      </div>

      {/* Search Input */}
      <div className="relative mb-5">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          value={userSearch}
          onChange={(e) => setUserSearch(e.target.value)}
          placeholder={
            activeSection === 'messages'
              ? 'Search active chats by name or country...'
              : 'Search pending message requests...'
          }
          className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-2xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
        />
      </div>

      {/* Clean Contacts List */}
      <div className="space-y-3">
        {displayedPartners.length === 0 ? (
          <div className="py-16 text-center bg-slate-900/40 border border-slate-800/60 rounded-3xl text-xs text-slate-500">
            {activeSection === 'messages'
              ? `No active chats found matching "${userSearch}".`
              : 'No pending message requests right now.'}
          </div>
        ) : (
          displayedPartners.map((partner) => {
            const partnerHistory = getDMHistory(currentUser.name, partner.name);
            const lastMessage = partnerHistory[partnerHistory.length - 1];
            const isRequest = activeSection === 'requests';
            const consecutiveCount = getSenderConsecutiveCount(partner.name, currentUser.name);

            return (
              <div
                key={partner.id}
                onClick={() => handleOpenConversation(partner.name)}
                className="group p-4 bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-3xl cursor-pointer transition-all duration-150 flex items-center justify-between gap-4 shadow-sm"
              >
                {/* Left: Avatar & Contact Info */}
                <div className="flex items-center gap-3.5 min-w-0">
                  <UserAvatar
                    src={partner.avatar}
                    name={partner.name}
                    size="md"
                    online={partner.online}
                    showOnlineIndicator
                  />

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-semibold text-white group-hover:text-indigo-400 transition-colors truncate">
                        {partner.name}
                      </h2>
                      {partner.online && (
                        <span className="w-2 h-2 rounded-full bg-emerald-500" title="Online" />
                      )}
                      {isRequest && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          {consecutiveCount} of 3 msgs
                        </span>
                      )}
                    </div>

                    {/* Metadata snippet */}
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                      <span className="truncate max-w-[200px] sm:max-w-md">
                        {lastMessage ? (
                          lastMessage.gameChallenge ? (
                            <span className="text-amber-400 font-semibold">
                              ⚔️ {lastMessage.gameChallenge.gameTitle} Challenge
                            </span>
                          ) : lastMessage.viewOnce ? (
                            <span className="text-amber-400 font-mono">
                              {lastMessage.opened ? '✓ Viewed Ephemeral Media' : '📷 1 View Once Media'}
                            </span>
                          ) : lastMessage.isDoodle ? (
                            <span className="text-indigo-400 font-medium">🎨 Doodle Artwork</span>
                          ) : lastMessage.voiceNote ? (
                            <span className="text-indigo-400 font-medium">🎤 Voice Note</span>
                          ) : (
                            lastMessage.message
                          )
                        ) : (
                          `${partner.country} · ${partner.gender}`
                        )}
                      </span>
                      {lastMessage && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono text-slate-500 text-[10px] shrink-0">
                            {lastMessage.timestamp}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right: Action Area */}
                <div className="flex items-center gap-2 shrink-0">
                  {isRequest ? (
                    <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                      <button
                        type="button"
                        onClick={() => declineDMRequest(partner.name)}
                        className="px-2.5 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 text-xs font-semibold transition-all active:scale-95 cursor-pointer"
                        title="Decline request"
                      >
                        Decline
                      </button>
                      <button
                        type="button"
                        onClick={() => acceptDMRequest(partner.name)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-sm"
                        title="Accept request"
                      >
                        Accept
                      </button>
                    </div>
                  ) : (
                    <div className="w-8 h-8 rounded-xl bg-slate-950 border border-slate-800 group-hover:border-indigo-500/50 flex items-center justify-center text-slate-400 group-hover:text-indigo-400 transition-colors">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
