import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Gamepad2,
  Trophy,
  Swords,
  RotateCcw,
  Bot,
  User as UserIcon,
  Users,
  ChevronLeft,
  Sparkles,
  Volume2,
  Shield,
  Search,
  Eye,
  EyeOff,
  Dice5,
  Crown,
  Play,
  Flame,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GameId, GameChallenge } from '../types';
import { audioManager } from '../utils/audio';

// =========================================================================
// 1. CHESS IMPLEMENTATION
// =========================================================================

type PieceColor = 'w' | 'b';
type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';

interface ChessPiece {
  color: PieceColor;
  type: PieceType;
  hasMoved?: boolean;
}

type ChessBoard = (ChessPiece | null)[][];

const PIECE_SYMBOLS: Record<PieceColor, Record<PieceType, string>> = {
  w: { p: '♙', n: '♘', b: '♗', r: '♖', q: '♕', k: '♔' },
  b: { p: '♟', n: '♞', b: '♝', r: '♜', q: '♛', k: '♚' },
};

function createInitialChessBoard(): ChessBoard {
  const board: ChessBoard = Array(8)
    .fill(null)
    .map(() => Array(8).fill(null));

  const backRow: PieceType[] = ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'];

  // Black pieces (top: rows 0 and 1)
  for (let c = 0; c < 8; c++) {
    board[0][c] = { color: 'b', type: backRow[c] };
    board[1][c] = { color: 'b', type: 'p' };
  }

  // White pieces (bottom: rows 6 and 7)
  for (let c = 0; c < 8; c++) {
    board[6][c] = { color: 'w', type: 'p' };
    board[7][c] = { color: 'w', type: backRow[c] };
  }

  return board;
}

function getValidChessMoves(r: number, c: number, board: ChessBoard): [number, number][] {
  const piece = board[r][c];
  if (!piece) return [];
  const moves: [number, number][] = [];
  const color = piece.color;
  const oppColor = color === 'w' ? 'b' : 'w';

  const inBounds = (row: number, col: number) => row >= 0 && row < 8 && col >= 0 && col < 8;

  if (piece.type === 'p') {
    const dir = color === 'w' ? -1 : 1;
    const startRow = color === 'w' ? 6 : 1;
    // 1 step forward
    if (inBounds(r + dir, c) && !board[r + dir][c]) {
      moves.push([r + dir, c]);
      // 2 steps forward from start
      if (r === startRow && inBounds(r + 2 * dir, c) && !board[r + 2 * dir][c]) {
        moves.push([r + 2 * dir, c]);
      }
    }
    // Diagonal captures
    [-1, 1].forEach((dc) => {
      const nr = r + dir;
      const nc = c + dc;
      if (inBounds(nr, nc) && board[nr][nc]?.color === oppColor) {
        moves.push([nr, nc]);
      }
    });
  } else if (piece.type === 'n') {
    const jumps = [
      [-2, -1], [-2, 1], [-1, -2], [-1, 2],
      [1, -2], [1, 2], [2, -1], [2, 1],
    ];
    jumps.forEach(([dr, dc]) => {
      const nr = r + dr;
      const nc = c + dc;
      if (inBounds(nr, nc) && board[nr][nc]?.color !== color) {
        moves.push([nr, nc]);
      }
    });
  } else if (piece.type === 'k') {
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nr = r + dr;
        const nc = c + dc;
        if (inBounds(nr, nc) && board[nr][nc]?.color !== color) {
          moves.push([nr, nc]);
        }
      }
    }
  } else {
    // Ray pieces: rook, bishop, queen
    const dirs: [number, number][] = [];
    if (piece.type === 'r' || piece.type === 'q') {
      dirs.push([-1, 0], [1, 0], [0, -1], [0, 1]);
    }
    if (piece.type === 'b' || piece.type === 'q') {
      dirs.push([-1, -1], [-1, 1], [1, -1], [1, 1]);
    }

    dirs.forEach(([dr, dc]) => {
      let step = 1;
      while (true) {
        const nr = r + dr * step;
        const nc = c + dc * step;
        if (!inBounds(nr, nc)) break;
        if (!board[nr][nc]) {
          moves.push([nr, nc]);
        } else {
          if (board[nr][nc]?.color === oppColor) {
            moves.push([nr, nc]);
          }
          break;
        }
        step++;
      }
    });
  }

  return moves;
}

const ChessGameComponent: React.FC<{
  mode: 'ai' | 'pass-and-play' | 'multiplayer';
  opponentName?: string;
  onExit: () => void;
}> = ({ mode, opponentName, onExit }) => {
  const [board, setBoard] = useState<ChessBoard>(createInitialChessBoard);
  const [turn, setTurn] = useState<PieceColor>('w');
  const [selectedSquare, setSelectedSquare] = useState<[number, number] | null>(null);
  const [capturedWhite, setCapturedWhite] = useState<ChessPiece[]>([]);
  const [capturedBlack, setCapturedBlack] = useState<ChessPiece[]>([]);
  const [moveHistory, setMoveHistory] = useState<string[]>([]);
  const [isBotThinking, setIsBotThinking] = useState(false);
  const [winner, setWinner] = useState<string | null>(null);

  const validMoves = useMemo(() => {
    if (!selectedSquare) return [];
    return getValidChessMoves(selectedSquare[0], selectedSquare[1], board);
  }, [selectedSquare, board]);

  // Bot move for Black in AI mode
  useEffect(() => {
    if (mode === 'ai' && turn === 'b' && !winner) {
      setIsBotThinking(true);
      const timer = setTimeout(() => {
        // Collect all possible moves for Black
        const allMoves: { from: [number, number]; to: [number, number]; score: number }[] = [];
        for (let r = 0; r < 8; r++) {
          for (let c = 0; c < 8; c++) {
            if (board[r][c]?.color === 'b') {
              const moves = getValidChessMoves(r, c, board);
              moves.forEach((to) => {
                let score = 0;
                const destPiece = board[to[0]][to[1]];
                if (destPiece) {
                  // Capture value
                  const values: Record<PieceType, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 100 };
                  score += values[destPiece.type] * 10;
                }
                // Prefer advancing pawns & central control
                if (to[0] >= 3 && to[0] <= 4 && to[1] >= 2 && to[1] <= 5) score += 2;
                allMoves.push({ from: [r, c], to, score });
              });
            }
          }
        }

        if (allMoves.length === 0) {
          setWinner('White');
          setIsBotThinking(false);
          return;
        }

        // Sort by score and pick best or random high
        allMoves.sort((a, b) => b.score - a.score);
        const topBucket = allMoves.slice(0, Math.min(3, allMoves.length));
        const chosen = topBucket[Math.floor(Math.random() * topBucket.length)];

        // Execute bot move
        const newBoard = board.map((row) => [...row]);
        const movingPiece = newBoard[chosen.from[0]][chosen.from[1]]!;
        const destPiece = newBoard[chosen.to[0]][chosen.to[1]];

        if (destPiece) {
          setCapturedWhite((prev) => [...prev, destPiece]);
          if (destPiece.type === 'k') {
            setWinner('Black');
          }
        }

        // Pawn promotion to Queen at rank 7
        if (movingPiece.type === 'p' && chosen.to[0] === 7) {
          movingPiece.type = 'q';
        }

        newBoard[chosen.to[0]][chosen.to[1]] = movingPiece;
        newBoard[chosen.from[0]][chosen.from[1]] = null;

        setBoard(newBoard);
        setTurn('w');
        setMoveHistory((prev) => [
          ...prev,
          `b: ${movingPiece.type.toUpperCase()}${String.fromCharCode(97 + chosen.to[1])}${8 - chosen.to[0]}`,
        ]);
        audioManager.playSendSound();
        setIsBotThinking(false);
      }, 500);

      return () => clearTimeout(timer);
    }
  }, [mode, turn, board, winner]);

  const handleSquareClick = (r: number, c: number) => {
    if (winner || isBotThinking) return;
    if (mode === 'ai' && turn === 'b') return; // wait for bot

    if (selectedSquare) {
      const [sr, sc] = selectedSquare;
      const isMoveTarget = validMoves.some(([mr, mc]) => mr === r && mc === c);

      if (isMoveTarget) {
        // Execute move
        const newBoard = board.map((row) => [...row]);
        const movingPiece = newBoard[sr][sc]!;
        const destPiece = newBoard[r][c];

        if (destPiece) {
          if (destPiece.color === 'w') {
            setCapturedWhite((prev) => [...prev, destPiece]);
          } else {
            setCapturedBlack((prev) => [...prev, destPiece]);
          }
          if (destPiece.type === 'k') {
            setWinner(movingPiece.color === 'w' ? 'White' : 'Black');
          }
        }

        // Pawn promotion to Queen at rank 0 or 7
        if (movingPiece.type === 'p' && (r === 0 || r === 7)) {
          movingPiece.type = 'q';
        }

        newBoard[r][c] = movingPiece;
        newBoard[sr][sc] = null;

        setBoard(newBoard);
        setSelectedSquare(null);
        setTurn(turn === 'w' ? 'b' : 'w');
        setMoveHistory((prev) => [
          ...prev,
          `${movingPiece.color}: ${movingPiece.type.toUpperCase()}${String.fromCharCode(97 + c)}${8 - r}`,
        ]);
        audioManager.playSendSound();
        return;
      }
    }

    // Select piece
    const piece = board[r][c];
    if (piece && piece.color === turn) {
      setSelectedSquare([r, c]);
    } else {
      setSelectedSquare(null);
    }
  };

  const resetGame = () => {
    setBoard(createInitialChessBoard());
    setTurn('w');
    setSelectedSquare(null);
    setCapturedWhite([]);
    setCapturedBlack([]);
    setMoveHistory([]);
    setWinner(null);
    setIsBotThinking(false);
  };

  return (
    <div className="flex flex-col items-center max-w-4xl mx-auto w-full px-2 sm:px-4 py-4 animate-in fade-in duration-200">
      {/* Game Header Bar */}
      <div className="w-full flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
        <button
          type="button"
          onClick={onExit}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition-all active:scale-95 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Arcade Hub</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs">
            <span
              className={`w-2.5 h-2.5 rounded-full ${turn === 'w' ? 'bg-amber-400 ring-2 ring-amber-400/30' : 'bg-indigo-400 ring-2 ring-indigo-400/30'}`}
            />
            <span className="font-semibold text-white">
              {turn === 'w' ? 'White Turn' : mode === 'ai' ? 'EchoBot (Black)' : 'Black Turn'}
            </span>
            {isBotThinking && <span className="text-[10px] text-indigo-400 animate-pulse font-mono">Thinking...</span>}
          </div>
        </div>

        <button
          type="button"
          onClick={resetGame}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition-all active:scale-95 cursor-pointer"
          title="Restart match"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Reset</span>
        </button>
      </div>

      {/* Opponent Info & Captured Cemetery */}
      <div className="w-full max-w-[420px] flex items-center justify-between px-2 mb-2 text-xs">
        <div className="flex items-center gap-2">
          {mode === 'ai' ? (
            <div className="flex items-center gap-1.5 text-indigo-300 font-medium">
              <Bot className="w-4 h-4 text-indigo-400" />
              <span>EchoBot AI</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-slate-300 font-medium">
              <UserIcon className="w-4 h-4 text-slate-400" />
              <span>{opponentName || 'Player 2 (Black)'}</span>
            </div>
          )}
        </div>
        {/* Captured White pieces by Black */}
        <div className="flex items-center gap-1 text-sm font-serif min-h-[22px]">
          {capturedWhite.map((p, i) => (
            <span key={i} className="text-slate-300 drop-shadow">
              {PIECE_SYMBOLS.w[p.type]}
            </span>
          ))}
        </div>
      </div>

      {/* 8x8 Chessboard */}
      <div className="relative p-2.5 sm:p-3.5 rounded-2xl bg-slate-900/90 border border-slate-700/60 shadow-2xl backdrop-blur-md">
        <div className="grid grid-cols-8 grid-rows-8 w-[320px] h-[320px] sm:w-[380px] sm:h-[380px] rounded-xl overflow-hidden border border-slate-700 shadow-inner">
          {board.map((row, r) =>
            row.map((piece, c) => {
              const isDark = (r + c) % 2 === 1;
              const isSelected = selectedSquare?.[0] === r && selectedSquare?.[1] === c;
              const isTarget = validMoves.some(([mr, mc]) => mr === r && mc === c);

              return (
                <button
                  key={`${r}-${c}`}
                  type="button"
                  onClick={() => handleSquareClick(r, c)}
                  className={`relative flex items-center justify-center select-none cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-amber-400/40 ring-2 ring-amber-400 inset-0 z-10'
                      : isDark
                      ? 'bg-slate-800/90 hover:bg-slate-700/80'
                      : 'bg-slate-700/40 hover:bg-slate-600/50'
                  }`}
                >
                  {/* Valid move indicator dot or ring */}
                  {isTarget && (
                    <div
                      className={`absolute rounded-full pointer-events-none z-10 ${
                        piece ? 'w-full h-full ring-4 ring-rose-500/80' : 'w-3 h-3 bg-emerald-400/90 shadow-lg animate-pulse'
                      }`}
                    />
                  )}

                  {/* Piece Symbol */}
                  {piece && (
                    <span
                      className={`text-2xl sm:text-3xl leading-none select-none transition-transform duration-100 ${
                        piece.color === 'w' ? 'text-amber-100 drop-shadow-md' : 'text-slate-950 font-bold drop-shadow'
                      } ${isSelected ? 'scale-115' : 'hover:scale-105'}`}
                      style={{
                        WebkitTextStroke: piece.color === 'b' ? '0.8px rgba(255,255,255,0.7)' : '0.5px rgba(0,0,0,0.4)',
                      }}
                    >
                      {PIECE_SYMBOLS[piece.color][piece.type]}
                    </span>
                  )}

                  {/* Board Coordinates on edges */}
                  {c === 0 && (
                    <span className="absolute top-0.5 left-1 text-[9px] font-mono font-bold text-slate-500/70 pointer-events-none">
                      {8 - r}
                    </span>
                  )}
                  {r === 7 && (
                    <span className="absolute bottom-0.5 right-1 text-[9px] font-mono font-bold text-slate-500/70 pointer-events-none">
                      {String.fromCharCode(97 + c)}
                    </span>
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Current Player (White) Info & Captured Black Cemetery */}
      <div className="w-full max-w-[420px] flex items-center justify-between px-2 mt-2 text-xs">
        <div className="flex items-center gap-1.5 text-amber-300 font-medium">
          <UserIcon className="w-4 h-4 text-amber-400" />
          <span>You (White)</span>
        </div>
        <div className="flex items-center gap-1 text-sm font-serif min-h-[22px]">
          {capturedBlack.map((p, i) => (
            <span key={i} className="text-slate-900 drop-shadow" style={{ WebkitTextStroke: '0.5px #fff' }}>
              {PIECE_SYMBOLS.b[p.type]}
            </span>
          ))}
        </div>
      </div>

      {/* Winner Overlay Modal */}
      {winner && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-700 text-center max-w-sm w-full space-y-4 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center mx-auto">
              <Trophy className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">{winner} Checkmate & Victory!</h3>
              <p className="text-xs text-slate-400 mt-1">
                {winner === 'White' ? 'Outstanding game! White secured the win.' : 'Black claimed checkmate!'}
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={resetGame}
                className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all active:scale-95 cursor-pointer"
              >
                Rematch
              </button>
              <button
                type="button"
                onClick={onExit}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-all active:scale-95 cursor-pointer"
              >
                Exit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// =========================================================================
// 2. CHECKERS IMPLEMENTATION
// =========================================================================

interface CheckerPiece {
  color: 'red' | 'black';
  isKing: boolean;
}

type CheckersBoard = (CheckerPiece | null)[][];

function createInitialCheckersBoard(): CheckersBoard {
  const board: CheckersBoard = Array(8)
    .fill(null)
    .map(() => Array(8).fill(null));

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if ((r + c) % 2 === 1) {
        if (r < 3) {
          board[r][c] = { color: 'black', isKing: false };
        } else if (r > 4) {
          board[r][c] = { color: 'red', isKing: false };
        }
      }
    }
  }
  return board;
}

const CheckersGameComponent: React.FC<{
  mode: 'ai' | 'pass-and-play' | 'multiplayer';
  opponentName?: string;
  onExit: () => void;
}> = ({ mode, opponentName, onExit }) => {
  const [board, setBoard] = useState<CheckersBoard>(createInitialCheckersBoard);
  const [turn, setTurn] = useState<'red' | 'black'>('red');
  const [selected, setSelected] = useState<[number, number] | null>(null);
  const [winner, setWinner] = useState<string | null>(null);

  const inBounds = (r: number, c: number) => r >= 0 && r < 8 && c >= 0 && c < 8;

  // Calculate valid moves for selected piece
  const validMoves = useMemo(() => {
    if (!selected) return [];
    const [r, c] = selected;
    const piece = board[r][c];
    if (!piece) return [];

    const moves: { to: [number, number]; jumpOver?: [number, number] }[] = [];
    const dirs: [number, number][] = [];

    if (piece.color === 'red' || piece.isKing) {
      dirs.push([-1, -1], [-1, 1]); // up
    }
    if (piece.color === 'black' || piece.isKing) {
      dirs.push([1, -1], [1, 1]); // down
    }

    dirs.forEach(([dr, dc]) => {
      const nr = r + dr;
      const nc = c + dc;
      if (inBounds(nr, nc)) {
        if (!board[nr][nc]) {
          moves.push({ to: [nr, nc] });
        } else if (board[nr][nc]?.color !== piece.color) {
          // Check jump
          const jr = nr + dr;
          const jc = nc + dc;
          if (inBounds(jr, jc) && !board[jr][jc]) {
            moves.push({ to: [jr, jc], jumpOver: [nr, nc] });
          }
        }
      }
    });

    return moves;
  }, [selected, board]);

  // AI Move for Black
  useEffect(() => {
    if (mode === 'ai' && turn === 'black' && !winner) {
      const timer = setTimeout(() => {
        // Collect all possible moves for Black
        const allMoves: { from: [number, number]; to: [number, number]; jumpOver?: [number, number]; isJump: boolean }[] = [];
        for (let r = 0; r < 8; r++) {
          for (let c = 0; c < 8; c++) {
            if (board[r][c]?.color === 'black') {
              const piece = board[r][c]!;
              const dirs: [number, number][] = [[1, -1], [1, 1]];
              if (piece.isKing) dirs.push([-1, -1], [-1, 1]);

              dirs.forEach(([dr, dc]) => {
                const nr = r + dr;
                const nc = c + dc;
                if (inBounds(nr, nc)) {
                  if (!board[nr][nc]) {
                    allMoves.push({ from: [r, c], to: [nr, nc], isJump: false });
                  } else if (board[nr][nc]?.color === 'red') {
                    const jr = nr + dr;
                    const jc = nc + dc;
                    if (inBounds(jr, jc) && !board[jr][jc]) {
                      allMoves.push({ from: [r, c], to: [jr, jc], jumpOver: [nr, nc], isJump: true });
                    }
                  }
                }
              });
            }
          }
        }

        if (allMoves.length === 0) {
          setWinner('Red (You)');
          return;
        }

        // Prioritize jumps
        const jumps = allMoves.filter((m) => m.isJump);
        const pick = jumps.length > 0 ? jumps[Math.floor(Math.random() * jumps.length)] : allMoves[Math.floor(Math.random() * allMoves.length)];

        const newBoard = board.map((row) => [...row]);
        const piece = newBoard[pick.from[0]][pick.from[1]]!;

        if (pick.jumpOver) {
          newBoard[pick.jumpOver[0]][pick.jumpOver[1]] = null;
        }

        // King promotion
        if (pick.to[0] === 7) piece.isKing = true;

        newBoard[pick.to[0]][pick.to[1]] = piece;
        newBoard[pick.from[0]][pick.from[1]] = null;

        setBoard(newBoard);
        setTurn('red');
        audioManager.playSendSound();
      }, 500);

      return () => clearTimeout(timer);
    }
  }, [mode, turn, board, winner]);

  const handleSquareClick = (r: number, c: number) => {
    if (winner) return;
    if (mode === 'ai' && turn === 'black') return;

    if (selected) {
      const match = validMoves.find((m) => m.to[0] === r && m.to[1] === c);
      if (match) {
        const newBoard = board.map((row) => [...row]);
        const piece = newBoard[selected[0]][selected[1]]!;

        if (match.jumpOver) {
          newBoard[match.jumpOver[0]][match.jumpOver[1]] = null;
        }

        // King promotion (Red reaches row 0)
        if (piece.color === 'red' && r === 0) piece.isKing = true;

        newBoard[r][c] = piece;
        newBoard[selected[0]][selected[1]] = null;

        setBoard(newBoard);
        setSelected(null);
        setTurn(turn === 'red' ? 'black' : 'red');
        audioManager.playSendSound();
        return;
      }
    }

    if (board[r][c]?.color === turn) {
      setSelected([r, c]);
    } else {
      setSelected(null);
    }
  };

  const redCount = board.flat().filter((p) => p?.color === 'red').length;
  const blackCount = board.flat().filter((p) => p?.color === 'black').length;

  useEffect(() => {
    if (redCount === 0) setWinner('Black');
    if (blackCount === 0) setWinner('Red (You)');
  }, [redCount, blackCount]);

  return (
    <div className="flex flex-col items-center max-w-4xl mx-auto w-full px-2 sm:px-4 py-4 animate-in fade-in duration-200">
      <div className="w-full flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
        <button
          type="button"
          onClick={onExit}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition-all active:scale-95 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Arcade Hub</span>
        </button>

        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 text-rose-400 font-semibold">
            <span className="w-3 h-3 rounded-full bg-rose-500 shadow-xs" />
            <span>Red: {redCount}</span>
          </div>
          <span className="text-slate-600">vs</span>
          <div className="flex items-center gap-1.5 text-slate-400 font-semibold">
            <span className="w-3 h-3 rounded-full bg-slate-900 border border-slate-600" />
            <span>Black: {blackCount}</span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            setBoard(createInitialCheckersBoard());
            setTurn('red');
            setSelected(null);
            setWinner(null);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition-all active:scale-95 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Reset</span>
        </button>
      </div>

      {/* Board */}
      <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-700/60 shadow-2xl backdrop-blur-md">
        <div className="grid grid-cols-8 grid-rows-8 w-[320px] h-[320px] sm:w-[380px] sm:h-[380px] rounded-xl overflow-hidden border border-slate-700">
          {board.map((row, r) =>
            row.map((piece, c) => {
              const isDark = (r + c) % 2 === 1;
              const isSelected = selected?.[0] === r && selected?.[1] === c;
              const isTarget = validMoves.some((m) => m.to[0] === r && m.to[1] === c);

              return (
                <button
                  key={`${r}-${c}`}
                  type="button"
                  onClick={() => handleSquareClick(r, c)}
                  className={`relative flex items-center justify-center select-none cursor-pointer transition-colors ${
                    isDark ? 'bg-slate-950 hover:bg-slate-900' : 'bg-slate-700/30'
                  }`}
                >
                  {isTarget && (
                    <div className="w-3.5 h-3.5 rounded-full bg-emerald-400 shadow-lg animate-pulse z-10" />
                  )}

                  {piece && (
                    <div
                      className={`w-7 h-7 sm:w-9 sm:h-9 rounded-full flex items-center justify-center text-xs font-bold shadow-md transition-all ${
                        piece.color === 'red'
                          ? 'bg-gradient-to-br from-rose-500 to-rose-700 text-white border-2 border-rose-300 ring-2 ring-rose-900/50'
                          : 'bg-gradient-to-br from-slate-700 to-slate-950 text-slate-200 border-2 border-slate-500 ring-2 ring-black/50'
                      } ${isSelected ? 'scale-115 ring-4 ring-amber-400' : ''}`}
                    >
                      {piece.isKing ? '👑' : ''}
                    </div>
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>

      {winner && (
        <div className="mt-4 p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-center text-amber-200 text-sm font-bold animate-bounce">
          🏆 {winner} Won the Checkers match!
        </div>
      )}
    </div>
  );
};

// =========================================================================
// 3. LUDO MINI-ARCADE IMPLEMENTATION
// =========================================================================

const LudoGameComponent: React.FC<{
  mode: 'ai' | 'pass-and-play' | 'multiplayer';
  onExit: () => void;
}> = ({ mode, onExit }) => {
  const [diceValue, setDiceValue] = useState<number>(1);
  const [isRolling, setIsRolling] = useState(false);
  const [turn, setTurn] = useState<'red' | 'blue'>('red');
  const [redTokens, setRedTokens] = useState<number[]>([-1, -1]); // -1 means home base, 0-20 track, 20 is victory
  const [blueTokens, setBlueTokens] = useState<number[]>([-1, -1]);
  const [winner, setWinner] = useState<string | null>(null);

  const rollDice = () => {
    if (isRolling || winner) return;
    setIsRolling(true);
    let rolls = 0;
    const interval = setInterval(() => {
      setDiceValue(Math.floor(Math.random() * 6) + 1);
      rolls++;
      if (rolls >= 8) {
        clearInterval(interval);
        const finalVal = Math.floor(Math.random() * 6) + 1;
        setDiceValue(finalVal);
        setIsRolling(false);
        handleTurnAction(finalVal);
      }
    }, 60);
  };

  const handleTurnAction = (val: number) => {
    if (turn === 'red') {
      // Move first available token or advance
      const canBringOut = val === 6 && redTokens.some((t) => t === -1);
      if (canBringOut) {
        const idx = redTokens.findIndex((t) => t === -1);
        const updated = [...redTokens];
        updated[idx] = 0;
        setRedTokens(updated);
        audioManager.playSendSound();
      } else {
        const activeIdx = redTokens.findIndex((t) => t >= 0 && t < 20);
        if (activeIdx !== -1) {
          const updated = [...redTokens];
          updated[activeIdx] = Math.min(20, updated[activeIdx] + val);
          setRedTokens(updated);
          audioManager.playSendSound();
        }
      }
      setTurn('blue');
    } else {
      // Blue turn
      const canBringOut = val === 6 && blueTokens.some((t) => t === -1);
      if (canBringOut) {
        const idx = blueTokens.findIndex((t) => t === -1);
        const updated = [...blueTokens];
        updated[idx] = 0;
        setBlueTokens(updated);
        audioManager.playSendSound();
      } else {
        const activeIdx = blueTokens.findIndex((t) => t >= 0 && t < 20);
        if (activeIdx !== -1) {
          const updated = [...blueTokens];
          updated[activeIdx] = Math.min(20, updated[activeIdx] + val);
          setBlueTokens(updated);
          audioManager.playSendSound();
        }
      }
      setTurn('red');
    }
  };

  // Bot auto-roll on blue turn if in AI mode
  useEffect(() => {
    if (mode === 'ai' && turn === 'blue' && !winner && !isRolling) {
      const timer = setTimeout(() => {
        rollDice();
      }, 700);
      return () => clearTimeout(timer);
    }
  }, [turn, mode, winner, isRolling]);

  useEffect(() => {
    if (redTokens.every((t) => t === 20)) setWinner('Red Team');
    if (blueTokens.every((t) => t === 20)) setWinner('Blue Team');
  }, [redTokens, blueTokens]);

  return (
    <div className="flex flex-col items-center max-w-4xl mx-auto w-full px-2 sm:px-4 py-4 animate-in fade-in duration-200">
      <div className="w-full flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
        <button
          type="button"
          onClick={onExit}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition-all active:scale-95 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Arcade Hub</span>
        </button>

        <div className="flex items-center gap-2">
          <span
            className={`px-3 py-1 rounded-full text-xs font-bold ${
              turn === 'red' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
            }`}
          >
            {turn === 'red' ? 'Red Turn' : mode === 'ai' ? 'Blue Bot Turn' : 'Blue Turn'}
          </span>
        </div>

        <button
          type="button"
          onClick={() => {
            setRedTokens([-1, -1]);
            setBlueTokens([-1, -1]);
            setTurn('red');
            setWinner(null);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition-all active:scale-95 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Reset</span>
        </button>
      </div>

      {/* Track & Board Arena */}
      <div className="w-full max-w-md p-4 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl backdrop-blur-md space-y-4">
        {/* Bases */}
        <div className="grid grid-cols-2 gap-4">
          {/* Red Base */}
          <div className="p-3 rounded-2xl bg-rose-950/40 border border-rose-800/40 flex flex-col items-center">
            <span className="text-xs font-bold text-rose-300 mb-2">Red Base (Need 6 to Launch)</span>
            <div className="flex gap-2">
              {redTokens.map((pos, i) => (
                <div
                  key={i}
                  className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs border-2 shadow-md transition-all ${
                    pos === -1
                      ? 'bg-rose-600 border-rose-300 text-white animate-pulse'
                      : pos === 20
                      ? 'bg-emerald-600 border-emerald-300 text-white'
                      : 'bg-rose-950 border-rose-800 text-rose-500'
                  }`}
                >
                  {pos === 20 ? '🏆' : `R${i + 1}`}
                </div>
              ))}
            </div>
            <span className="text-[10px] text-slate-400 mt-2 font-mono">
              Tokens at: {redTokens.map((t) => (t === -1 ? 'Base' : t === 20 ? 'Home!' : `Tile ${t}`)).join(', ')}
            </span>
          </div>

          {/* Blue Base */}
          <div className="p-3 rounded-2xl bg-cyan-950/40 border border-cyan-800/40 flex flex-col items-center">
            <span className="text-xs font-bold text-cyan-300 mb-2">Blue Base (Need 6 to Launch)</span>
            <div className="flex gap-2">
              {blueTokens.map((pos, i) => (
                <div
                  key={i}
                  className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs border-2 shadow-md transition-all ${
                    pos === -1
                      ? 'bg-cyan-600 border-cyan-300 text-white animate-pulse'
                      : pos === 20
                      ? 'bg-emerald-600 border-emerald-300 text-white'
                      : 'bg-cyan-950 border-cyan-800 text-cyan-500'
                  }`}
                >
                  {pos === 20 ? '🏆' : `B${i + 1}`}
                </div>
              ))}
            </div>
            <span className="text-[10px] text-slate-400 mt-2 font-mono">
              Tokens at: {blueTokens.map((t) => (t === -1 ? 'Base' : t === 20 ? 'Home!' : `Tile ${t}`)).join(', ')}
            </span>
          </div>
        </div>

        {/* 20-Step Race Progress Track */}
        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 mb-2">
            <span>🏁 Start (Tile 0)</span>
            <span>⭐ Victory (Tile 20)</span>
          </div>

          {/* Red Progress Bar */}
          <div className="mb-2">
            <div className="flex justify-between text-[10px] text-rose-400 font-mono mb-1">
              <span>Red Tokens</span>
              <span>{Math.max(...redTokens, 0)} / 20</span>
            </div>
            <div className="h-3 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-rose-600 to-rose-400 transition-all duration-300"
                style={{ width: `${(Math.max(...redTokens, 0) / 20) * 100}%` }}
              />
            </div>
          </div>

          {/* Blue Progress Bar */}
          <div>
            <div className="flex justify-between text-[10px] text-cyan-400 font-mono mb-1">
              <span>Blue Tokens</span>
              <span>{Math.max(...blueTokens, 0)} / 20</span>
            </div>
            <div className="h-3 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400 transition-all duration-300"
                style={{ width: `${(Math.max(...blueTokens, 0) / 20) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* 3D Dice Box & Roll CTA */}
        <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div
            className={`w-16 h-16 rounded-2xl bg-gradient-to-br from-white to-slate-200 text-slate-950 flex items-center justify-center font-bold text-3xl shadow-xl transition-all ${
              isRolling ? 'rotate-180 scale-110 ring-4 ring-indigo-500' : 'ring-2 ring-slate-400'
            }`}
          >
            {diceValue}
          </div>

          <button
            type="button"
            onClick={rollDice}
            disabled={isRolling || (mode === 'ai' && turn === 'blue') || Boolean(winner)}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-sm shadow-lg transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            {isRolling ? 'Rolling Dice...' : `Roll Dice (${turn === 'red' ? 'Red' : 'Blue'})`}
          </button>
        </div>
      </div>

      {winner && (
        <div className="mt-4 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-center text-emerald-200 text-sm font-bold animate-bounce">
          🎉 {winner} Reached the Center Victory Home!
        </div>
      )}
    </div>
  );
};

// =========================================================================
// 4. MAFIA / PARTY GAME HOST IMPLEMENTATION
// =========================================================================

type MafiaRole = 'Mafia' | 'Detective' | 'Doctor' | 'Citizen';
type MafiaPhase = 'setup' | 'secret-reveal' | 'night' | 'day-dawn' | 'day-discussion' | 'day-voting' | 'game-over';

interface MafiaPlayer {
  id: string;
  name: string;
  avatar?: string;
  role: MafiaRole;
  alive: boolean;
  notes?: string;
}

const MafiaGameComponent: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  const { users } = useApp();

  const [phase, setPhase] = useState<MafiaPhase>('setup');
  const [players, setPlayers] = useState<MafiaPlayer[]>(() => {
    // Seed with 6 players from crew
    const seed = users.slice(0, 6).map((u, i) => {
      const roles: MafiaRole[] = ['Mafia', 'Detective', 'Doctor', 'Citizen', 'Citizen', 'Citizen'];
      return {
        id: u.id,
        name: u.name,
        avatar: u.avatar,
        role: roles[i] || 'Citizen',
        alive: true,
      };
    });
    return seed;
  });

  // Reveal peeker state
  const [peekIndex, setPeekIndex] = useState(0);
  const [isPeeking, setIsPeeking] = useState(false);

  // Night decisions
  const [mafiaTarget, setMafiaTarget] = useState<string | null>(null);
  const [doctorTarget, setDoctorTarget] = useState<string | null>(null);
  const [detectiveTarget, setDetectiveTarget] = useState<string | null>(null);
  const [detectiveResult, setDetectiveResult] = useState<string | null>(null);

  // Day casualty announcement
  const [lastNightCasualty, setLastNightCasualty] = useState<string | null>(null);

  // Discussion countdown
  const [discussionTimer, setDiscussionTimer] = useState(60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  // Voting
  const [accusedPlayer, setAccusedPlayer] = useState<string | null>(null);

  // Timer tick
  useEffect(() => {
    let interval: number | undefined;
    if (isTimerRunning && discussionTimer > 0) {
      interval = window.setInterval(() => {
        setDiscussionTimer((prev) => prev - 1);
      }, 1000);
    } else if (discussionTimer === 0) {
      setIsTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, discussionTimer]);

  const handleStartGame = () => {
    // Shuffle roles
    const shuffledRoles: MafiaRole[] = ['Mafia', 'Detective', 'Doctor', 'Citizen', 'Citizen', 'Citizen'];
    shuffledRoles.sort(() => Math.random() - 0.5);

    const updated = players.map((p, i) => ({
      ...p,
      role: shuffledRoles[i] || 'Citizen',
      alive: true,
    }));
    setPlayers(updated);
    setPeekIndex(0);
    setPhase('secret-reveal');
  };

  const handleExecuteNight = () => {
    if (!mafiaTarget) return;

    let casualty: string | null = null;
    if (mafiaTarget !== doctorTarget) {
      casualty = mafiaTarget;
      setPlayers((prev) => prev.map((p) => (p.name === mafiaTarget ? { ...p, alive: false } : p)));
    }

    setLastNightCasualty(casualty);
    setPhase('day-dawn');
    setDiscussionTimer(60);
    setIsTimerRunning(true);
  };

  const handleEliminatePlayer = (targetName: string) => {
    setPlayers((prev) => prev.map((p) => (p.name === targetName ? { ...p, alive: false } : p)));
    setAccusedPlayer(null);

    // Check game over
    const aliveMafia = players.filter((p) => p.name !== targetName && p.alive && p.role === 'Mafia').length;
    const aliveCitizens = players.filter((p) => p.name !== targetName && p.alive && p.role !== 'Mafia').length;

    if (aliveMafia === 0) {
      setPhase('game-over');
    } else if (aliveMafia >= aliveCitizens) {
      setPhase('game-over');
    } else {
      // Next night
      setMafiaTarget(null);
      setDoctorTarget(null);
      setDetectiveTarget(null);
      setDetectiveResult(null);
      setPhase('night');
    }
  };

  const alivePlayers = players.filter((p) => p.alive);
  const mafiaCount = alivePlayers.filter((p) => p.role === 'Mafia').length;
  const townCount = alivePlayers.filter((p) => p.role !== 'Mafia').length;

  return (
    <div className="flex flex-col items-center max-w-4xl mx-auto w-full px-2 sm:px-4 py-4 animate-in fade-in duration-200">
      <div className="w-full flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
        <button
          type="button"
          onClick={onExit}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition-all active:scale-95 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Arcade Hub</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-rose-950/60 border border-rose-800/50 text-rose-300 text-xs font-semibold">
            Mafia: {mafiaCount} vs Town: {townCount}
          </span>
        </div>

        <button
          type="button"
          onClick={() => {
            setPhase('setup');
          }}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition-all active:scale-95 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Reset</span>
        </button>
      </div>

      {/* PHASE 1: SETUP */}
      {phase === 'setup' && (
        <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-2xl text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-rose-600/20 text-rose-400 flex items-center justify-center mx-auto border border-rose-500/30">
            <Shield className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Mafia Party Game Host</h2>
            <p className="text-xs text-slate-400 mt-1">
              Host secret role allocations, manage night actions (Mafia hit, Doctor save, Detective inquiry), and day discussion trials.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-left text-xs space-y-1.5">
            <span className="font-semibold text-slate-300">Roster ({players.length} Players):</span>
            <div className="grid grid-cols-2 gap-2 mt-1">
              {players.map((p) => (
                <div key={p.id} className="flex items-center gap-2 p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span className="text-white font-medium truncate">{p.name}</span>
                </div>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={handleStartGame}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-xs shadow-lg transition-all active:scale-95 cursor-pointer"
          >
            Assign Secret Roles & Begin Game
          </button>
        </div>
      )}

      {/* PHASE 2: SECRET ROLE REVEAL */}
      {phase === 'secret-reveal' && (
        <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-2xl text-center space-y-5">
          <div className="space-y-1">
            <span className="text-[10px] font-mono text-indigo-400 font-bold tracking-widest uppercase">
              Secret Pass & Reveal
            </span>
            <h3 className="text-base font-bold text-white">
              Pass device to {players[peekIndex].name}
            </h3>
            <p className="text-xs text-slate-400">
              Only {players[peekIndex].name} should look at the screen. Press & hold below to reveal secret identity.
            </p>
          </div>

          <div
            onMouseDown={() => setIsPeeking(true)}
            onMouseUp={() => setIsPeeking(false)}
            onTouchStart={() => setIsPeeking(true)}
            onTouchEnd={() => setIsPeeking(false)}
            className={`p-6 rounded-2xl border-2 transition-all cursor-pointer select-none ${
              isPeeking
                ? 'bg-rose-950/80 border-rose-500 shadow-xl'
                : 'bg-slate-950 border-dashed border-slate-700 hover:border-slate-500'
            }`}
          >
            {isPeeking ? (
              <div className="space-y-2">
                <span className="text-2xl font-black text-rose-400 tracking-wider">
                  {players[peekIndex].role.toUpperCase()}
                </span>
                <p className="text-xs text-rose-200">
                  {players[peekIndex].role === 'Mafia' && 'You eliminate citizens each night.'}
                  {players[peekIndex].role === 'Doctor' && 'You protect 1 player from being eliminated each night.'}
                  {players[peekIndex].role === 'Detective' && 'You investigate 1 suspect each night.'}
                  {players[peekIndex].role === 'Citizen' && 'Discuss during the day and vote out the Mafia.'}
                </p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-slate-400 py-4">
                <EyeOff className="w-6 h-6 text-slate-500" />
                <span className="text-xs font-semibold text-slate-300">Press & Hold to Peek Role</span>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => {
              if (peekIndex < players.length - 1) {
                setPeekIndex(peekIndex + 1);
                setIsPeeking(false);
              } else {
                setPhase('night');
              }
            }}
            className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-all active:scale-95 cursor-pointer"
          >
            {peekIndex < players.length - 1 ? 'Next Player' : 'All Roles Confirmed · Start Night 1'}
          </button>
        </div>
      )}

      {/* PHASE 3: NIGHT PHASE */}
      {phase === 'night' && (
        <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-2xl space-y-4">
          <div className="text-center space-y-1">
            <span className="text-[10px] font-mono text-cyan-400 tracking-widest uppercase">
              🌙 Night Phase · City is Asleep
            </span>
            <h3 className="text-base font-bold text-white">Moderator Control Deck</h3>
          </div>

          {/* Action 1: Mafia Target */}
          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-rose-400">1. Mafia Selection (Choose Elimination Target):</span>
            <div className="grid grid-cols-2 gap-1.5">
              {alivePlayers.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setMafiaTarget(p.name)}
                  className={`p-2 rounded-xl text-xs font-medium border text-left truncate transition-colors ${
                    mafiaTarget === p.name
                      ? 'bg-rose-600 text-white border-rose-500 font-bold'
                      : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          {/* Action 2: Doctor Target */}
          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-emerald-400">2. Doctor Selection (Choose Protection Target):</span>
            <div className="grid grid-cols-2 gap-1.5">
              {alivePlayers.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setDoctorTarget(p.name)}
                  className={`p-2 rounded-xl text-xs font-medium border text-left truncate transition-colors ${
                    doctorTarget === p.name
                      ? 'bg-emerald-600 text-white border-emerald-500 font-bold'
                      : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          {/* Action 3: Detective Target */}
          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-indigo-400">3. Detective Inquiry (Inspect 1 Suspect):</span>
            <div className="grid grid-cols-2 gap-1.5">
              {alivePlayers.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setDetectiveTarget(p.name);
                    const isMafia = p.role === 'Mafia';
                    setDetectiveResult(isMafia ? 'GUILTY (Mafia)' : 'INNOCENT (Citizen/Special)');
                  }}
                  className={`p-2 rounded-xl text-xs font-medium border text-left truncate transition-colors ${
                    detectiveTarget === p.name
                      ? 'bg-indigo-600 text-white border-indigo-500 font-bold'
                      : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>
            {detectiveResult && (
              <p className="text-[11px] font-bold text-indigo-300 pt-1">
                Detective Result for {detectiveTarget}: {detectiveResult}
              </p>
            )}
          </div>

          <button
            type="button"
            disabled={!mafiaTarget}
            onClick={handleExecuteNight}
            className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs shadow-lg transition-all active:scale-95 cursor-pointer"
          >
            End Night & Dawn Break ☀️
          </button>
        </div>
      )}

      {/* PHASE 4: DAY DAWN & DISCUSSION */}
      {(phase === 'day-dawn' || phase === 'day-discussion') && (
        <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-2xl space-y-5 text-center">
          <div className="space-y-1">
            <span className="text-[10px] font-mono text-amber-400 tracking-widest uppercase">
              ☀️ Morning Dawn Report
            </span>
            <h3 className="text-lg font-bold text-white">The Town Awakens</h3>
          </div>

          <div
            className={`p-4 rounded-2xl border text-xs leading-relaxed ${
              lastNightCasualty
                ? 'bg-rose-950/40 border-rose-800 text-rose-300 font-semibold'
                : 'bg-emerald-950/40 border-emerald-800 text-emerald-300 font-semibold'
            }`}
          >
            {lastNightCasualty ? (
              <span>⚠️ Tragedy in town! {lastNightCasualty} was attacked by the Mafia and eliminated.</span>
            ) : (
              <span>🛡️ A peaceful night! The Doctor successfully shielded the Mafia victim! Nobody died.</span>
            )}
          </div>

          {/* Discussion Countdown Timer */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col items-center space-y-2">
            <span className="text-xs text-slate-400">Discussion Timer</span>
            <span className="text-3xl font-mono font-bold text-white tabular-nums">
              00:{discussionTimer < 10 ? `0${discussionTimer}` : discussionTimer}
            </span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setIsTimerRunning(!isTimerRunning)}
                className="px-3 py-1 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
              >
                {isTimerRunning ? 'Pause' : 'Resume'}
              </button>
              <button
                type="button"
                onClick={() => setDiscussionTimer(60)}
                className="px-3 py-1 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
              >
                Reset 60s
              </button>
            </div>
          </div>

          {/* Proceed to Trial Voting */}
          <button
            type="button"
            onClick={() => setPhase('day-voting')}
            className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg transition-all active:scale-95 cursor-pointer"
          >
            Proceed to Town Trial & Elimination Voting ⚖️
          </button>
        </div>
      )}

      {/* PHASE 5: DAY VOTING */}
      {phase === 'day-voting' && (
        <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-2xl space-y-4">
          <div className="text-center space-y-1">
            <span className="text-[10px] font-mono text-amber-400 tracking-widest uppercase">
              ⚖️ Town Court & Vote
            </span>
            <h3 className="text-base font-bold text-white">Select Suspect to Eliminate</h3>
          </div>

          <div className="space-y-2">
            {alivePlayers.map((p) => (
              <div
                key={p.id}
                className={`p-3 rounded-2xl border flex items-center justify-between transition-colors ${
                  accusedPlayer === p.name ? 'bg-amber-500/20 border-amber-500' : 'bg-slate-950 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  <span className="text-xs font-bold text-white">{p.name}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setAccusedPlayer(p.name)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                    accusedPlayer === p.name ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {accusedPlayer === p.name ? 'Selected for Trial' : 'Put on Trial'}
                </button>
              </div>
            ))}
          </div>

          {accusedPlayer && (
            <div className="p-3 bg-rose-950/40 border border-rose-800/50 rounded-2xl text-center space-y-2">
              <p className="text-xs text-rose-300 font-semibold">
                Majority voted to eliminate {accusedPlayer}!
              </p>
              <button
                type="button"
                onClick={() => handleEliminatePlayer(accusedPlayer)}
                className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-md"
              >
                Confirm Elimination & Reveal Role
              </button>
            </div>
          )}
        </div>
      )}

      {/* PHASE 6: GAME OVER */}
      {phase === 'game-over' && (
        <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-2xl text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center mx-auto">
            <Trophy className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">
              {mafiaCount === 0 ? 'Townspeople Victorious! 🎉' : 'Mafia Dominates the City! 🕵️'}
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              {mafiaCount === 0
                ? 'All Mafia members have been successfully brought to justice.'
                : 'The Mafia took full control of the town session.'}
            </p>
          </div>

          {/* Full Role Reveal */}
          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-left text-xs space-y-1.5">
            <span className="font-semibold text-slate-300">Identity Ledger:</span>
            {players.map((p) => (
              <div key={p.id} className="flex items-center justify-between py-1 border-b border-slate-900 last:border-none">
                <span className={p.alive ? 'text-white' : 'text-slate-500 line-through'}>{p.name}</span>
                <span
                  className={`font-mono text-[10px] font-bold ${
                    p.role === 'Mafia' ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {p.role}
                </span>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={handleStartGame}
            className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition-all active:scale-95 cursor-pointer"
          >
            Play Another Round
          </button>
        </div>
      )}
    </div>
  );
};

// =========================================================================
// 5. MAIN GAMES ARCADE SCREEN (Hub + Game Launcher)
// =========================================================================

export const GamesScreen: React.FC = () => {
  const { activeGame, launchGame, closeActiveGame, currentUser } = useApp();

  const [selectedGameId, setSelectedGameId] = useState<GameId | null>(activeGame?.gameId || null);
  const [selectedMode, setSelectedMode] = useState<'ai' | 'pass-and-play' | 'multiplayer'>(
    activeGame?.mode || 'ai'
  );

  useEffect(() => {
    if (activeGame) {
      setSelectedGameId(activeGame.gameId);
      setSelectedMode(activeGame.mode);
    }
  }, [activeGame]);

  const handleExitCurrentGame = () => {
    closeActiveGame();
    setSelectedGameId(null);
  };

  // Render active game
  if (selectedGameId === 'chess') {
    return (
      <ChessGameComponent
        mode={selectedMode}
        opponentName={activeGame?.opponentName}
        onExit={handleExitCurrentGame}
      />
    );
  }

  if (selectedGameId === 'checkers') {
    return (
      <CheckersGameComponent
        mode={selectedMode}
        opponentName={activeGame?.opponentName}
        onExit={handleExitCurrentGame}
      />
    );
  }

  if (selectedGameId === 'ludo') {
    return <LudoGameComponent mode={selectedMode} onExit={handleExitCurrentGame} />;
  }

  if (selectedGameId === 'mafia') {
    return <MafiaGameComponent onExit={handleExitCurrentGame} />;
  }

  // ARCADE HUB OVERVIEW
  const GAMES_LIST: Array<{
    id: GameId;
    title: string;
    badge: string;
    description: string;
    icon: string;
    gradient: string;
    modes: string[];
  }> = [
    {
      id: 'chess',
      title: 'Grandmaster Chess',
      badge: 'Classic 8x8 Strategy',
      description: 'Full legal move engine, legal captures, checkmate detection, cemetery graveyard, and EchoBot AI.',
      icon: '♟️',
      gradient: 'from-amber-500/20 via-orange-600/10 to-transparent',
      modes: ['vs EchoBot AI', 'Pass & Play', 'DM Challenge'],
    },
    {
      id: 'checkers',
      title: 'Crown Checkers',
      badge: 'Tactical Draughts',
      description: 'Diagonal jumps, king piece crowning, jump captures, and single/2P multiplayer passes.',
      icon: '👑',
      gradient: 'from-rose-500/20 via-red-600/10 to-transparent',
      modes: ['vs EchoBot AI', 'Pass & Play'],
    },
    {
      id: 'ludo',
      title: 'Ludo Arena',
      badge: 'Dice Race Track',
      description: '3D animated dice rolls, home base launch on 6s, 20-step tactical race track, and bot opposition.',
      icon: '🎲',
      gradient: 'from-cyan-500/20 via-blue-600/10 to-transparent',
      modes: ['vs EchoBot AI', 'Local 2P'],
    },
    {
      id: 'mafia',
      title: 'Mafia Party Lounge',
      badge: 'Voice Room Party Host',
      description: 'Interactive role manager for room drop-ins: secret role peeker, night elimination, doctor shield, detective investigations, and day dawn voting.',
      icon: '🕵️',
      gradient: 'from-purple-500/20 via-indigo-600/10 to-transparent',
      modes: ['Room Host Moderator', 'Crew Party'],
    },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto px-4 md:px-6 py-6 pb-28 md:pb-16 animate-in fade-in duration-200">
      {/* Header & Hero */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse" />
            <span className="text-[11px] font-mono uppercase tracking-widest text-indigo-400 font-bold">
              EchoTalk Arcade
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
            <span>Mini-Games Hub</span>
            <Flame className="w-6 h-6 text-amber-400" />
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-md leading-relaxed">
            Play classic multiplayer offline games or challenge crew members directly inside DM conversations.
          </p>
        </div>

        {/* Global Player Card */}
        <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-sm backdrop-blur-md self-start sm:self-auto">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-md">
            🎮
          </div>
          <div>
            <span className="text-xs font-bold text-white block">{currentUser.name}</span>
            <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              Online & Ready to Play
            </span>
          </div>
        </div>
      </div>

      {/* Mode Filter Selector */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setSelectedMode('ai')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
            selectedMode === 'ai'
              ? 'bg-indigo-600 text-white border-indigo-500 shadow-md'
              : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          <Bot className="w-3.5 h-3.5" />
          <span>vs EchoBot AI</span>
        </button>
        <button
          type="button"
          onClick={() => setSelectedMode('pass-and-play')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
            selectedMode === 'pass-and-play'
              ? 'bg-indigo-600 text-white border-indigo-500 shadow-md'
              : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Local Pass & Play</span>
        </button>
      </div>

      {/* Games Catalog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {GAMES_LIST.map((game) => (
          <div
            key={game.id}
            className="group relative p-5 rounded-3xl bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-slate-700/80 shadow-xl transition-all duration-200 overflow-hidden flex flex-col justify-between"
          >
            {/* Background Gradient Splash */}
            <div
              className={`absolute top-0 right-0 w-48 h-48 bg-gradient-to-br ${game.gradient} rounded-full blur-2xl pointer-events-none -mr-10 -mt-10`}
            />

            <div>
              {/* Header: Icon & Badge */}
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center text-2xl shadow-inner group-hover:scale-110 transition-transform">
                  {game.icon}
                </div>
                <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-slate-950 border border-slate-800 text-indigo-300 font-semibold">
                  {game.badge}
                </span>
              </div>

              {/* Title & Description */}
              <h3 className="text-base font-bold text-white group-hover:text-indigo-400 transition-colors">
                {game.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                {game.description}
              </p>

              {/* Mode Tags */}
              <div className="flex flex-wrap gap-1.5 mt-3">
                {game.modes.map((modeTag) => (
                  <span
                    key={modeTag}
                    className="text-[10px] px-2 py-0.5 rounded-lg bg-slate-950/80 text-slate-400 border border-slate-800"
                  >
                    {modeTag}
                  </span>
                ))}
              </div>
            </div>

            {/* Launch Button */}
            <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">
                Mode: {selectedMode === 'ai' ? '🤖 Bot' : '👥 2P'}
              </span>
              <button
                type="button"
                onClick={() => launchGame(game.id, undefined, selectedMode)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md transition-all active:scale-95 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Play Now</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
