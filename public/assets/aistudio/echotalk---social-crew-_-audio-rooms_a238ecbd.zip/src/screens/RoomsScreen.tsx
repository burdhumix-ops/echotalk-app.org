import React, { useState, useEffect, useRef } from 'react';
import {
  Lock,
  Unlock,
  Plus,
  Send,
  Mic,
  Users,
  Clock,
  Shield,
  UserX,
  Trash2,
  AlertCircle,
  DoorOpen,
  DoorClosed,
  Sparkles,
  ArrowLeft,
  ChevronRight,
  Radio,
  Square,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CreateRoomModal } from '../components/CreateRoomModal';
import { AudioWaveform } from '../components/AudioWaveform';
import { VoiceRecorder } from '../utils/audio';
import { Room } from '../types';

export const RoomsScreen: React.FC = () => {
  const {
    rooms,
    currentUser,
    isAdmin,
    isUserAdminOrOwner,
    currentRoomName,
    setCurrentRoomName,
    sendMessage,
    lockRoom,
    unlockRoom,
    openRoom,
    closeRoom,
    cleanupMessages,
    kickUser,
    startMessageCleanupTimer,
    cancelMessageCleanupTimer,
    simulateIncomingRoomMessage,
  } = useApp();

  // State: selectedRoomName is null when on the clean Rooms List, and string when inside 100% Full-Screen Chat View
  const [selectedRoomName, setSelectedRoomName] = useState<string | null>(null);
  const [messageText, setMessageText] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);
  const [timerRemaining, setTimerRemaining] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordDuration, setRecordDuration] = useState(0);

  const recorderRef = useRef<VoiceRecorder | null>(null);
  const recordIntervalRef = useRef<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Active full-screen room reference
  const activeRoom: Room | undefined = rooms.find((r) => r.name === selectedRoomName);

  // Auto scroll to bottom when inside full-screen chat
  useEffect(() => {
    if (activeRoom) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [activeRoom?.messages, activeRoom?.richMessages]);

  // Live countdown timer for active room
  useEffect(() => {
    if (!activeRoom?.cleanupTimerExpiresAt) {
      setTimerRemaining(null);
      return;
    }

    const updateCountdown = () => {
      if (!activeRoom.cleanupTimerExpiresAt) {
        setTimerRemaining(null);
        return;
      }
      const diff = Math.max(0, activeRoom.cleanupTimerExpiresAt - Date.now());
      if (diff <= 0) {
        setTimerRemaining('Expired');
        return;
      }
      const totalSecs = Math.floor(diff / 1000);
      const hours = Math.floor(totalSecs / 3600);
      const mins = Math.floor((totalSecs % 3600) / 60);
      const secs = totalSecs % 60;
      if (hours > 0) {
        setTimerRemaining(`${hours}h ${mins}m ${secs}s`);
      } else {
        setTimerRemaining(`${mins}m ${secs}s`);
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [activeRoom?.cleanupTimerExpiresAt]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !activeRoom) return;

    const res = sendMessage(activeRoom.name, currentUser.name, messageText.trim());
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to send message.');
      setTimeout(() => setErrorMessage(''), 4000);
    } else {
      setMessageText('');
      setErrorMessage('');
    }
  };

  const handleToggleRecord = async () => {
    if (!activeRoom) return;
    if (activeRoom.locked || !activeRoom.isOpen) return;

    if (isRecording) {
      if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
      if (recorderRef.current) {
        const result = await recorderRef.current.stop();
        if (result) {
          sendMessage(activeRoom.name, currentUser.name, '[Voice Note]', result.audioUrl, result.duration);
        }
      }
      setIsRecording(false);
      setRecordDuration(0);
    } else {
      const rec = new VoiceRecorder();
      recorderRef.current = rec;
      const started = await rec.start();
      if (started) {
        setIsRecording(true);
        setRecordDuration(0);
        recordIntervalRef.current = window.setInterval(() => {
          setRecordDuration((prev) => prev + 1);
        }, 1000);
      } else {
        // Fallback to synthetic note if mic access denied
        sendMessage(
          activeRoom.name,
          currentUser.name,
          '[Voice Note]',
          `room-voice-${Date.now()}`,
          5
        );
      }
    }
  };

  const handleJoinRoom = (room: Room) => {
    setCurrentRoomName(room.name);
    setSelectedRoomName(room.name);
    if (!room.participants.includes(currentUser.name)) {
      room.participants = [...room.participants, currentUser.name];
    }
  };

  const handleLockToggle = () => {
    if (!activeRoom) return;
    if (activeRoom.locked) {
      const res = unlockRoom(activeRoom.name);
      if (!res.success) {
        setErrorMessage(res.error || 'Cannot unlock.');
        setTimeout(() => setErrorMessage(''), 4000);
      }
    } else {
      const res = lockRoom(activeRoom.name);
      if (!res.success) {
        setErrorMessage(res.error || 'Cannot lock.');
        setTimeout(() => setErrorMessage(''), 4000);
      }
    }
  };

  const handleSetTimer = (seconds: number) => {
    if (!activeRoom) return;
    startMessageCleanupTimer(activeRoom.name, seconds);
  };

  // =========================================================================
  // 3. 100% FULL-SCREEN CHAT VIEW (Dedicated Full Width and Height Page)
  // =========================================================================
  if (selectedRoomName && activeRoom) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col h-screen w-screen overflow-hidden text-slate-100">
        {/* Top Bar with ← Back to Rooms Button */}
        <header className="shrink-0 h-16 px-4 md:px-8 border-b border-slate-800/80 bg-slate-950/95 backdrop-blur-md flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            {/* Back Button */}
            <button
              type="button"
              onClick={() => {
                setSelectedRoomName(null);
                setShowAdminPanel(false);
                setShowParticipants(false);
                setErrorMessage('');
              }}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 transition-colors shrink-0"
              aria-label="Back to Rooms list"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Rooms</span>
            </button>

            {/* Room Title & Unboxed Metadata */}
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="text-sm md:text-base font-bold text-white truncate">
                  {activeRoom.name}
                </h1>
                {activeRoom.isSpecialRoom && (
                  <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 bg-amber-950/50 border border-amber-800/60 px-1.5 py-0.5 rounded shrink-0">
                    Special 2-Day Room
                  </span>
                )}
                {activeRoom.locked && (
                  <span className="text-[10px] font-mono text-amber-400 flex items-center gap-1 shrink-0">
                    <Lock className="w-3 h-3" />
                    <span>Locked</span>
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 truncate">
                <span>{activeRoom.participants.length} Participants</span>
                <span aria-hidden="true">·</span>
                <span className={activeRoom.isOpen ? 'text-emerald-400' : 'text-rose-400'}>
                  {activeRoom.isOpen ? 'Open Room' : 'Closed Room'}
                </span>
                {timerRemaining && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-amber-300 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{timerRemaining}</span>
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Top Right Controls (Participants & Admin) */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Participants Toggle */}
            <button
              type="button"
              onClick={() => setShowParticipants(!showParticipants)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-xl border transition-colors ${
                showParticipants
                  ? 'bg-slate-800 text-white border-slate-700'
                  : 'bg-slate-900/80 text-slate-300 hover:text-white border-slate-800 hover:bg-slate-800'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span className="font-mono tabular-nums">{activeRoom.participants.length}</span>
            </button>

            {/* Admin Controls Toggle (Visible to Admin or Owner) */}
            {isUserAdminOrOwner && (
              <button
                type="button"
                onClick={() => setShowAdminPanel(!showAdminPanel)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border transition-colors ${
                  showAdminPanel
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm'
                    : 'bg-slate-900 text-indigo-300 border-slate-800 hover:text-white hover:bg-slate-800'
                }`}
                title="Admin Controls"
              >
                <Shield className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Admin</span>
              </button>
            )}
          </div>
        </header>

        {/* Collapsible Admin Control Panel */}
        {isUserAdminOrOwner && showAdminPanel && (
          <div className="shrink-0 p-3.5 bg-slate-950 border-b border-slate-800 text-xs text-slate-300 space-y-3 animate-in slide-in-from-top-2 duration-150">
            <div className="max-w-4xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-indigo-400" />
                Administrator Controls for {activeRoom.name}
              </span>
              <span className="text-[10px] font-mono text-slate-500">app_logic.dart rule enforced</span>
            </div>

            <div className="max-w-4xl mx-auto flex flex-wrap items-center gap-2">
              {/* Lock/Unlock Special Room */}
              <button
                type="button"
                onClick={handleLockToggle}
                className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 border transition-colors ${
                  activeRoom.locked
                    ? 'bg-amber-600/30 border-amber-500/50 text-amber-200 hover:bg-amber-600/40'
                    : 'bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800'
                }`}
                title={
                  activeRoom.isSpecialRoom
                    ? 'Lock/unlock special room'
                    : 'Only the special room can be locked'
                }
              >
                {activeRoom.locked ? (
                  <>
                    <Unlock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Unlock Room</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    <span>Lock Room</span>
                  </>
                )}
              </button>

              {/* Open / Close Room */}
              <button
                type="button"
                onClick={() => (activeRoom.isOpen ? closeRoom(activeRoom.name) : openRoom(activeRoom.name))}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl font-medium flex items-center gap-1.5 text-slate-200"
              >
                {activeRoom.isOpen ? (
                  <>
                    <DoorClosed className="w-3.5 h-3.5 text-rose-400" />
                    <span>Close Room</span>
                  </>
                ) : (
                  <>
                    <DoorOpen className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Open Room</span>
                  </>
                )}
              </button>

              {/* Cleanup Messages */}
              <button
                type="button"
                onClick={() => cleanupMessages(activeRoom.name)}
                className="px-3 py-1.5 bg-slate-900 hover:bg-rose-950/60 border border-slate-800 hover:border-rose-800/60 rounded-xl font-medium flex items-center gap-1.5 text-rose-300"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                <span>Cleanup Messages</span>
              </button>

              {/* Simulate Incoming Room Chatter */}
              <button
                type="button"
                onClick={() => simulateIncomingRoomMessage(activeRoom.name)}
                className="px-3 py-1.5 bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-800/50 rounded-xl font-medium flex items-center gap-1.5 text-indigo-300"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Simulate Chatter</span>
              </button>
            </div>

            {/* Auto-Cleanup Timers */}
            <div className="max-w-4xl mx-auto pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-2">
              <span className="text-slate-400 shrink-0">Set Cleanup Timer:</span>
              <button
                type="button"
                onClick={() => handleSetTimer(300)}
                className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg font-mono text-[11px]"
              >
                5m (Test)
              </button>
              <button
                type="button"
                onClick={() => handleSetTimer(3600)}
                className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg font-mono text-[11px]"
              >
                1 Hour
              </button>
              <button
                type="button"
                onClick={() => handleSetTimer(86400)}
                className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg font-mono text-[11px]"
              >
                24 Hours
              </button>
              <button
                type="button"
                onClick={() => handleSetTimer(172800)}
                className="px-2.5 py-1 bg-amber-950/50 hover:bg-amber-900/50 border border-amber-800/60 text-amber-300 rounded-lg font-mono text-[11px]"
              >
                2 Days (Special)
              </button>

              {activeRoom.cleanupTimerExpiresAt && (
                <button
                  type="button"
                  onClick={() => cancelMessageCleanupTimer(activeRoom.name)}
                  className="text-xs text-rose-400 hover:underline ml-2"
                >
                  Cancel Timer
                </button>
              )}
            </div>
          </div>
        )}

        {/* Collapsible Participants Drawer */}
        {showParticipants && (
          <div className="shrink-0 p-3 bg-slate-900/95 border-b border-slate-800 text-xs animate-in slide-in-from-top-1 duration-150">
            <div className="max-w-4xl mx-auto flex items-center justify-between mb-2">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-indigo-400" />
                Active Participants in {activeRoom.name} ({activeRoom.participants.length})
              </span>
              <button
                type="button"
                onClick={() => setShowParticipants(false)}
                className="text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>
            <div className="max-w-4xl mx-auto flex flex-wrap gap-2">
              {activeRoom.participants.map((person) => (
                <div
                  key={person}
                  className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800"
                >
                  <span className="text-slate-200">{person}</span>
                  {isUserAdminOrOwner && person !== currentUser.name && (
                    <button
                      type="button"
                      onClick={() => kickUser(activeRoom.name, person)}
                      className="text-slate-500 hover:text-rose-400 transition-colors"
                      title={`Kick ${person} (AppLogic: kickUser)`}
                    >
                      <UserX className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Locked / Closed Alert Banners */}
        {activeRoom.locked && (
          <div className="shrink-0 px-4 py-2.5 bg-amber-950/60 border-b border-amber-800/40 text-xs text-amber-300 flex items-center justify-center gap-2">
            <Lock className="w-4 h-4 shrink-0 text-amber-400" />
            <span>
              <strong>Room Locked:</strong> Messaging is disabled by administrator. Only the special room can be locked/unlocked.
            </span>
          </div>
        )}

        {!activeRoom.isOpen && (
          <div className="shrink-0 px-4 py-2.5 bg-rose-950/60 border-b border-rose-800/40 text-xs text-rose-300 flex items-center justify-center gap-2">
            <DoorClosed className="w-4 h-4 shrink-0 text-rose-400" />
            <span>
              <strong>Room Closed:</strong> This room has been closed by an administrator.
            </span>
          </div>
        )}

        {errorMessage && (
          <div className="shrink-0 px-4 py-2 bg-rose-950/80 border-b border-rose-800/80 text-xs text-rose-200 flex items-center justify-center gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Center: Pinned Message List (Spans full remaining height, centered layout) */}
        <div className="flex-1 overflow-y-auto px-4 md:px-8 py-6">
          <div className="max-w-3xl mx-auto space-y-4">
            {(!activeRoom.richMessages || activeRoom.richMessages.length === 0) ? (
              <div className="py-24 flex flex-col items-center justify-center text-center text-slate-500">
                <Radio className="w-10 h-10 text-slate-600 mb-2 stroke-[1.5]" />
                <p className="text-sm font-medium text-slate-400">No messages in {activeRoom.name} yet.</p>
                <p className="text-xs text-slate-500 mt-1">Be the first to say hello or drop a voice note!</p>
              </div>
            ) : (
              activeRoom.richMessages.map((msg) => {
                const isMe = msg.userName === currentUser.name;
                const isSys = msg.isSystem;

                if (isSys) {
                  return (
                    <div key={msg.id} className="flex justify-center my-3">
                      <span className="text-[11px] font-mono text-slate-400 bg-slate-900 border border-slate-800 px-3.5 py-1 rounded-full text-center">
                        {msg.message}
                      </span>
                    </div>
                  );
                }

                return (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-3 max-w-xl ${isMe ? 'ml-auto flex-row-reverse' : ''}`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700/60 flex items-center justify-center text-xs font-bold text-slate-200 shrink-0">
                      {msg.userName.charAt(0)}
                    </div>
                    <div className={`space-y-1.5 ${isMe ? 'items-end' : ''}`}>
                      <div className={`flex items-center gap-2 text-[11px] ${isMe ? 'justify-end' : ''}`}>
                        <span className="font-semibold text-slate-300">{msg.userName}</span>
                        <span className="text-slate-500 font-mono">{msg.timestamp}</span>
                      </div>

                      {msg.voiceNote ? (
                        <AudioWaveform
                          seed={msg.voiceNote}
                          duration={msg.voiceDuration || 5}
                          isSentByMe={isMe}
                        />
                      ) : (
                        <div
                          className={`p-3.5 rounded-2xl text-xs leading-relaxed ${
                            isMe
                              ? 'bg-indigo-600 text-white rounded-tr-xs'
                              : 'bg-slate-900 text-slate-200 rounded-tl-xs border border-slate-800'
                          }`}
                        >
                          {msg.message}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Live Recording Banner in Room */}
        {isRecording && (
          <div className="shrink-0 px-4 py-2 bg-rose-950/70 border-t border-rose-800/60 flex items-center justify-between text-xs text-rose-300 animate-pulse">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span>Recording voice note... ({recordDuration}s)</span>
            </div>
            <button
              type="button"
              onClick={handleToggleRecord}
              className="font-medium hover:underline text-rose-200"
            >
              Finish & Send
            </button>
          </div>
        )}

        {/* Bottom: Strictly Pinned Message Input / Send Bar */}
        <div className="shrink-0 p-3 md:p-4 border-t border-slate-800/80 bg-slate-950/95 backdrop-blur-md">
          <div className="max-w-3xl mx-auto">
            <form onSubmit={handleSendMessage} className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleToggleRecord}
                disabled={activeRoom.locked || !activeRoom.isOpen}
                className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                  isRecording
                    ? 'bg-rose-600 hover:bg-rose-500 text-white animate-bounce'
                    : 'bg-slate-900 hover:bg-slate-800 border border-slate-800 disabled:opacity-40 disabled:pointer-events-none text-slate-300 hover:text-white'
                }`}
                title={isRecording ? 'Finish & send voice note' : 'Record voice note (hold/click)'}
              >
                {isRecording ? <Square className="w-4 h-4 fill-current" /> : <Mic className="w-4 h-4" />}
              </button>

              <input
                type="text"
                disabled={activeRoom.locked || !activeRoom.isOpen}
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder={
                  activeRoom.locked
                    ? 'Room is locked by admin (messages blocked)'
                    : !activeRoom.isOpen
                    ? 'Room is closed by admin'
                    : `Message ${activeRoom.name}...`
                }
                className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 disabled:opacity-50 transition-colors"
              />

              <button
                type="submit"
                disabled={!messageText.trim() || activeRoom.locked || !activeRoom.isOpen}
                className="w-11 h-11 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:pointer-events-none text-white flex items-center justify-center shrink-0 transition-all active:scale-95 shadow-sm"
                aria-label="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // 2. CLEAN ROOMS LIST PAGE (Simple, clean list of room names, no inline chat previews)
  // =========================================================================
  const totalParticipants = rooms.reduce((acc, r) => acc + r.participants.length, 0);

  return (
    <div className="w-full max-w-4xl mx-auto px-4 md:px-6 py-6 pb-24 md:pb-12">
      {/* Header and Permission-Controlled Create Room Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Audio & Text Rooms</h1>
          {/* Zero-Pill Unboxed Text Metadata */}
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span className="tabular-nums font-mono text-indigo-400">{rooms.length} Active Rooms</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{totalParticipants} Active Listeners</span>
            <span aria-hidden="true">·</span>
            <span>Tap room to join full-screen</span>
          </div>
        </div>

        {/* 1. Admin/Owner Only Room Creation:
            Hide button completely for standard public users.
            Only users with Admin or Owner role can see the button and create new rooms. */}
        {isUserAdminOrOwner && (
          <button
            type="button"
            onClick={() => setIsCreateModalOpen(true)}
            className="self-start sm:self-auto inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all shadow-sm active:scale-95 shrink-0"
            title="Create a new room (Admin/Owner only)"
          >
            <Plus className="w-4 h-4" />
            <span>Create Room</span>
          </button>
        )}
      </div>

      {/* Clean Rooms List Container (No inline chat previews!) */}
      <div className="space-y-3">
        {rooms.map((room) => {
          return (
            <div
              key={room.id}
              onClick={() => handleJoinRoom(room)}
              className="group p-4 bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl cursor-pointer transition-all flex items-center justify-between gap-4"
            >
              {/* Left: Room Icon, Name & Clean Metadata */}
              <div className="flex items-center gap-3.5 min-w-0">
                <div
                  className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${
                    room.isSpecialRoom
                      ? 'bg-amber-950/40 border-amber-800/50 text-amber-400'
                      : 'bg-slate-800/80 border-slate-700/60 text-indigo-400'
                  }`}
                >
                  <Radio className="w-5 h-5" />
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h2 className="text-sm md:text-base font-semibold text-white group-hover:text-indigo-400 transition-colors truncate">
                      {room.name}
                    </h2>
                    {room.isSpecialRoom && (
                      <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 bg-amber-950/50 border border-amber-800/60 px-1.5 py-0.5 rounded shrink-0">
                        Special 2-Day
                      </span>
                    )}
                    {room.locked && (
                      <span className="text-[10px] font-mono text-amber-400 flex items-center gap-1 shrink-0">
                        <Lock className="w-3 h-3" />
                        <span>Locked</span>
                      </span>
                    )}
                    {!room.isOpen && (
                      <span className="text-[10px] font-mono text-rose-400 flex items-center gap-1 shrink-0">
                        <DoorClosed className="w-3 h-3" />
                        <span>Closed</span>
                      </span>
                    )}
                  </div>

                  {/* Optional participant counts & unboxed room topic/type */}
                  <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                    <span className="font-mono tabular-nums text-slate-300">
                      {room.participants.length} Participants
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="truncate max-w-[280px] sm:max-w-md">
                      {room.description || (room.isSpecialRoom ? '48-hour pop-up room' : 'Public voice room')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Right: Join Trigger Arrow */}
              <div className="flex items-center gap-2 shrink-0">
                <span className="hidden sm:inline text-xs font-medium text-slate-400 group-hover:text-indigo-400 transition-colors">
                  Join Room
                </span>
                <div className="w-8 h-8 rounded-lg bg-slate-950 border border-slate-800 group-hover:border-indigo-500/50 flex items-center justify-center text-slate-400 group-hover:text-indigo-400 transition-colors">
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create Room Modal (accessible only to Admin/Owner) */}
      {isUserAdminOrOwner && (
        <CreateRoomModal
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
        />
      )}
    </div>
  );
};
