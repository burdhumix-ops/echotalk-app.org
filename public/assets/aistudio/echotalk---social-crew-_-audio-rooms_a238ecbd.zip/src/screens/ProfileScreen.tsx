import React, { useState } from 'react';
import {
  User,
  Shield,
  ShieldAlert,
  Globe,
  Terminal,
  Volume2,
  Trash2,
  Bell,
  Check,
  CheckCircle2,
  Edit2,
  Palette,
  RotateCcw,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserAvatar } from '../components/UserAvatar';
import { ThemeSelector } from '../components/ThemeSelector';
import { AdminVaultSection } from '../components/AdminVaultSection';
import { audioManager } from '../utils/audio';

export const ProfileScreen: React.FC = () => {
  const {
    currentUser,
    setCurrentUser,
    users,
    isAdmin,
    setIsAdmin,
    isUserAdminOrOwner,
    updateOnlineStatus,
    activityLogs,
    clearLogs,
    notifyUser,
  } = useApp();

  const [activeLogCategory, setActiveLogCategory] = useState<string>('All');
  const [isEditingBio, setIsEditingBio] = useState(false);
  const [editedBio, setEditedBio] = useState(currentUser.bio || '');

  const filteredLogs = activeLogCategory === 'All'
    ? activityLogs
    : activityLogs.filter((l) => l.category === activeLogCategory);

  const handleToggleAdmin = () => {
    const nextVal = !isAdmin;
    setIsAdmin(nextVal);
    notifyUser('System', `Admin permissions have been ${nextVal ? 'enabled' : 'revoked'}.`, 'admin');
  };

  const handleTestSound = () => {
    audioManager.playNotificationSound();
  };

  const handleSwitchUser = (user: (typeof users)[0]) => {
    setCurrentUser(user);
    setEditedBio(user.bio || '');
    notifyUser(user.name, `Switched active session to ${user.name}.`, 'info');
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 md:px-6 py-6 pb-24 md:pb-12 space-y-6">
      {/* Page Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight" style={{ color: 'var(--text-main)' }}>
          Profile & App Settings
        </h1>
        {/* Zero-Pill Unboxed Text Metadata */}
        <div className="flex items-center gap-2 text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
          <span>User Profile</span>
          <span aria-hidden="true">·</span>
          <span>6 Modern Themes</span>
          <span aria-hidden="true">·</span>
          <span>Role Permissions</span>
          {isUserAdminOrOwner && (
            <>
              <span aria-hidden="true">·</span>
              <span className="font-semibold text-rose-400">Admin Vault</span>
            </>
          )}
          <span aria-hidden="true">·</span>
          <span className="font-mono text-indigo-400">Dart Logic Console</span>
        </div>
      </div>

      {/* Modern Theme Switcher Card (User Requirement 1) */}
      <div
        className="p-5 rounded-2xl border transition-colors shadow-sm"
        style={{
          backgroundColor: 'var(--bg-surface)',
          borderColor: 'var(--border-theme)',
        }}
      >
        <ThemeSelector />
      </div>

      {/* Secret Admin View-Once Image Vault (User Requirement 2: Admin/Owner only) */}
      {isUserAdminOrOwner && <AdminVaultSection />}

      {/* Two Column Layout: Profile Info & App Preferences / Dart Console */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: User Profile Card & Controls (5 cols) */}
        <div className="md:col-span-5 space-y-5">
          {/* Main User Card */}
          <div
            className="p-5 rounded-2xl border relative transition-colors"
            style={{
              backgroundColor: 'var(--bg-surface)',
              borderColor: 'var(--border-theme)',
            }}
          >
            <div className="flex items-start gap-4">
              <UserAvatar
                src={currentUser.avatar}
                name={currentUser.name}
                size="xl"
                online={currentUser.online}
                showOnlineIndicator
              />

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold truncate" style={{ color: 'var(--text-main)' }}>
                    {currentUser.name}
                  </h2>
                  <span
                    className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-md font-semibold"
                    style={{
                      backgroundColor: 'var(--accent-light)',
                      color: 'var(--accent)',
                      border: '1px solid var(--border-theme)',
                    }}
                  >
                    {currentUser.role || (isAdmin ? 'admin' : 'member')}
                  </span>
                </div>

                {/* Zero-Pill Metadata */}
                <div className="flex items-center gap-2 text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                  <span>{currentUser.country}</span>
                  <span aria-hidden="true">·</span>
                  <span>{currentUser.gender}</span>
                </div>

                <div className="mt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => updateOnlineStatus(currentUser.name, !currentUser.online)}
                    className="text-[11px] font-mono px-2.5 py-1 rounded-lg border transition-colors"
                    style={{
                      backgroundColor: currentUser.online ? 'rgba(16, 185, 129, 0.15)' : 'var(--bg-card)',
                      borderColor: currentUser.online ? 'rgba(16, 185, 129, 0.4)' : 'var(--border-theme)',
                      color: currentUser.online ? '#10b981' : 'var(--text-muted)',
                    }}
                  >
                    Status: {currentUser.online ? 'Online' : 'Offline'}
                  </button>
                </div>
              </div>
            </div>

            {/* Bio */}
            <div className="mt-4 pt-4 border-t" style={{ borderColor: 'var(--border-theme)' }}>
              <div className="flex items-center justify-between text-xs mb-1" style={{ color: 'var(--text-muted)' }}>
                <span>Bio / Status Line</span>
                <button
                  type="button"
                  onClick={() => setIsEditingBio(!isEditingBio)}
                  className="hover:underline flex items-center gap-1 font-medium"
                  style={{ color: 'var(--accent)' }}
                >
                  <Edit2 className="w-3 h-3" />
                  <span>{isEditingBio ? 'Done' : 'Edit'}</span>
                </button>
              </div>

              {isEditingBio ? (
                <div className="mt-1 space-y-2">
                  <textarea
                    value={editedBio}
                    onChange={(e) => setEditedBio(e.target.value)}
                    rows={2}
                    className="w-full p-2.5 rounded-xl text-xs focus:outline-none border"
                    style={{
                      backgroundColor: 'var(--bg-input)',
                      borderColor: 'var(--border-theme)',
                      color: 'var(--text-main)',
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      currentUser.bio = editedBio;
                      setIsEditingBio(false);
                      notifyUser(currentUser.name, 'Profile bio updated.', 'info');
                    }}
                    className="px-3 py-1 rounded-lg text-xs font-semibold text-white transition-opacity hover:opacity-90"
                    style={{ backgroundColor: 'var(--accent)' }}
                  >
                    Save
                  </button>
                </div>
              ) : (
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  {currentUser.bio || 'Product Designer & Sound Enthusiast · San Francisco'}
                </p>
              )}
            </div>
          </div>

          {/* Settings & Admin Controls */}
          <div
            className="p-5 rounded-2xl border space-y-4 transition-colors"
            style={{
              backgroundColor: 'var(--bg-surface)',
              borderColor: 'var(--border-theme)',
            }}
          >
            <h3 className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--text-main)' }}>
              App Preferences
            </h3>

            {/* Admin Mode Toggle */}
            <div
              className="flex items-center justify-between p-3 rounded-xl border"
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-theme)',
              }}
            >
              <div>
                <div className="flex items-center gap-1.5 text-xs font-semibold" style={{ color: 'var(--text-main)' }}>
                  <Shield className="w-3.5 h-3.5" style={{ color: 'var(--accent)' }} />
                  <span>Administrator Mode</span>
                </div>
                <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>
                  Enables room locking, kick commands, and secret View-Once image auditing.
                </p>
              </div>

              <button
                type="button"
                onClick={handleToggleAdmin}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  isAdmin ? 'bg-indigo-600' : 'bg-slate-700'
                }`}
                style={{
                  backgroundColor: isAdmin ? 'var(--accent)' : undefined,
                }}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    isAdmin ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Audio Feedback Test */}
            <div
              className="flex items-center justify-between p-3 rounded-xl border"
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-theme)',
              }}
            >
              <div>
                <div className="flex items-center gap-1.5 text-xs font-semibold" style={{ color: 'var(--text-main)' }}>
                  <Volume2 className="w-3.5 h-3.5" style={{ color: 'var(--accent)' }} />
                  <span>Web Audio Feedback</span>
                </div>
                <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>
                  Chimes for DMs, voice note playback, and room timers.
                </p>
              </div>

              <button
                type="button"
                onClick={handleTestSound}
                className="px-2.5 py-1 text-xs font-medium rounded-lg border transition-colors"
                style={{
                  backgroundColor: 'var(--bg-input)',
                  borderColor: 'var(--border-theme)',
                  color: 'var(--text-main)',
                }}
              >
                Test Chime
              </button>
            </div>

            {/* Switch Active User */}
            <div>
              <label className="block text-xs font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                Simulate Perspective as Crew Member:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {users.map((u) => {
                  const isCurrent = u.name === currentUser.name;
                  return (
                    <button
                      key={u.id}
                      type="button"
                      onClick={() => handleSwitchUser(u)}
                      className="flex items-center gap-2 p-2 rounded-xl text-left border transition-all cursor-pointer"
                      style={{
                        backgroundColor: isCurrent ? 'var(--accent-light)' : 'var(--bg-card)',
                        borderColor: isCurrent ? 'var(--accent)' : 'var(--border-theme)',
                        color: isCurrent ? 'var(--accent)' : 'var(--text-main)',
                      }}
                    >
                      <UserAvatar
                        src={u.avatar}
                        name={u.name}
                        size="xs"
                      />
                      <span className="text-xs truncate font-medium">{u.name.split(' ')[0]}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Dart AppLogic Event Log Console (7 cols) */}
        <div
          className="md:col-span-7 rounded-2xl border flex flex-col overflow-hidden transition-colors"
          style={{
            backgroundColor: 'var(--bg-surface)',
            borderColor: 'var(--border-theme)',
          }}
        >
          {/* Console Header */}
          <div
            className="p-4 border-b flex items-center justify-between gap-3"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-theme)',
            }}
          >
            <div className="flex items-center gap-2" style={{ color: 'var(--accent)' }}>
              <Terminal className="w-4 h-4" />
              <h2 className="text-sm font-bold" style={{ color: 'var(--text-main)' }}>
                AppLogic Dart Execution Console
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={clearLogs}
                className="p-1.5 rounded-lg transition-colors hover:bg-rose-500/20 text-slate-400 hover:text-rose-400"
                title="Clear console logs"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Category Filter Bar */}
          <div
            className="px-4 py-2 border-b flex items-center gap-1.5 overflow-x-auto text-[11px]"
            style={{
              backgroundColor: 'var(--bg-input)',
              borderColor: 'var(--border-theme)',
            }}
          >
            {['All', 'Crew', 'Rooms', 'Admin', 'DMs', 'Timer', 'Utility'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveLogCategory(cat)}
                className={`px-2.5 py-1 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  activeLogCategory === cat
                    ? 'font-medium border'
                    : 'hover:opacity-80'
                }`}
                style={{
                  backgroundColor: activeLogCategory === cat ? 'var(--accent)' : 'transparent',
                  borderColor: activeLogCategory === cat ? 'var(--accent)' : 'transparent',
                  color: activeLogCategory === cat ? '#ffffff' : 'var(--text-muted)',
                }}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Console Logs Body */}
          <div
            className="flex-1 overflow-y-auto p-4 space-y-2 font-mono text-[11px] max-h-[500px]"
            style={{ backgroundColor: 'var(--bg-input)' }}
          >
            {filteredLogs.length === 0 ? (
              <div className="py-16 text-center" style={{ color: 'var(--text-muted)' }}>
                No events logged in this category.
              </div>
            ) : (
              filteredLogs.map((log) => {
                const isDenied = log.action.includes('[BLOCKED]') || log.action.includes('[DENIED]');
                const isAdminAction = log.category === 'Admin';
                const isTimer = log.category === 'Timer';

                return (
                  <div
                    key={log.id}
                    className="p-2 rounded-lg border space-y-0.5"
                    style={{
                      backgroundColor: 'var(--bg-card)',
                      borderColor: 'var(--border-theme)',
                    }}
                  >
                    <div className="flex items-center justify-between text-[10px]" style={{ color: 'var(--text-muted)' }}>
                      <span className="font-semibold" style={{ color: 'var(--accent)' }}>
                        {log.category} · {log.action}
                      </span>
                      <span>{log.timestamp}</span>
                    </div>
                    <div
                      className={`break-words ${
                        isDenied
                          ? 'text-rose-400 font-medium'
                          : isAdminAction
                          ? 'text-amber-300 font-medium'
                          : isTimer
                          ? 'text-emerald-400 font-medium'
                          : ''
                      }`}
                      style={{ color: !isDenied && !isAdminAction && !isTimer ? 'var(--text-main)' : undefined }}
                    >
                      {log.details}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Console Footer */}
          <div
            className="p-3 border-t text-[11px] flex items-center justify-between"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-theme)',
              color: 'var(--text-muted)',
            }}
          >
            <span>Tracking all live Dart print statements</span>
            <span className="font-mono tabular-nums">{filteredLogs.length} entries</span>
          </div>
        </div>
      </div>
    </div>
  );
};
