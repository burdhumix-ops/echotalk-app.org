import React, { useState, useMemo } from 'react';
import { UserPlus, Search, MessageSquare, ArrowUpDown, Globe, UserCheck, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AddUserModal } from '../components/AddUserModal';
import { UserAvatar } from '../components/UserAvatar';
import { User } from '../types';

export const CrewScreen: React.FC = () => {
  const {
    users,
    filterCrew,
    sortCrewOnlineFirst,
    updateUserStatus,
    setActiveDmPartner,
    setActiveTab,
    currentUser,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('All');
  const [selectedGender, setSelectedGender] = useState('All');
  const [onlineFirst, setOnlineFirst] = useState(true);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Extract unique countries
  const countries = useMemo(() => {
    const list = Array.from(new Set(users.map((u) => u.country))).sort();
    return ['All', ...list];
  }, [users]);

  const genders = ['All', 'Female', 'Male', 'Non-Binary'];

  // Apply filters and sort
  const displayedUsers = useMemo(() => {
    // 1. Filter using AppLogic filterCrew
    let filtered = filterCrew({
      country: selectedCountry === 'All' ? undefined : selectedCountry,
      gender: selectedGender === 'All' ? undefined : selectedGender,
    });

    // 2. Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (u) =>
          u.name.toLowerCase().includes(q) ||
          u.country.toLowerCase().includes(q) ||
          (u.bio && u.bio.toLowerCase().includes(q))
      );
    }

    // 3. Sort using AppLogic sortCrewOnlineFirst
    if (onlineFirst) {
      filtered = sortCrewOnlineFirst(filtered);
    } else {
      filtered = [...filtered].sort((a, b) => a.name.localeCompare(b.name));
    }

    return filtered;
  }, [users, filterCrew, sortCrewOnlineFirst, selectedCountry, selectedGender, searchQuery, onlineFirst]);

  const onlineCount = users.filter((u) => u.online).length;
  const totalCount = users.length;

  const handleStartDM = (userName: string) => {
    setActiveDmPartner(userName);
    setActiveTab('DMs');
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 md:px-6 py-6 pb-24 md:pb-12">
      {/* Header and Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Crew Directory</h1>
          {/* Zero-Pill Unboxed Text Metadata */}
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span className="font-mono text-emerald-400 tabular-nums">{onlineCount} Online</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{totalCount} Total Members</span>
            <span aria-hidden="true">·</span>
            <span>{countries.length - 1} Countries</span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsAddModalOpen(true)}
          className="self-start sm:self-auto inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors shadow-sm whitespace-nowrap shrink-0 active:scale-95"
        >
          <UserPlus className="w-4 h-4" />
          <span>Add Crew Member</span>
        </button>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 mb-6 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search crew by name, country, or bio..."
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Country Selector */}
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-slate-500 shrink-0 hidden sm:block" />
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="w-full sm:w-auto px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
            >
              <option value="All">All Countries ({countries.length - 1})</option>
              {countries
                .filter((c) => c !== 'All')
                .map((country) => (
                  <option key={country} value={country}>
                    {country}
                  </option>
                ))}
            </select>

            {/* Online First Sort Toggle */}
            <button
              type="button"
              onClick={() => setOnlineFirst(!onlineFirst)}
              className={`px-3 py-2 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                onlineFirst
                  ? 'bg-indigo-950/60 border-indigo-500/40 text-indigo-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
              title="Toggle sorting order"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>{onlineFirst ? 'Online First' : 'A-Z Sort'}</span>
            </button>
          </div>
        </div>

        {/* Gender Filter Interactive Buttons */}
        <div className="flex items-center gap-1.5 pt-1 overflow-x-auto text-xs">
          <span className="text-slate-500 mr-1.5 shrink-0">Gender:</span>
          {genders.map((g) => {
            const isSelected = selectedGender === g;
            return (
              <button
                key={g}
                type="button"
                onClick={() => setSelectedGender(g)}
                className={`px-3 py-1 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  isSelected
                    ? 'bg-slate-800 text-white font-medium border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                {g}
              </button>
            );
          })}
        </div>
      </div>

      {/* Crew Cards Grid */}
      {displayedUsers.length === 0 ? (
        <div className="py-16 text-center bg-slate-900/40 border border-slate-800/60 rounded-2xl">
          <p className="text-sm text-slate-400">No crew members match the selected filters.</p>
          <button
            type="button"
            onClick={() => {
              setSelectedCountry('All');
              setSelectedGender('All');
              setSearchQuery('');
            }}
            className="mt-3 text-xs text-indigo-400 hover:underline"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {displayedUsers.map((user) => (
            <div
              key={user.id}
              className="p-4 bg-slate-900/80 border border-slate-800/80 rounded-2xl hover:border-slate-700/80 transition-all flex flex-col justify-between group"
            >
              <div>
                {/* User Top Row */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <UserAvatar
                      src={user.avatar}
                      name={user.name}
                      size="lg"
                      online={user.online}
                      showOnlineIndicator
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-sm font-semibold text-white truncate">{user.name}</h3>
                        {user.role === 'admin' && (
                          <span title="Admin">
                            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                          </span>
                        )}
                      </div>
                      {/* Zero-Pill Metadata */}
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-0.5">
                        <span>{user.country}</span>
                        <span aria-hidden="true">·</span>
                        <span>{user.gender}</span>
                      </div>
                    </div>
                  </div>

                  {/* Online/Offline Status Pill Toggle */}
                  <button
                    type="button"
                    onClick={() => updateUserStatus(user.name, !user.online)}
                    className={`text-[10px] font-mono px-2 py-1 rounded-md transition-colors ${
                      user.online
                        ? 'text-emerald-400 bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-800/40'
                        : 'text-slate-400 bg-slate-950/60 hover:bg-slate-800/60 border border-slate-800'
                    }`}
                    title="Click to toggle online status (AppLogic: updateUserStatus)"
                  >
                    {user.online ? 'Online' : 'Offline'}
                  </button>
                </div>

                {/* Bio */}
                <p className="text-xs text-slate-300/90 leading-relaxed mb-4 line-clamp-2">
                  {user.bio || 'Active participant in EchoTalk voice sessions.'}
                </p>
              </div>

              {/* Bottom Actions */}
              <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between gap-2">
                <span className="text-[10px] font-mono text-slate-500">
                  Joined {user.joinedAt || '2026'}
                </span>

                {user.name !== currentUser.name ? (
                  <button
                    type="button"
                    onClick={() => handleStartDM(user.name)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-indigo-300 hover:text-white bg-indigo-950/40 hover:bg-indigo-900/50 border border-indigo-800/40 rounded-xl transition-colors"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Send DM</span>
                  </button>
                ) : (
                  <span className="text-[10px] text-slate-400 font-medium px-2 py-1 bg-slate-800/60 rounded-md">
                    You (Current)
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add User Modal */}
      <AddUserModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} />
    </div>
  );
};
