/**
 * Audio helper for EchoTalk
 * Handles Web Audio API sounds, synthetic voice note synthesis, and MediaRecorder recording.
 */

class AudioManager {
  private ctx: AudioContext | null = null;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  /**
   * Play a clean, subtle UI sound
   */
  playNotificationSound() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12); // A5

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch (e) {
      console.warn('Audio play error', e);
    }
  }

  /**
   * Play sent message chime
   */
  playSendSound() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, ctx.currentTime); // A4
      osc.frequency.exponentialRampToValueAtTime(659.25, ctx.currentTime + 0.08); // E5

      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    } catch (e) {
      console.warn('Audio play error', e);
    }
  }

  /**
   * Synthesize a realistic voice note audio clip (harmonized formant simulation)
   * that can be played on demand when no actual audio file is present.
   */
  playSimulatedVoiceNote(seed: string = 'echo', duration: number = 3, onProgress?: (ratio: number) => void, onEnded?: () => void) {
    try {
      const ctx = this.getContext();
      if (!ctx) {
        onEnded?.();
        return () => {};
      }

      // Generate distinct frequencies from seed
      let hash = 0;
      for (let i = 0; i < seed.length; i++) {
        hash = (hash << 5) - hash + seed.charCodeAt(i);
      }
      const baseFreq = 160 + (Math.abs(hash) % 120); // 160-280Hz human voice register

      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(baseFreq, ctx.currentTime);

      // Modulate frequency to mimic speech prosody
      const now = ctx.currentTime;
      const steps = Math.floor(duration * 4);
      for (let s = 1; s <= steps; s++) {
        const timeOffset = (s / steps) * duration;
        const pitchDrift = baseFreq + Math.sin(s * 1.5) * 35;
        osc.frequency.linearRampToValueAtTime(pitchDrift, now + timeOffset);
      }

      // Vocal formant filter
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(800, now);
      filter.Q.setValueAtTime(3.5, now);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.12, now + 0.08);
      gain.gain.setValueAtTime(0.12, now + duration - 0.1);
      gain.gain.linearRampToValueAtTime(0.001, now + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + duration);

      const startTime = performance.now();
      const interval = setInterval(() => {
        const elapsed = (performance.now() - startTime) / 1000;
        const ratio = Math.min(1, elapsed / duration);
        onProgress?.(ratio);
        if (ratio >= 1) {
          clearInterval(interval);
          onEnded?.();
        }
      }, 50);

      return () => {
        clearInterval(interval);
        try {
          osc.stop();
          osc.disconnect();
        } catch {
          // ignore
        }
        onEnded?.();
      };
    } catch {
      onEnded?.();
      return () => {};
    }
  }
}

export const audioManager = new AudioManager();

/**
 * Microphone voice recorder helper
 */
export class VoiceRecorder {
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private stream: MediaStream | null = null;

  async start(): Promise<boolean> {
    try {
      this.audioChunks = [];
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.mediaRecorder = new MediaRecorder(this.stream);

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.audioChunks.push(event.data);
        }
      };

      this.mediaRecorder.start(100);
      return true;
    } catch (err) {
      console.warn('Microphone access denied or unavailable', err);
      return false;
    }
  }

  stop(): Promise<{ audioUrl: string; duration: number } | null> {
    return new Promise((resolve) => {
      if (!this.mediaRecorder || this.mediaRecorder.state === 'inactive') {
        resolve(null);
        return;
      }

      this.mediaRecorder.onstop = () => {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        
        // Stop stream tracks
        if (this.stream) {
          this.stream.getTracks().forEach((track) => track.stop());
        }

        resolve({ audioUrl, duration: Math.max(1, Math.round(this.audioChunks.length * 0.1)) });
      };

      this.mediaRecorder.stop();
    });
  }

  cancel() {
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
    }
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
    }
  }
}
