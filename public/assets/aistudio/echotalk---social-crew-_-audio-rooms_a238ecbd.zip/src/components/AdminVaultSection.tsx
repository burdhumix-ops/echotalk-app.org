import React, { useState } from 'react';
import {
  ShieldAlert,
  Eye,
  Trash2,
  Lock,
  Clock,
  User,
  ArrowRight,
  Sparkles,
  X,
  AlertTriangle,
  CheckCircle2,
  FileQuestion,
  Maximize2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AdminViewOnceVaultItem } from '../types';

export const AdminVaultSection: React.FC = () => {
  const { isUserAdminOrOwner, adminViewOnceVault, deleteVaultItem, clearAdminVault, notifyUser } = useApp();
  const [selectedItem, setSelectedItem] = useState<AdminViewOnceVaultItem | null>(null);
  const [isConfirmingClear, setIsConfirmingClear] = useState(false);

  // Hidden strictly from standard public members
  if (!isUserAdminOrOwner) {
    return null;
  }

  const handleClear = () => {
    clearAdminVault();
    setIsConfirmingClear(false);
    notifyUser('Admin', 'All logged view-once images purged from secret vault.', 'admin');
  };

  const handleDeleteOne = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteVaultItem(id);
    if (selectedItem?.id === id) {
      setSelectedItem(null);
    }
    notifyUser('Admin', 'View-once audit record removed.', 'admin');
  };

  return (
    <div
      className="p-5 rounded-2xl border transition-colors space-y-4"
      style={{
        backgroundColor: 'var(--bg-surface)',
        borderColor: 'var(--border-theme)',
      }}
    >
      {/* Header with Secret Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/5">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
              <ShieldAlert className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-sm font-bold flex items-center gap-2" style={{ color: 'var(--text-main)' }}>
              <span>Secret 'View-Once' Media Vault</span>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/30">
                Admin Exclusive
              </span>
            </h3>
          </div>
          <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
            Invisible to public users. Every ephemeral doodle and photo transmitted in DMs is permanently logged here for compliance and moderation.
          </p>
        </div>

        {/* Clear All / Counter */}
        <div className="flex items-center gap-2 shrink-0">
          <span
            className="text-xs font-mono px-2.5 py-1 rounded-lg border"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-theme)',
              color: 'var(--text-main)',
            }}
          >
            {adminViewOnceVault.length} {adminViewOnceVault.length === 1 ? 'record' : 'records'}
          </span>

          {adminViewOnceVault.length > 0 && (
            <>
              {isConfirmingClear ? (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleClear}
                    className="px-2.5 py-1 text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white rounded-lg transition-colors"
                  >
                    Confirm Wipe
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsConfirmingClear(false)}
                    className="px-2 py-1 text-xs text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsConfirmingClear(true)}
                  className="px-2.5 py-1 text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 border border-rose-900/60 rounded-lg transition-colors flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Wipe Vault</span>
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Grid of Logged Media */}
      {adminViewOnceVault.length === 0 ? (
        <div
          className="p-8 rounded-xl text-center border border-dashed"
          style={{
            borderColor: 'var(--border-theme)',
            backgroundColor: 'var(--bg-card)',
          }}
        >
          <Lock className="w-8 h-8 mx-auto text-slate-500 mb-2 opacity-60" />
          <p className="text-xs font-medium" style={{ color: 'var(--text-main)' }}>
            No ephemeral media logged yet
          </p>
          <p className="text-[11px] mt-1" style={{ color: 'var(--text-muted)' }}>
            When users send "View-Once" photos or doodles in DMs, a permanent backup will automatically appear here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {adminViewOnceVault.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedItem(item)}
              className="group relative flex flex-col p-3 rounded-xl border transition-all cursor-pointer hover:border-indigo-400/60 overflow-hidden"
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-theme)',
              }}
            >
              {/* Media Thumbnail with Screenshot Protection */}
              <div
                className="relative w-full h-36 rounded-lg bg-black/40 overflow-hidden flex items-center justify-center border border-white/5 no-screenshot select-none"
                onContextMenu={(e) => e.preventDefault()}
                onDragStart={(e) => e.preventDefault()}
              >
                <img
                  src={item.image}
                  alt={item.caption || (item.isDoodle ? 'Vault doodle' : 'Vault image')}
                  className="w-full h-full object-contain pointer-events-none group-hover:scale-105 transition-transform duration-300"
                />

                {/* Status Badges */}
                <div className="absolute top-2 left-2 flex items-center gap-1">
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/80 backdrop-blur-md text-white font-medium border border-white/10">
                    {item.isDoodle ? '🎨 Doodle' : '📷 Photo'}
                  </span>
                  {item.openedByRecipient ? (
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-950/90 text-amber-300 border border-amber-800/80 font-medium">
                      Opened
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950/90 text-emerald-300 border border-emerald-800/80 font-medium">
                      Unopened
                    </span>
                  )}
                </div>

                {/* Inspect Overlay Prompt */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 text-white text-xs font-semibold backdrop-blur-[2px]">
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>Inspect Audit File</span>
                </div>

                {/* Delete button */}
                <button
                  type="button"
                  onClick={(e) => handleDeleteOne(item.id, e)}
                  className="absolute top-2 right-2 p-1 rounded-md bg-black/70 hover:bg-rose-900/80 text-slate-400 hover:text-white transition-colors"
                  title="Purge this audit record"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>

              {/* Transmission Metadata */}
              <div className="mt-2.5 space-y-1">
                <div className="flex items-center justify-between text-xs font-semibold" style={{ color: 'var(--text-main)' }}>
                  <div className="flex items-center gap-1 truncate max-w-[170px]">
                    <span className="text-indigo-400 truncate">{item.senderName}</span>
                    <ArrowRight className="w-2.5 h-2.5 shrink-0 text-slate-500" />
                    <span className="truncate">{item.recipientName}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{item.capturedAt}</span>
                </div>

                {item.caption && (
                  <p className="text-[11px] truncate italic" style={{ color: 'var(--text-muted)' }}>
                    "{item.caption}"
                  </p>
                )}

                <div className="text-[10px] flex items-center gap-2 pt-1 border-t border-white/5" style={{ color: 'var(--text-muted)' }}>
                  <span>Public Status:</span>
                  {item.openedByRecipient ? (
                    <span className="text-amber-400 font-medium">Disappeared for recipient ({item.openedAt || 'opened'})</span>
                  ) : (
                    <span className="text-slate-400">Waiting for 1-time tap</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Admin Inspector Lightbox Modal */}
      {selectedItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200 select-none no-screenshot"
          onContextMenu={(e) => e.preventDefault()}
        >
          <div
            className="relative w-full max-w-3xl rounded-3xl border overflow-hidden shadow-2xl flex flex-col"
            style={{
              backgroundColor: 'var(--bg-surface)',
              borderColor: 'var(--border-theme)',
            }}
          >
            {/* Modal Header */}
            <div
              className="p-4 border-b flex items-center justify-between"
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-theme)',
              }}
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold" style={{ color: 'var(--text-main)' }}>
                      Audit Inspector: {selectedItem.isDoodle ? 'Hand-Drawn Doodle' : 'Original Photo'}
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/30">
                      Vault ID: {selectedItem.id.slice(0, 12)}
                    </span>
                  </div>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                    Sent by <strong className="text-indigo-400">{selectedItem.senderName}</strong> to{' '}
                    <strong className="text-slate-200">{selectedItem.recipientName}</strong> at {selectedItem.capturedAt}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                className="p-2 rounded-xl bg-black/30 hover:bg-black/60 text-slate-300 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* High-Res Media Container */}
            <div
              className="relative p-6 flex items-center justify-center min-h-[380px] max-h-[65vh] overflow-hidden no-screenshot"
              style={{ backgroundColor: 'var(--bg-app)' }}
              onContextMenu={(e) => e.preventDefault()}
              onDragStart={(e) => e.preventDefault()}
            >
              <img
                src={selectedItem.image}
                alt="Audit record"
                className="max-h-[60vh] max-w-full rounded-2xl object-contain shadow-2xl border border-white/10 pointer-events-none"
              />

              {/* Watermark Overlay for screenshot deterrence */}
              <div className="absolute bottom-4 right-4 text-[10px] font-mono px-2.5 py-1 rounded bg-black/70 backdrop-blur-md text-slate-400 border border-white/10 select-none pointer-events-none">
                ECHOTALK ADMIN VAULT · CONFIDENTIAL AUDIT
              </div>
            </div>

            {/* Modal Footer with Actions & Diagnostic Metadata */}
            <div
              className="p-4 border-t flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-theme)',
              }}
            >
              <div className="flex items-center gap-3" style={{ color: 'var(--text-muted)' }}>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Recipient Status: {selectedItem.openedByRecipient ? `Opened & Disappeared (${selectedItem.openedAt || 'viewed'})` : 'Unviewed in DM chat'}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={(e) => handleDeleteOne(selectedItem.id, e)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-600/20 hover:bg-rose-600/40 text-rose-300 border border-rose-500/30 transition-colors flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Purge from Vault</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedItem(null)}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                >
                  Close Inspector
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
