import React, { useRef, useState, useEffect } from 'react';
import { X, Send, RotateCcw, Trash2, Paintbrush, Eraser, EyeOff, Sparkles } from 'lucide-react';

interface DoodleCanvasModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendDoodle: (dataUrl: string, isViewOnce: boolean) => void;
  recipientName: string;
}

const COLORS = [
  '#ffffff', // White
  '#818cf8', // Indigo
  '#38bdf8', // Cyan
  '#34d399', // Emerald
  '#fbbf24', // Amber
  '#fb7185', // Rose
  '#c084fc', // Purple
  '#f97316', // Orange
];

const STROKE_SIZES = [
  { label: 'Fine', value: 3 },
  { label: 'Medium', value: 6 },
  { label: 'Bold', value: 12 },
  { label: 'Highlighter', value: 24 },
];

export const DoodleCanvasModal: React.FC<DoodleCanvasModalProps> = ({
  isOpen,
  onClose,
  onSendDoodle,
  recipientName,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedColor, setSelectedColor] = useState('#818cf8');
  const [selectedSize, setSelectedSize] = useState(6);
  const [isEraser, setIsEraser] = useState(false);
  const [isViewOnce, setIsViewOnce] = useState(false);
  const [history, setHistory] = useState<ImageData[]>([]);
  const isDrawingRef = useRef(false);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (isOpen) {
      // Initialize canvas
      const timer = setTimeout(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Set high DPR resolution
        const dpr = window.devicePixelRatio || 1;
        const rect = canvas.getBoundingClientRect();
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        ctx.scale(dpr, dpr);

        // Fill background with dark chalkboard slate
        ctx.fillStyle = '#090d16';
        ctx.fillRect(0, 0, rect.width, rect.height);

        // Save initial blank state
        setHistory([ctx.getImageData(0, 0, canvas.width, canvas.height)]);
      }, 50);

      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const saveHistorySnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const snap = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setHistory((prev) => [...prev.slice(-15), snap]);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture(e.pointerId);
    isDrawingRef.current = true;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    lastPointRef.current = { x, y };

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = isEraser ? '#090d16' : selectedColor;
    ctx.lineWidth = selectedSize;

    // Draw single point
    ctx.beginPath();
    ctx.arc(x, y, selectedSize / 2, 0, Math.PI * 2);
    ctx.fillStyle = isEraser ? '#090d16' : selectedColor;
    ctx.fill();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current || !lastPointRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(lastPointRef.current.x, lastPointRef.current.y);
    ctx.lineTo(x, y);
    ctx.stroke();

    lastPointRef.current = { x, y };
  };

  const handlePointerUp = () => {
    if (isDrawingRef.current) {
      isDrawingRef.current = false;
      lastPointRef.current = null;
      saveHistorySnapshot();
    }
  };

  const handleUndo = () => {
    if (history.length <= 1) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const newHistory = history.slice(0, -1);
    const previousState = newHistory[newHistory.length - 1];
    if (previousState) {
      ctx.putImageData(previousState, 0, 0);
      setHistory(newHistory);
    }
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, rect.width, rect.height);
    saveHistorySnapshot();
  };

  const handleSend = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    onSendDoodle(dataUrl, isViewOnce);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100 max-h-[92vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white leading-none">Doodle Canvas</h3>
              <p className="text-[11px] text-slate-400 mt-1">Drawing to {recipientName}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Close doodle"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar: Color picker & tools */}
        <div className="p-3 border-b border-slate-800/80 bg-slate-950/40 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Colors */}
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => {
                  setSelectedColor(c);
                  setIsEraser(false);
                }}
                className={`w-6 h-6 rounded-full transition-transform shrink-0 ${
                  !isEraser && selectedColor === c
                    ? 'scale-125 ring-2 ring-indigo-400 ring-offset-2 ring-offset-slate-900'
                    : 'hover:scale-110'
                }`}
                style={{ backgroundColor: c }}
                title={`Color ${c}`}
              />
            ))}
          </div>

          {/* Stroke Widths & Tools */}
          <div className="flex items-center gap-2">
            {/* Eraser */}
            <button
              type="button"
              onClick={() => setIsEraser(!isEraser)}
              className={`p-1.5 rounded-lg border transition-colors ${
                isEraser
                  ? 'bg-indigo-600 border-indigo-500 text-white'
                  : 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:text-white'
              }`}
              title="Eraser tool"
            >
              <Eraser className="w-3.5 h-3.5" />
            </button>

            {/* Stroke sizes */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
              {STROKE_SIZES.map((s) => (
                <button
                  key={s.value}
                  type="button"
                  onClick={() => setSelectedSize(s.value)}
                  className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                    selectedSize === s.value
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {/* Undo */}
            <button
              type="button"
              onClick={handleUndo}
              disabled={history.length <= 1}
              className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 disabled:opacity-40 text-slate-300 hover:text-white transition-colors"
              title="Undo last stroke"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            {/* Clear */}
            <button
              type="button"
              onClick={handleClear}
              className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-rose-950/60 text-slate-300 hover:text-rose-400 transition-colors"
              title="Clear canvas"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Drawing Canvas Area */}
        <div className="relative flex-1 min-h-[300px] h-[45vh] bg-[#090d16] p-2 flex items-center justify-center touch-none">
          <canvas
            ref={canvasRef}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            className="w-full h-full rounded-2xl cursor-crosshair border border-slate-800/80 shadow-inner"
          />
        </div>

        {/* Footer: View-Once Toggle & Send */}
        <div className="p-3.5 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between gap-3">
          {/* View Once Toggle Button */}
          <button
            type="button"
            onClick={() => setIsViewOnce(!isViewOnce)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              isViewOnce
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-xs'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="When enabled, doodle can only be viewed once by the recipient"
          >
            <div
              className={`w-4 h-4 rounded-full flex items-center justify-center font-mono text-[10px] font-bold ${
                isViewOnce ? 'bg-amber-400 text-slate-950' : 'bg-slate-700 text-slate-300'
              }`}
            >
              1
            </div>
            <span>{isViewOnce ? 'View Once: ON' : 'View Once: OFF'}</span>
          </button>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSend}
              className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-xs font-semibold text-white shadow-sm transition-all active:scale-95"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Doodle</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
