import React, { useState, useEffect } from 'react';
import { Play, Pause, Mic } from 'lucide-react';
import { audioManager } from '../utils/audio';

interface AudioWaveformProps {
  voiceNoteId?: string;
  audioUrl?: string;
  duration?: number;
  seed?: string;
  senderName?: string;
  isSentByMe?: boolean;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({
  audioUrl,
  duration = 4,
  seed = 'echo-note',
  isSentByMe = false,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0); // 0 to 1
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  // Generate deterministic pseudo waveform heights based on seed
  const barHeights = React.useMemo(() => {
    const bars: number[] = [];
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      hash = (hash << 5) - hash + seed.charCodeAt(i);
    }
    const count = 18;
    for (let i = 0; i < count; i++) {
      const pseudo = Math.abs(Math.sin((hash + i * 17) * 0.4));
      bars.push(Math.max(15, Math.floor(pseudo * 85)));
    }
    return bars;
  }, [seed]);

  useEffect(() => {
    if (audioUrl && !audioUrl.startsWith('voice-sample')) {
      const audio = new Audio(audioUrl);
      audio.onended = () => {
        setIsPlaying(false);
        setProgress(0);
      };
      audio.ontimeupdate = () => {
        if (audio.duration) {
          setProgress(audio.currentTime / audio.duration);
        }
      };
      setAudioElement(audio);
      return () => {
        audio.pause();
      };
    }
  }, [audioUrl]);

  const togglePlay = () => {
    if (isPlaying) {
      if (audioElement) {
        audioElement.pause();
      }
      setIsPlaying(false);
      setProgress(0);
      return;
    }

    setIsPlaying(true);
    if (audioElement) {
      audioElement.currentTime = 0;
      audioElement.play().catch(() => {
        setIsPlaying(false);
      });
    } else {
      // Use synthetic voice simulator
      audioManager.playSimulatedVoiceNote(
        seed,
        duration,
        (ratio) => setProgress(ratio),
        () => {
          setIsPlaying(false);
          setProgress(0);
        }
      );
    }
  };

  const currentSeconds = Math.floor(progress * duration);
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div
      className={`flex items-center gap-3 px-3 py-2 rounded-xl transition-colors ${
        isSentByMe
          ? 'bg-indigo-600/30 text-indigo-100 border border-indigo-500/30'
          : 'bg-slate-800/80 text-slate-200 border border-slate-700/60'
      }`}
    >
      <button
        type="button"
        onClick={togglePlay}
        aria-label={isPlaying ? 'Pause voice note' : 'Play voice note'}
        className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-95 ${
          isSentByMe
            ? 'bg-indigo-500 hover:bg-indigo-400 text-white'
            : 'bg-slate-700 hover:bg-slate-600 text-slate-100'
        }`}
      >
        {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
      </button>

      {/* Waveform Visualizer */}
      <div className="flex-1 min-w-[120px] max-w-[200px]">
        <div className="flex items-center gap-[2.5px] h-7">
          {barHeights.map((h, idx) => {
            const barRatio = idx / barHeights.length;
            const isFilled = progress >= barRatio;
            return (
              <span
                key={idx}
                className="w-1 rounded-full transition-all duration-75"
                style={{
                  height: `${h}%`,
                  backgroundColor: isFilled
                    ? isSentByMe
                      ? '#818cf8'
                      : '#38bdf8'
                    : isSentByMe
                    ? 'rgba(129, 140, 248, 0.25)'
                    : 'rgba(148, 163, 184, 0.25)',
                }}
              />
            );
          })}
        </div>
      </div>

      {/* Timestamp & Duration */}
      <div className="flex items-center gap-1 text-[11px] font-mono tabular-nums text-slate-400 shrink-0">
        <Mic className="w-3 h-3 text-slate-500" />
        <span>{isPlaying ? formatTime(currentSeconds) : formatTime(duration)}</span>
      </div>
    </div>
  );
};
