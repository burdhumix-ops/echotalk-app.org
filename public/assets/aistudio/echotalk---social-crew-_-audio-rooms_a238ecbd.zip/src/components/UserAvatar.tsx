import React, { useState } from 'react';

interface UserAvatarProps {
  src?: string;
  name: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  online?: boolean;
  showOnlineIndicator?: boolean;
}

const SIZE_MAP = {
  xs: { container: 'w-6 h-6 text-[10px]', indicator: 'w-2 h-2 -bottom-0.5 -right-0.5 border' },
  sm: { container: 'w-8 h-8 text-xs', indicator: 'w-2.5 h-2.5 -bottom-0.5 -right-0.5 border-2' },
  md: { container: 'w-10 h-10 text-xs font-semibold', indicator: 'w-3 h-3 -bottom-0.5 -right-0.5 border-2' },
  lg: { container: 'w-12 h-12 text-sm font-bold', indicator: 'w-3.5 h-3.5 -bottom-1 -right-1 border-2' },
  xl: { container: 'w-16 h-16 text-base font-bold', indicator: 'w-4 h-4 -bottom-1 -right-1 border-2' },
};

const GRADIENTS = [
  'from-indigo-600 to-violet-700',
  'from-blue-600 to-cyan-700',
  'from-emerald-600 to-teal-700',
  'from-amber-600 to-orange-700',
  'from-rose-600 to-pink-700',
  'from-purple-600 to-indigo-800',
  'from-cyan-600 to-blue-800',
];

export const UserAvatar: React.FC<UserAvatarProps> = ({
  src,
  name,
  size = 'md',
  className = '',
  online,
  showOnlineIndicator = false,
}) => {
  const [imageFailed, setImageFailed] = useState(false);

  // Deterministic gradient choice based on name
  const gradient = React.useMemo(() => {
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = (hash << 5) - hash + name.charCodeAt(i);
    }
    return GRADIENTS[Math.abs(hash) % GRADIENTS.length];
  }, [name]);

  const initials = React.useMemo(() => {
    if (!name.trim()) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }, [name]);

  const { container: sizeClass, indicator: indicatorClass } = SIZE_MAP[size] || SIZE_MAP.md;

  return (
    <div className={`relative shrink-0 select-none ${className}`}>
      {!imageFailed && src ? (
        <img
          src={src}
          alt={name}
          referrerPolicy="no-referrer"
          onError={() => setImageFailed(true)}
          className={`${sizeClass} rounded-2xl object-cover ring-1 ring-slate-800/80 shadow-xs`}
        />
      ) : (
        <div
          className={`${sizeClass} rounded-2xl bg-gradient-to-br ${gradient} text-white flex items-center justify-center font-bold tracking-tight ring-1 ring-white/10 shadow-xs`}
        >
          {initials}
        </div>
      )}

      {showOnlineIndicator && typeof online === 'boolean' && (
        <span
          className={`absolute rounded-full border-slate-950 ${indicatorClass} ${
            online ? 'bg-emerald-500' : 'bg-slate-600'
          }`}
          title={online ? 'Online' : 'Offline'}
        />
      )}
    </div>
  );
};
