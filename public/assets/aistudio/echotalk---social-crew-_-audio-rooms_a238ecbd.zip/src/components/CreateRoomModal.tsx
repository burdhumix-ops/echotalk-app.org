import React, { useState } from 'react';
import { X, PlusCircle, Lock, ShieldAlert } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface CreateRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateRoomModal: React.FC<CreateRoomModalProps> = ({ isOpen, onClose }) => {
  const { createRoom, rooms, setCurrentRoomName, isUserAdminOrOwner } = useApp();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isSpecialRoom, setIsSpecialRoom] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !isUserAdminOrOwner) return null;

  const existingSpecialRoom = rooms.find((r) => r.isSpecialRoom);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide a room name.');
      return;
    }
    const res = createRoom(name.trim(), {
      isSpecialRoom,
      description: description.trim() || undefined,
    });
    if (!res.success) {
      setError(res.error || 'Failed to create room.');
      return;
    }
    setCurrentRoomName(name.trim());
    setName('');
    setDescription('');
    setIsSpecialRoom(false);
    setError('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative text-slate-100">
        <button
          onClick={onClose}
          type="button"
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-1 text-indigo-400">
          <PlusCircle className="w-5 h-5" />
          <h2 className="text-lg font-bold text-white">Create New Room</h2>
        </div>
        <p className="text-xs text-slate-400 mb-5">
          Spin up an audio and text room for the EchoTalk community.
        </p>

        {error && (
          <div className="mb-4 text-xs text-rose-400 bg-rose-950/40 border border-rose-800/60 rounded-lg p-2.5">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Room Name
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Ambient Synthesis Room"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Description / Topic
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Weekly voice jam & feedback"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Special Room Checkbox (Rule: Only 1 special room can be locked!) */}
          <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={isSpecialRoom}
                disabled={Boolean(existingSpecialRoom)}
                onChange={(e) => setIsSpecialRoom(e.target.checked)}
                className="mt-1 rounded bg-slate-900 border-slate-700 text-indigo-600 focus:ring-indigo-500"
              />
              <div>
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Mark as Special Room (Lockable)</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                  Per app logic specifications, only 1 special room can be locked/unlocked by administrators.
                </p>
                {existingSpecialRoom && (
                  <div className="flex items-center gap-1 text-[11px] text-amber-400/90 mt-1 font-mono">
                    <ShieldAlert className="w-3 h-3" />
                    <span>Special room already set: "{existingSpecialRoom.name}"</span>
                  </div>
                )}
              </div>
            </label>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors shadow-sm"
            >
              Create Room
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
