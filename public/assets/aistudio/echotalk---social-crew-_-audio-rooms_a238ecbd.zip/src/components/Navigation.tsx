import React from 'react';
import { Users, Radio, MessageSquare, UserCheck, Shield, Bell, Lock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserAvatar } from './UserAvatar';

export interface NavButtonProps {
  title: 'Crew' | 'Rooms' | 'DMs' | 'Profile';
  activeTab: 'Crew' | 'Rooms' | 'DMs' | 'Profile';
  setActiveTab: (tab: 'Crew' | 'Rooms' | 'DMs' | 'Profile') => void;
  badge?: number;
  icon?: React.ElementType;
}

/**
 * Reusable NavButton matching App.js specification
 */
export const NavButton: React.FC<NavButtonProps> = ({
  title,
  activeTab,
  setActiveTab,
  badge,
  icon: Icon,
}) => {
  const isActive = activeTab === title;

  return (
    <button
      type="button"
      className="nav-button relative flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-150 select-none cursor-pointer"
      style={{
        backgroundColor: isActive ? 'var(--accent)' : 'transparent',
        color: isActive ? '#ffffff' : 'var(--text-muted)',
        boxShadow: isActive ? '0 0 14px var(--accent-glow)' : 'none',
      }}
      onClick={() => setActiveTab(title)}
    >
      {Icon && <Icon className="w-3.5 h-3.5" style={{ color: isActive ? '#ffffff' : 'var(--text-muted)' }} />}
      <span>{title}</span>
      {typeof badge === 'number' && badge > 0 && (
        <span
          className="min-w-[16px] h-4 px-1 rounded-full text-[10px] font-mono flex items-center justify-center font-bold"
          style={{
            backgroundColor: isActive ? '#ffffff' : 'var(--accent)',
            color: isActive ? 'var(--accent)' : '#ffffff',
          }}
        >
          {badge}
        </span>
      )}
    </button>
  );
};

export const TopBar: React.FC<{ onOpenNotifications?: () => void }> = ({ onOpenNotifications }) => {
  const { currentUser, isAdmin, notifications, activeTab, setActiveTab, dmList } = useApp();
  const unreadCount = notifications.filter((n) => !n.read).length;
  const unreadDMs = dmList.filter((d) => d.to === currentUser.name).length;

  const tabs: Array<{ id: 'Crew' | 'Rooms' | 'DMs' | 'Profile'; label: 'Crew' | 'Rooms' | 'DMs' | 'Profile'; icon: React.ElementType; badge?: number }> = [
    { id: 'Crew', label: 'Crew', icon: Users },
    { id: 'Rooms', label: 'Rooms', icon: Radio },
    { id: 'DMs', label: 'DMs', icon: MessageSquare, badge: unreadDMs },
    { id: 'Profile', label: 'Profile', icon: UserCheck },
  ];

  return (
    <header
      className="sticky top-0 z-30 backdrop-blur-md border-b transition-colors duration-200"
      style={{
        backgroundColor: 'var(--bg-surface)',
        borderColor: 'var(--border-theme)',
      }}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-3 flex items-center justify-between gap-4">
        {/* Brand Zone */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('Crew')}
            className="text-lg font-bold tracking-tight hover:opacity-85 transition-opacity whitespace-nowrap shrink-0 flex items-center gap-2 cursor-pointer"
            style={{ color: 'var(--text-main)' }}
          >
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center border"
              style={{
                backgroundColor: 'var(--accent-light)',
                borderColor: 'var(--border-theme)',
                color: 'var(--accent)',
              }}
            >
              <Radio className="w-4 h-4" />
            </div>
            <span>EchoTalk</span>
          </button>
        </div>

        {/* Center Zone: Segmented Nav Buttons */}
        <nav
          className="flex items-center gap-1.5 p-1 rounded-2xl border transition-colors shadow-inner"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--border-theme)',
          }}
        >
          {tabs.map((tab) => (
            <NavButton
              key={tab.id}
              title={tab.label}
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              badge={tab.badge}
              icon={tab.icon}
            />
          ))}
        </nav>

        {/* Right Zone: Notifications & Current User Info */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenNotifications}
            className="relative min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border transition-colors cursor-pointer hover:opacity-90"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-theme)',
              color: 'var(--text-muted)',
            }}
            aria-label="View notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span
                className="absolute top-1 right-1 w-4 h-4 rounded-full text-[10px] font-mono flex items-center justify-center font-bold text-white"
                style={{ backgroundColor: 'var(--accent)' }}
              >
                {unreadCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('Profile')}
            className="flex items-center gap-2 pl-1 pr-2.5 py-1 rounded-xl border transition-colors text-left cursor-pointer hover:opacity-90"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-theme)',
            }}
          >
            <UserAvatar
              src={currentUser.avatar}
              name={currentUser.name}
              size="sm"
              online={currentUser.online}
              showOnlineIndicator
            />
            <div className="hidden sm:block">
              <div className="text-xs font-semibold leading-none truncate max-w-[100px]" style={{ color: 'var(--text-main)' }}>
                {currentUser.name}
              </div>
              <div className="text-[10px] font-mono mt-0.5 leading-none flex items-center gap-1" style={{ color: 'var(--text-muted)' }}>
                {isAdmin && <Shield className="w-2.5 h-2.5" style={{ color: 'var(--accent)' }} />}
                <span>{isAdmin ? 'Admin' : 'Member'}</span>
              </div>
            </div>
          </button>
        </div>
      </div>
    </header>
  );
};

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, dmList, currentUser } = useApp();

  const unreadDMs = dmList.filter((d) => d.to === currentUser.name).length;

  const tabs: Array<{ id: 'Crew' | 'Rooms' | 'DMs' | 'Profile'; label: string; icon: React.ElementType; badge?: number }> = [
    { id: 'Crew', label: 'Crew', icon: Users },
    { id: 'Rooms', label: 'Rooms', icon: Radio },
    { id: 'DMs', label: 'DMs', icon: MessageSquare, badge: unreadDMs },
    { id: 'Profile', label: 'Profile', icon: UserCheck },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800/80 md:hidden">
      <div className="grid grid-cols-4 items-center h-16 max-w-lg mx-auto px-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as 'Crew' | 'Rooms' | 'DMs' | 'Profile')}
              className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-all ${
                isActive ? 'text-indigo-400 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 stroke-[2.2]' : 'stroke-[1.8]'}`} />
                {Boolean(tab.badge && tab.badge > 0 && tab.id === 'DMs') && (
                  <span className="absolute -top-1 -right-2.5 min-w-[14px] h-[14px] px-0.5 rounded-full bg-indigo-500 text-white text-[9px] font-mono flex items-center justify-center">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className={`text-[11px] mt-1 tracking-tight ${isActive ? 'text-indigo-400 font-semibold' : 'text-slate-400'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
