import React from 'react';
import { X, Bell, Check, Trash2, Shield, MessageSquare, Radio, Info } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const NotificationDrawer: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const { notifications, markNotificationRead, clearNotifications } = useApp();

  if (!isOpen) return null;

  const getIcon = (type?: string) => {
    switch (type) {
      case 'admin':
        return <Shield className="w-4 h-4 text-amber-400" />;
      case 'dm':
        return <MessageSquare className="w-4 h-4 text-indigo-400" />;
      case 'room':
        return <Radio className="w-4 h-4 text-emerald-400" />;
      default:
        return <Info className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end p-4 md:p-6 bg-slate-950/60 backdrop-blur-xs">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-5 text-slate-100 flex flex-col max-h-[85vh] animate-in slide-in-from-right duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-bold text-white">Notifications</h3>
            <span className="text-[11px] font-mono text-slate-400 tabular-nums">
              ({notifications.length})
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            {notifications.length > 0 && (
              <button
                type="button"
                onClick={clearNotifications}
                className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                title="Clear all"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-500">
              No recent notifications
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                onClick={() => markNotificationRead(notif.id)}
                className={`p-3 rounded-xl border text-xs cursor-pointer transition-colors ${
                  notif.read
                    ? 'bg-slate-950/50 border-slate-800/60 text-slate-400'
                    : 'bg-slate-800/80 border-indigo-500/30 text-slate-200 shadow-xs'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 shrink-0 mt-0.5">
                    {getIcon(notif.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1 mb-0.5">
                      <span className="font-semibold text-slate-200 truncate">{notif.userName}</span>
                      <span className="text-[10px] font-mono text-slate-500 shrink-0">
                        {notif.timestamp}
                      </span>
                    </div>
                    <p className="text-slate-300 leading-snug">{notif.message}</p>
                  </div>
                  {!notif.read && (
                    <span className="w-2 h-2 rounded-full bg-indigo-500 shrink-0 mt-1.5" />
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
