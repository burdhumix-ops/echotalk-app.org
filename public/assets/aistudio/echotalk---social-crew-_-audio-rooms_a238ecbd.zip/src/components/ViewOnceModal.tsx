import React, { useEffect, useState, useRef, useCallback } from 'react';
import { X, EyeOff } from 'lucide-react';

interface ViewOnceModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageSrc: string;
  senderName: string;
  isDoodle?: boolean;
  onViewed: () => void;
}

export const ViewOnceModal: React.FC<ViewOnceModalProps> = ({
  isOpen,
  onClose,
  imageSrc,
  senderName,
  isDoodle = false,
  onViewed,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(15);
  const viewedReportedRef = useRef(false);

  // Close handler with guaranteed one-time viewed dispatch
  const handleClose = useCallback(() => {
    if (!viewedReportedRef.current) {
      viewedReportedRef.current = true;
      onViewed();
    }
    onClose();
  }, [onClose, onViewed]);

  // Reset seconds left when modal opens with new media
  useEffect(() => {
    if (isOpen) {
      setSecondsLeft(15);
      viewedReportedRef.current = false;
    }
  }, [isOpen, imageSrc]);

  // Clean countdown effect
  useEffect(() => {
    if (!isOpen) return;

    if (secondsLeft <= 0) {
      handleClose();
      return;
    }

    const timer = setTimeout(() => {
      setSecondsLeft((s) => s - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [isOpen, secondsLeft, handleClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-lg animate-in fade-in duration-200 select-none no-screenshot"
      onContextMenu={(e) => e.preventDefault()}
    >
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col no-screenshot">
        {/* Top Header */}
        <div className="p-4 border-b border-slate-800/80 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center text-xs font-mono font-bold">
              1
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">
                  {isDoodle ? 'View-Once Doodle' : 'View-Once Photo'}
                </h3>
                <span className="text-[10px] font-mono text-amber-400 bg-amber-950/60 border border-amber-800/60 px-1.5 py-0.2 rounded">
                  Ephemeral · Protected
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                From {senderName} · Closes in {secondsLeft}s
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            <X className="w-4 h-4" />
            <span>Close & Dismiss</span>
          </button>
        </div>

        {/* Media Container */}
        <div
          className="relative p-4 md:p-6 bg-slate-950 flex items-center justify-center min-h-[350px] max-h-[65vh] overflow-hidden no-screenshot"
          onContextMenu={(e) => e.preventDefault()}
          onDragStart={(e) => e.preventDefault()}
        >
          <img
            src={imageSrc}
            alt={isDoodle ? 'View once doodle' : 'View once photo'}
            className="max-h-[60vh] max-w-full rounded-2xl object-contain shadow-2xl border border-slate-800/80 pointer-events-none select-none"
            draggable={false}
          />
          {/* Subtle anti-screenshot security marker */}
          <div className="absolute top-3 right-3 text-[9px] font-mono uppercase tracking-wider text-slate-600 bg-black/60 px-2 py-0.5 rounded pointer-events-none select-none">
            Screen capture prohibited
          </div>
        </div>

        {/* Footer Warning */}
        <div className="p-3 bg-slate-900/90 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <EyeOff className="w-3.5 h-3.5 text-amber-400" />
            <span>This media will disappear permanently once closed.</span>
          </div>
          <span className="font-mono tabular-nums text-slate-500">{secondsLeft}s left</span>
        </div>
      </div>
    </div>
  );
};
