import React from 'react';
import { Check, Sparkles } from 'lucide-react';
import { ThemeId, ThemeConfig } from '../types';
import { useApp } from '../context/AppContext';

export const THEME_CONFIGS: ThemeConfig[] = [
  {
    id: 'midnight',
    name: 'Midnight Dark',
    description: 'Deep Navy & Electric Violet (Default)',
    previewBg: '#0b1329',
    previewAccent: '#6366f1',
    previewBorder: '#312e81',
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk Neon',
    description: 'Dark Slate & Neon Cyan / Magenta',
    previewBg: '#0d0f17',
    previewAccent: '#06b6d4',
    previewBorder: '#ec4899',
  },
  {
    id: 'emerald',
    name: 'Emerald Slate',
    description: 'Dark Charcoal & Vivid Emerald',
    previewBg: '#0a170f',
    previewAccent: '#10b981',
    previewBorder: '#065f46',
  },
  {
    id: 'sunset',
    name: 'Sunset Amber',
    description: 'Dark Grey & Warm Amber Glow',
    previewBg: '#17100a',
    previewAccent: '#f59e0b',
    previewBorder: '#b45309',
  },
  {
    id: 'tokyo',
    name: 'Tokyo Night',
    description: 'Deep Indigo & Soft Cyan Neon',
    previewBg: '#101328',
    previewAccent: '#38bdf8',
    previewBorder: '#4338ca',
  },
  {
    id: 'light',
    name: 'Minimal White',
    description: 'Clean Modern High-Contrast Light Mode',
    previewBg: '#ffffff',
    previewAccent: '#4f46e5',
    previewBorder: '#cbd5e1',
  },
];

export const ThemeSelector: React.FC = () => {
  const { theme, setTheme, notifyUser } = useApp();

  const handleSelectTheme = (tId: ThemeId, name: string) => {
    setTheme(tId);
    notifyUser('System', `Theme updated to ${name}`, 'info');
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4" style={{ color: 'var(--accent)' }} />
          <h3 className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--text-main)' }}>
            Color Themes
          </h3>
        </div>
        <span className="text-[11px] font-mono" style={{ color: 'var(--text-muted)' }}>
          Instant UI Switching
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
        {THEME_CONFIGS.map((t) => {
          const isSelected = theme === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => handleSelectTheme(t.id, t.name)}
              className="group relative flex flex-col items-start p-3 rounded-2xl transition-all duration-200 text-left cursor-pointer border"
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: isSelected ? 'var(--accent)' : 'var(--border-theme)',
                boxShadow: isSelected ? '0 0 16px var(--accent-glow)' : 'none',
              }}
            >
              {/* Top Row: Mini Palette Preview & Check Indicator */}
              <div className="w-full flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 p-1 rounded-lg bg-black/20 border border-white/10">
                  {/* Theme Background Swatch */}
                  <span
                    className="w-4 h-4 rounded-full border border-white/20 shadow-sm"
                    style={{ backgroundColor: t.previewBg }}
                    title="Surface background"
                  />
                  {/* Theme Accent Swatch */}
                  <span
                    className="w-4 h-4 rounded-full shadow-sm"
                    style={{ backgroundColor: t.previewAccent }}
                    title="Accent primary"
                  />
                  {/* Theme Border / Secondary Swatch */}
                  <span
                    className="w-4 h-4 rounded-full shadow-sm"
                    style={{ backgroundColor: t.previewBorder }}
                    title="Secondary accent"
                  />
                </div>

                {isSelected ? (
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center text-white"
                    style={{ backgroundColor: 'var(--accent)' }}
                  >
                    <Check className="w-3 h-3 stroke-[3]" />
                  </div>
                ) : (
                  <div
                    className="w-4 h-4 rounded-full border border-white/20 group-hover:border-white/40"
                  />
                )}
              </div>

              {/* Theme Name */}
              <div className="text-xs font-bold leading-tight flex items-center gap-1.5" style={{ color: 'var(--text-main)' }}>
                <span>{t.name}</span>
                {t.id === 'midnight' && (
                  <span
                    className="text-[9px] font-mono px-1 rounded uppercase tracking-wider"
                    style={{
                      backgroundColor: 'var(--accent-light)',
                      color: 'var(--accent)',
                    }}
                  >
                    Default
                  </span>
                )}
              </div>

              {/* Theme Description */}
              <p className="text-[11px] leading-snug mt-0.5 line-clamp-1" style={{ color: 'var(--text-muted)' }}>
                {t.description}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
