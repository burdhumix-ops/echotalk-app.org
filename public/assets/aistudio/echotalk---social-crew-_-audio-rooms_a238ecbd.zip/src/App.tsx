/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { TopBar, BottomNav, NavButton } from './components/Navigation';
import { CrewScreen } from './screens/CrewScreen';
import { RoomsScreen } from './screens/RoomsScreen';
import { DMsScreen } from './screens/DMsScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { NotificationDrawer } from './components/NotificationDrawer';
import { Users, Radio, MessageSquare, UserCheck } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { activeTab, setActiveTab, currentUser, dmList } = useApp();
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const unreadDMs = dmList.filter((d) => d.to === currentUser.name).length;

  const renderScreen = () => {
    switch (activeTab) {
      case 'Crew':
        return <CrewScreen />;
      case 'Rooms':
        return <RoomsScreen />;
      case 'DMs':
        return <DMsScreen />;
      case 'Profile':
        return <ProfileScreen />;
      default:
        return <CrewScreen />;
    }
  };

  return (
    <div
      className="app-container min-h-screen flex flex-col font-sans antialiased transition-colors duration-200"
      style={{
        backgroundColor: 'var(--bg-app)',
        color: 'var(--text-main)',
      }}
    >
      {/* Top Bar with brand & notification controls */}
      <TopBar onOpenNotifications={() => setIsNotificationsOpen(true)} />

      {/* Screen Container with active screen */}
      <div className="screen-container flex-1 w-full pb-20 md:pb-8">
        {renderScreen()}
      </div>

      {/* Bottom Nav matching App.js specification */}
      <div
        className="bottom-nav fixed bottom-0 left-0 right-0 z-40 backdrop-blur-md border-t md:hidden transition-colors duration-200"
        style={{
          backgroundColor: 'var(--bg-surface)',
          borderColor: 'var(--border-theme)',
        }}
      >
        <div className="flex items-center justify-around h-16 max-w-md mx-auto px-2">
          <NavButton
            title="Crew"
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            icon={Users}
          />
          <NavButton
            title="Rooms"
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            icon={Radio}
          />
          <NavButton
            title="DMs"
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            icon={MessageSquare}
            badge={unreadDMs}
          />
          <NavButton
            title="Profile"
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            icon={UserCheck}
          />
        </div>
      </div>

      {/* Notification Drawer */}
      <NotificationDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
