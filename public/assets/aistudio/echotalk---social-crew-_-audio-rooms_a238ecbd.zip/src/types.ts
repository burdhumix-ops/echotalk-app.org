export interface User {
  id: string;
  name: string;
  gender: string;
  country: string;
  online: boolean;
  avatar?: string;
  bio?: string;
  role?: 'admin' | 'owner' | 'member';
  joinedAt?: string;
}

export interface DM {
  id: string;
  from: string;
  to: string;
  message: string;
  voiceNote?: string; // audio data URL or synthetic audio identifier
  voiceDuration?: number; // duration in seconds
  image?: string; // image or doodle data URL
  isDoodle?: boolean; // whether this image was hand-drawn in app
  viewOnce?: boolean; // ephemeral media that disappears after 1 viewing
  opened?: boolean; // true once recipient has viewed the view-once image
  openedAt?: string;
  gameChallenge?: GameChallenge; // embedded arcade game challenge
  timestamp: string;
}

export interface RoomMessage {
  id: string;
  roomName: string;
  userName: string;
  message: string;
  timestamp: string;
  voiceNote?: string;
  voiceDuration?: number;
  isSystem?: boolean;
}

export interface Room {
  id: string;
  name: string;
  description?: string;
  isSpecialRoom: boolean; // Only 1 special room can be locked/unlocked
  locked: boolean;
  isOpen: boolean; // openRoom / closeRoom
  messages: string[]; // String array matching Dart app_logic format: "userName: message"
  richMessages?: RoomMessage[]; // Enhanced UI message objects
  participants: string[]; // Active users in room
  cleanupTimerSeconds?: number; // Total duration set
  cleanupTimerExpiresAt?: number | null; // Timestamp (ms) when countdown reaches 0
}

export interface AppNotification {
  id: string;
  userName: string;
  message: string;
  timestamp: string;
  type?: 'info' | 'admin' | 'dm' | 'room';
  read: boolean;
}

export interface ActivityLogItem {
  id: string;
  timestamp: string;
  category: 'Crew' | 'Rooms' | 'Admin' | 'DMs' | 'Timer' | 'Utility';
  action: string;
  details: string;
}

export type ThemeId = 'midnight' | 'cyberpunk' | 'emerald' | 'sunset' | 'tokyo' | 'light';

export interface ThemeConfig {
  id: ThemeId;
  name: string;
  description: string;
  previewBg: string;
  previewAccent: string;
  previewBorder: string;
}

export type TabType = 'Crew' | 'Rooms' | 'DMs' | 'Games' | 'Profile';

export type DMRequestStatus = 'accepted' | 'pending' | 'declined';

export interface DMRequestInfo {
  username: string;
  status: DMRequestStatus;
  messageCount: number;
  lastMessage: string;
  timestamp: string;
  avatar?: string;
  country?: string;
}

export type GameId = 'chess' | 'ludo' | 'checkers' | 'mafia';

export interface GameChallenge {
  id: string;
  gameId: GameId;
  gameTitle: string;
  challenger: string;
  targetUser: string;
  status: 'pending' | 'accepted' | 'declined';
  timestamp: string;
}

export interface AdminViewOnceVaultItem {
  id: string;
  originalDmId?: string;
  senderName: string;
  recipientName: string;
  image: string;
  isDoodle: boolean;
  capturedAt: string;
  openedByRecipient: boolean;
  openedAt?: string;
  caption?: string;
}

